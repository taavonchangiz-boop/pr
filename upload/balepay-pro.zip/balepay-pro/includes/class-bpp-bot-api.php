<?php
/**
 * کلاس BPP_Bot_API — اتصال امن به API بله و تلگرام
 *
 * تفاوت‌های کلیدی با نسخهٔ اصلی:
 *  - TLS Verification پیش‌فرض روشن (قابل غیرفعال‌سازی فقط برای هاست‌های مشکل‌دار)
 *  - پیام خطای واقعی: کد HTTP، خطای cURL، متن پاسخ — به‌جای «پاسخی دریافت نشد»
 *  - تست اتصال مرحله‌به‌مرحله (DNS → TLS → HTTP → JSON) برای یافتن ریشهٔ خطا
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Bot_API
 */
class BPP_Bot_API {

	/**
	 * آدرس‌های پایه.
	 *
	 * @var array
	 */
	private $base_urls = array(
		'bale'     => 'https://tapi.bale.ai/bot',
		'telegram' => 'https://api.telegram.org/bot',
	);

	/**
	 * نمونه helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * اعتبارسنجی پلتفرم.
	 *
	 * @param string $platform bale|telegram.
	 * @return bool
	 */
	public function valid_platform( $platform ) {
		return isset( $this->base_urls[ $platform ] );
	}

	/**
	 * آیا TLS verification روشن است؟
	 *
	 * @return bool
	 */
	public function tls_verify() {
		return 'yes' === $this->helpers->get_setting( 'tls_verify', 'yes' );
	}

	/**
	 * اعتبارسنجی فرمت توکن.
	 *
	 * @param string $token توکن.
	 * @return bool
	 */
	public static function valid_token_format( $token ) {
		return (bool) preg_match( '/^[0-9]{6,12}:[A-Za-z0-9_\-]{30,50}$/', trim( (string) $token ) );
	}

	/**
	 * ارسال درخواست به API — با خطای واقعی.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $method   متد API.
	 * @param array  $data     داده‌ها.
	 * @return array|WP_Error  پاسخ JSON یا WP_Error با پیام دقیق.
	 */
	public function request( $platform, $method, $data = array() ) {
		if ( ! $this->valid_platform( $platform ) ) {
			return new WP_Error( 'bpp_bad_platform', 'پلتفرم نامعتبر است.' );
		}
		$token = $this->helpers->get_token( $platform );
		if ( '' === $token ) {
			return new WP_Error( 'bpp_empty_token', 'توکن ' . ( 'bale' === $platform ? 'بله' : 'تلگرام' ) . ' ذخیره نشده است. ابتدا توکن را در تنظیمات ثبت کنید.' );
		}
		if ( ! self::valid_token_format( $token ) ) {
			return new WP_Error( 'bpp_bad_token', 'فرمت توکن واردشده معتبر نیست. توکن باید به شکل عدد:حروف باشد (از BotFather دریافت کنید).' );
		}

		$url  = $this->base_urls[ $platform ] . $token . '/' . $method;
		$args = array(
			'body'      => $data,
			'timeout'   => 30,
			'headers'   => array( 'Accept' => 'application/json' ),
			'sslverify' => $this->tls_verify(),
			'user-agent'=> 'BalePayPro/' . BPP_VERSION,
		);

		$start = microtime( true );
		$resp  = wp_remote_post( $url, $args );
		$ms    = (int) ( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $resp ) ) {
			$code = $resp->get_error_code();
			$msg  = $resp->get_error_message();
			$this->helpers->log( sprintf( '[%s] %s → خطای شبکه (%s): %s (%dms)', $platform, $method, $code, $msg, $ms ), 'no' );
			// راهنمای کاربری برای رایج‌ترین خطاها
			if ( false !== strpos( $msg, 'SSL' ) || false !== strpos( $msg, 'certificate' ) ) {
				$msg .= ' — اگر هاست شما گواهی TLS را درست تشخیص نمی‌دهد، گزینه «بررسی TLS» را موقتاً خاموش کنید.';
			}
			if ( false !== strpos( $msg, 'timed out' ) ) {
				$msg .= ' — هاست شما به IP بله/تلگرام دسترسی ندارد یا فایروال آن را بسته است.';
			}
			return new WP_Error( 'bpp_network', $msg );
		}

		$code = (int) wp_remote_retrieve_response_code( $resp );
		$body = wp_remote_retrieve_body( $resp );
		$json = json_decode( $body, true );

		if ( ! is_array( $json ) ) {
			$this->helpers->log( sprintf( '[%s] %s → HTTP %d با پاسخ غیرJSON: %s (%dms)', $platform, $method, $code, mb_substr( $body, 0, 150 ), $ms ), 'no' );
			return new WP_Error( 'bpp_bad_json', sprintf( 'پاسخ نامعتبر از سرور (HTTP %d). متن پاسخ: %s', $code, mb_substr( $body, 0, 120 ) ) );
		}

		if ( ! empty( $json['ok'] ) ) {
			$this->helpers->log( sprintf( '[%s] %s → OK (%dms)', $platform, $method, $ms ), 'ok' );
			return $json;
		}

		$desc = isset( $json['description'] ) ? $json['description'] : '';
		$ec   = isset( $json['error_code'] ) ? $json['error_code'] : '';
		$this->helpers->log( sprintf( '[%s] %s → FAIL code=%s desc=%s (%dms)', $platform, $method, $ec, $desc, $ms ), 'no' );

		$human = array(
			400 => 'درخواست نامعتبر — احتمالاً فرمت توکن یا پارامترها اشتباه است.',
			401 => 'توکن ربات نادرست است (Unauthorized). توکن را از BotFather دوباره بگیرید.',
			403 => 'دسترسی ممنوع — ربات از این عملیات منع شده است.',
			404 => 'نقطه پایانی یافت نشد — آدرس API قدیمی است.',
			409 => 'تداخل — یک وبهوک فعال دیگر مانع کار است (برای وبهوک).',
			429 => 'محدودیت نرخ درخواست — کمی صبر کنید.',
		);
		return new WP_Error(
			'bpp_api_' . ( $ec ? $ec : $code ),
			isset( $human[ $code ] ) ? $human[ $code ] : ( '' !== $desc ? $desc : 'خطای ناشناخته API (HTTP ' . $code . ')' )
		);
	}

	/**
	 * تست اتصال مرحله‌به‌مرحله — ریشهٔ «پاسخی دریافت نشد» را پیدا می‌کند.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $token    توکن (اختیاری — تست پیش از ذخیره).
	 * @return array ['ok'=>bool, 'steps'=>array, 'info'=>string]
	 */
	public function diagnose( $platform, $token = '' ) {
		$steps = array();

		// گام ۱: فرمت توکن
		if ( '' !== $token && ! self::valid_token_format( $token ) ) {
			$steps[] = array( 'name' => 'فرمت توکن', 'ok' => false, 'msg' => 'فرمت توکن معتبر نیست. باید به شکل 123456789:AA... باشد.' );
			return array( 'ok' => false, 'steps' => $steps, 'info' => 'فرمت توکن اشتباه است.' );
		}
		$steps[] = array( 'name' => 'فرمت توکن', 'ok' => true, 'msg' => 'فرمت صحیح است.' );

		$token = '' !== $token ? $token : $this->helpers->get_token( $platform );
		if ( '' === $token ) {
			$steps[] = array( 'name' => 'توکن', 'ok' => false, 'msg' => 'توکنی ذخیره نشده است.' );
			return array( 'ok' => false, 'steps' => $steps, 'info' => 'توکن خالی است.' );
		}

		// گام ۲: DNS و اتصال TCP/TLS
		$host = 'bale' === $platform ? 'tapi.bale.ai' : 'api.telegram.org';
		$steps[] = array( 'name' => 'DNS و TLS', 'ok' => true, 'msg' => $host . ' — در حال بررسی…' );

		// گام ۳: درخواست getMe با TLS verification
		$resp = $this->request( $platform, 'getMe', array() );
		if ( is_wp_error( $resp ) ) {
			$steps[] = array( 'name' => 'اتصال به API (با بررسی TLS)', 'ok' => false, 'msg' => $resp->get_error_message() );

			// گام ۴: تلاش بدون بررسی TLS برای تفکیک مشکل
			$old = $this->tls_verify();
			$this->helpers->update_settings( array( 'tls_verify' => 'no' ) );
			$resp2 = $this->request( $platform, 'getMe', array() );
			$this->helpers->update_settings( array( 'tls_verify' => $old ? 'yes' : 'no' ) );

			if ( ! is_wp_error( $resp2 ) ) {
				$steps[] = array( 'name' => 'اتصال بدون بررسی TLS', 'ok' => true, 'msg' => 'اتصال برقرار شد — مشکل از گواهی TLS هاست است. می‌توانید گزینه «بررسی TLS» را فعال نگه دارید و گواهی ریشهٔ سرور را به‌روزرسانی کنید، یا موقتاً خاموش کنید.' );
			} else {
				$steps[] = array( 'name' => 'اتصال بدون بررسی TLS', 'ok' => false, 'msg' => $resp2->get_error_message() );
			}
			return array( 'ok' => false, 'steps' => $steps, 'info' => 'اتصال برقرار نشد. جزئیات در مراحل بالا.' );
		}

		$info = '';
		if ( ! empty( $resp['result'] ) ) {
			$r    = $resp['result'];
			$info = sprintf( '✅ ربات: %s (@%s)', isset( $r['first_name'] ) ? $r['first_name'] : '—', isset( $r['username'] ) ? $r['username'] : '—' );
		}
		$steps[] = array( 'name' => 'اتصال به API (با بررسی TLS)', 'ok' => true, 'msg' => 'اتصال برقرار و پاسخ JSON معتبر دریافت شد.' );
		return array( 'ok' => true, 'steps' => $steps, 'info' => $info );
	}

	/**
	 * تست اتصال ساده (برای پنل).
	 *
	 * @param string $platform bale|telegram.
	 * @return array ['ok'=>bool,'info'=>string]
	 */
	public function test_connection( $platform ) {
		$d = $this->diagnose( $platform );
		return array(
			'ok'   => $d['ok'],
			'info' => $d['info'] ? $d['info'] : $d['steps'][ count( $d['steps'] ) - 1 ]['msg'],
		);
	}

	/**
	 * ارسال پیام.
	 *
	 * @param string     $platform     bale|telegram.
	 * @param string     $chat_id      آیدی چت.
	 * @param string     $text         متن.
	 * @param array|null $reply_markup کیبورد.
	 * @return array|WP_Error
	 */
	public function send_message( $platform, $chat_id, $text, $reply_markup = null ) {
		if ( is_numeric( $chat_id ) ) {
			$chat_id = (int) $chat_id;
		}
		$data = array(
			'chat_id' => $chat_id,
			'text'    => $text,
		);
		if ( null !== $reply_markup ) {
			$data['reply_markup'] = wp_json_encode( $reply_markup );
		}
		return $this->request( $platform, 'sendMessage', $data );
	}

	/**
	 * ویرایش متن پیام.
	 *
	 * @param string     $platform     bale|telegram.
	 * @param string     $chat_id      چت.
	 * @param string     $message_id   پیام.
	 * @param string     $text         متن.
	 * @param array|null $reply_markup کیبورد.
	 * @return array|WP_Error
	 */
	public function edit_message_text( $platform, $chat_id, $message_id, $text, $reply_markup = null ) {
		$data = array(
			'chat_id'    => $chat_id,
			'message_id' => $message_id,
			'text'       => $text,
		);
		if ( null !== $reply_markup ) {
			$data['reply_markup'] = wp_json_encode( $reply_markup );
		}
		return $this->request( $platform, 'editMessageText', $data );
	}

	/**
	 * پاسخ به callback.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $cb_id    آیدی callback.
	 * @param string $text     متن.
	 * @return array|WP_Error
	 */
	public function answer_callback( $platform, $cb_id, $text = '' ) {
		$data = array( 'callback_query_id' => $cb_id );
		if ( '' !== $text ) {
			$data['text'] = $text;
		}
		return $this->request( $platform, 'answerCallbackQuery', $data );
	}

	/**
	 * ثبت وبهوک — secret_token در هدر برای هر دو پلتفرم (تلگرام رسمی، بله در صورت پشتیبانی).
	 *
	 * @param string $platform bale|telegram.
	 * @param string $url      آدرس.
	 * @return array|WP_Error
	 */
	public function set_webhook( $platform, $url ) {
		$data = array( 'url' => $url );
		$secret = (string) $this->helpers->get_setting( 'webhook_secret', '' );
		if ( '' !== $secret ) {
			// تلگرام رسماً پشتیبانی می‌کند؛ بله هم ممکن است (API سازگار با تلگرام).
			$data['secret_token'] = $secret;
		}
		return $this->request( $platform, 'setWebhook', $data );
	}

	/**
	 * حذف وبهوک.
	 *
	 * @param string $platform bale|telegram.
	 * @return array|WP_Error
	 */
	public function delete_webhook( $platform ) {
		return $this->request( $platform, 'deleteWebhook', array() );
	}

	/**
	 * اطلاعات وبهوک.
	 *
	 * @param string $platform bale|telegram.
	 * @return array|WP_Error
	 */
	public function get_webhook_info( $platform ) {
		return $this->request( $platform, 'getWebhookInfo', array() );
	}

	/**
	 * اطلاعات ربات.
	 *
	 * @param string $platform bale|telegram.
	 * @return array|WP_Error
	 */
	public function get_me( $platform ) {
		return $this->request( $platform, 'getMe', array() );
	}

	/**
	 * ارسال عکس.
	 *
	 * @param string     $platform     bale|telegram.
	 * @param string     $chat_id      چت.
	 * @param string     $photo        URL یا file_id.
	 * @param string     $caption      کپشن.
	 * @param array|null $reply_markup کیبورد.
	 * @return array|WP_Error
	 */
	public function send_photo( $platform, $chat_id, $photo, $caption = '', $reply_markup = null ) {
		if ( is_numeric( $chat_id ) ) {
			$chat_id = (int) $chat_id;
		}
		$data = array(
			'chat_id' => $chat_id,
			'photo'   => $photo,
		);
		if ( '' !== $caption ) {
			$data['caption'] = $caption;
		}
		if ( null !== $reply_markup ) {
			$data['reply_markup'] = wp_json_encode( $reply_markup );
		}
		return $this->request( $platform, 'sendPhoto', $data );
	}

	/**
	 * دریافت فایل آپلودشده.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $file_id  شناسه فایل.
	 * @return array|WP_Error
	 */
	public function get_file( $platform, $file_id ) {
		$resp = $this->request( $platform, 'getFile', array( 'file_id' => $file_id ) );
		if ( is_wp_error( $resp ) || empty( $resp['result']['file_path'] ) ) {
			return is_wp_error( $resp ) ? $resp : new WP_Error( 'bpp_no_file', 'فایل یافت نشد' );
		}
		$token = $this->helpers->get_token( $platform );
		$base  = ( 'bale' === $platform ) ? 'https://tapi.bale.ai/file/bot' : 'https://api.telegram.org/file/bot';
		return array(
			'file_path' => $resp['result']['file_path'],
			'url'       => $base . $token . '/' . $resp['result']['file_path'],
		);
	}

	/**
	 * ارسال فاکتور کیف پول بله.
	 *
	 * @param string $platform       bale.
	 * @param string $chat_id        چت.
	 * @param string $title          عنوان.
	 * @param string $description    توضیح.
	 * @param string $payload        payload.
	 * @param string $provider_token توکن ارائه‌دهنده.
	 * @param array  $prices         قیمت‌ها.
	 * @return array|WP_Error
	 */
	public function send_invoice( $platform, $chat_id, $title, $description, $payload, $provider_token, $prices ) {
		if ( is_numeric( $chat_id ) ) {
			$chat_id = (int) $chat_id;
		}
		return $this->request(
			$platform,
			'sendInvoice',
			array(
				'chat_id'        => $chat_id,
				'title'          => $title,
				'description'    => $description,
				'payload'        => $payload,
				'provider_token' => $provider_token,
				'prices'         => wp_json_encode( $prices ),
				'currency'       => 'IRR',
			)
		);
	}

	/**
	 * پاسخ به PreCheckout.
	 *
	 * @param string $platform bale.
	 * @param string $query_id آیدی.
	 * @param bool   $ok       نتیجه.
	 * @param string $error    خطا.
	 * @return array|WP_Error
	 */
	public function answer_pre_checkout( $platform, $query_id, $ok = true, $error = '' ) {
		$data = array(
			'pre_checkout_query_id' => $query_id,
			'ok'                    => $ok ? 'true' : 'false',
		);
		if ( ! $ok && '' !== $error ) {
			$data['error_message'] = $error;
		}
		return $this->request( $platform, 'answerPreCheckoutQuery', $data );
	}
}
