<?php
/**
 * کلاس BPP_Notifications — اعلان به مدیر و مشتری (ربات + سفیر + SMS)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Notifications
 */
class BPP_Notifications {

	/**
	 * API.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * SMS.
	 *
	 * @var BPP_SMS|null
	 */
	private $sms;

	/**
	 * Safir.
	 *
	 * @var BPP_Safir|null
	 */
	private $safir;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API   $api     api.
	 * @param BPP_Helpers  $helpers helpers.
	 * @param BPP_SMS|null  $sms     sms.
	 * @param BPP_Safir|null $safir  safir.
	 */
	public function __construct( $api, $helpers, $sms = null, $safir = null ) {
		$this->api     = $api;
		$this->helpers = $helpers;
		$this->sms     = $sms;
		$this->safir   = $safir;
	}

	/**
	 * ارسال به همه مدیران (ربات + سفیر + SMS).
	 *
	 * @param string $message متن.
	 */
	public function send_to_admins( $message ) {
		$sent = false;
		foreach ( array( 'bale', 'telegram' ) as $platform ) {
			if ( 'yes' !== $this->helpers->get_setting( 'notify_admin_' . ( 'bale' === $platform ? 'bale' : 'tg' ), 'yes' ) ) {
				continue;
			}
			$admin_id = $this->helpers->get_admin_chat_id( $platform );
			if ( '' === $admin_id ) {
				continue;
			}
			$resp = $this->api->send_message( $platform, $admin_id, $message );
			if ( ! is_wp_error( $resp ) ) {
				$sent = true;
			} else {
				$this->helpers->log( sprintf( '[admin] %s ارسال نشد: %s', $platform, $resp->get_error_message() ), 'wa' );
			}
		}

		$admin_phone = $this->helpers->get_setting( 'admin_phone', '' );
		if ( $admin_phone && $this->safir && $this->safir->is_enabled() ) {
			$r = $this->safir->send( $admin_phone, $message );
			if ( ! empty( $r['ok'] ) ) {
				$sent = true;
			}
		}
		if ( $admin_phone && $this->sms && $this->sms->is_enabled() ) {
			$r = $this->sms->send( $admin_phone, mb_substr( $message, 0, 300, 'UTF-8' ) );
			if ( ! empty( $r['ok'] ) ) {
				$sent = true;
			}
		}
		if ( ! $sent ) {
			$this->helpers->log( '[admin] هیچ کانالی برای اعلان مدیر فعال نیست.', 'wa' );
		}
	}

	/**
	 * اعلان به مشتری (ربات متصل، سپس سفیر/SMS).
	 *
	 * @param WC_Order $order  سفارش.
	 * @param string   $text   متن.
	 */
	public function notify_customer( $order, $text ) {
		$user_id = $order->get_user_id();
		if ( ! $user_id ) {
			return;
		}

		$sent_bot = false;
		foreach ( array( 'bale', 'telegram' ) as $platform ) {
			$flag = ( 'bale' === $platform ) ? 'notify_customer_bale' : 'notify_customer_tg';
			if ( 'yes' !== $this->helpers->get_setting( $flag, 'yes' ) ) {
				continue;
			}
			$chat_id = $this->helpers->get_user_chat_id( $user_id, $platform );
			if ( '' === $chat_id ) {
				continue;
			}
			$resp = $this->api->send_message( $platform, $chat_id, $text );
			if ( ! is_wp_error( $resp ) ) {
				$sent_bot = true;
			}
		}

		// اگر ربات در دسترس نبود، از سفیر/SMS استفاده کن
		if ( ! $sent_bot ) {
			$phone = $order->get_billing_phone();
			$short = mb_substr( preg_replace( '/\s+/u', ' ', $text ), 0, 300, 'UTF-8' );
			if ( $phone && $this->safir && $this->safir->is_enabled() ) {
				$this->safir->send( $phone, $short );
			} elseif ( $phone && $this->sms && $this->sms->is_enabled() ) {
				$this->sms->send( $phone, $short );
			}
		}
	}

	/**
	 * دکمه تأیید/رد برای مدیر.
	 *
	 * @param WC_Order $order سفارش.
	 * @return bool
	 */
	public function send_admin_verification( $order ) {
		$order_id = $order->get_id();
		$text  = "🧾 درخواست تأیید پرداخت\n\n";
		$text .= "📋 سفارش: #" . $this->helpers->fa_num( $order_id ) . "\n";
		$text .= "💰 مبلغ: " . $this->helpers->fa_money( $order->get_total() ) . " تومان\n";
		$text .= "👤 مشتری: " . trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) . "\n";
		$text .= "📞 تلفن: " . $order->get_billing_phone() . "\n";

		$receipt = $order->get_meta( '_bpp_receipt_url' );
		if ( $receipt ) {
			$text .= "🧾 رسید: " . $receipt . "\n";
		}
		$text .= "🔗 " . admin_url( 'post.php?post=' . $order_id . '&action=edit' );

		$expires = time() + 3600; // دکمه‌ها یک ساعت معتبرند

		$ok = false;
		foreach ( array( 'bale', 'telegram' ) as $platform ) {
			$flag = ( 'bale' === $platform ) ? 'notify_admin_bale' : 'notify_admin_tg';
			if ( 'yes' !== $this->helpers->get_setting( $flag, 'yes' ) ) {
				continue;
			}
			$admin_id = $this->helpers->get_admin_chat_id( $platform );
			if ( '' === $admin_id ) {
				continue;
			}
			$kb = array(
				'inline_keyboard' => array(
					array(
						array(
							'text'          => '✅ تأیید',
							'callback_data' => 'bpp:' . $order_id . ':approve:' . $expires . ':' . $this->helpers->sign( "cb:{$order_id}:approve:{$expires}:{$platform}" ),
						),
						array(
							'text'          => '❌ رد',
							'callback_data' => 'bpp:' . $order_id . ':reject:' . $expires . ':' . $this->helpers->sign( "cb:{$order_id}:reject:{$expires}:{$platform}" ),
						),
					),
				),
			);
			$resp = $this->api->send_message( $platform, $admin_id, $text, $kb );
			if ( ! is_wp_error( $resp ) ) {
				$ok = true;
			}
		}
		return $ok;
	}

	/**
	 * اعلان سفارش جدید به مدیر.
	 *
	 * @param WC_Order $order سفارش.
	 */
	public function notify_new_order( $order ) {
		$template = $this->helpers->get_setting( 'msg_order_placed', '' );
		if ( '' === $template ) {
			return;
		}
		$text = $this->helpers->render_message( $template, $order );
		$this->send_to_admins( $text );
	}

	/**
	 * اعلان آپلود رسید.
	 *
	 * @param WC_Order $order سفارش.
	 */
	public function notify_receipt_uploaded( $order ) {
		$template = $this->helpers->get_setting( 'msg_receipt_uploaded', '' );
		$text     = $template ? $this->helpers->render_message( $template, $order ) : '🧾 رسید سفارش #' . $this->helpers->fa_num( $order->get_id() ) . ' آپلود شد.';
		$this->send_to_admins( $text );
	}

	/**
	 * اعلان کاربر جدید.
	 *
	 * @param int $user_id کاربر.
	 */
	public function notify_new_user( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		$this->send_to_admins( '👤 کاربر جدید ثبت‌نام کرد: ' . $user->display_name . ' (' . $user->user_email . ')' );
	}

	/**
	 * اعلان موجودی کم.
	 *
	 * @param WC_Product $product محصول.
	 */
	public function notify_low_stock( $product ) {
		if ( ! $product ) {
			return;
		}
		$this->send_to_admins( '⚠️ موجودی کم: ' . $product->get_name() . ' — باقی‌مانده: ' . $product->get_stock_quantity() );
	}

	/**
	 * ثبت هوک‌های ووکامرس.
	 */
	public function register_hooks() {
		add_action( 'woocommerce_order_status_pending_to_on-hold', array( $this, 'on_receipt_uploaded' ), 10, 1 );
		add_action( 'user_register', array( $this, 'notify_new_user' ), 10, 1 );
		add_action( 'woocommerce_low_stock', array( $this, 'notify_low_stock' ) );
		add_action( 'woocommerce_no_stock', array( $this, 'notify_low_stock' ) );
	}

	/**
	 * هوک آپلود رسید (pending → on-hold).
	 *
	 * @param int $order_id سفارش.
	 */
	public function on_receipt_uploaded( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$this->notify_receipt_uploaded( $order );
		$this->send_admin_verification( $order );
	}
}
