<?php
/**
 * کلاس BPP_User_Link — اتصال امن chat به حساب وردپرس
 *
 * بهبودهای امنیتی نسبت به نسخهٔ اصلی:
 *  - کد اتصال دارای امضای HMAC است → قابل جعل نیست
 *  - محدودیت تعداد تلاش (ضد Brute Force)
 *  - فقط یک chat فعال در هر پلتفرم برای هر حساب
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_User_Link
 */
class BPP_User_Link {

	/**
	 * نمونه API.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * نمونه helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * مدت اعتبار کد (ثانیه).
	 *
	 * @var int
	 */
	private $code_ttl = 600;

	/**
	 * حداکثر تلاش ناموفق.
	 *
	 * @var int
	 */
	private $max_attempts = 10;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API  $api     api.
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $api, $helpers ) {
		$this->api     = $api;
		$this->helpers = $helpers;
	}

	/**
	 * تولید کد اتصال امضاشده.
	 *
	 * @param int $user_id کاربر.
	 * @return string کد مانند BLP-A1B2C3.sig
	 */
	public function generate_code( $user_id ) {
		$user_id = (int) $user_id;
		$rand    = strtoupper( wp_generate_password( 6, false, false ) );
		$expires = time() + $this->code_ttl;
		$sig     = $this->helpers->sign( "link:{$user_id}:{$rand}:{$expires}" );
		$code    = 'BLP-' . $rand . '.' . substr( $sig, 0, 12 ) . '.' . dechex( $expires );

		update_user_meta( $user_id, '_bpp_link_code', $code );
		update_user_meta( $user_id, '_bpp_link_expires', $expires );
		update_user_meta( $user_id, '_bpp_link_attempts', 0 );
		return $code;
	}

	/**
	 * کد فعال یا ساخت کد جدید.
	 *
	 * @param int $user_id کاربر.
	 * @return string
	 */
	public function get_or_create_code( $user_id ) {
		$code    = get_user_meta( $user_id, '_bpp_link_code', true );
		$expires = (int) get_user_meta( $user_id, '_bpp_link_expires', true );
		if ( '' === $code || $expires < time() ) {
			$code = $this->generate_code( $user_id );
		}
		return $code;
	}

	/**
	 * ساخت لینک عمیق.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $code     کد.
	 * @return string
	 */
	public function build_link( $platform, $code ) {
		$resp = $this->api->get_me( $platform );
		if ( is_wp_error( $resp ) || empty( $resp['result']['username'] ) ) {
			return '';
		}
		$username = $resp['result']['username'];
		$scheme   = ( 'bale' === $platform ) ? 'https://ble.ir/' : 'https://t.me/';
		return $scheme . $username . '?start=' . $code;
	}

	/**
	 * اعتبارسنجی ساختار و امضای کد.
	 *
	 * @param string $code    کد.
	 * @param int    $user_id کاربر.
	 * @param int    $expires انقضا.
	 * @return bool
	 */
	private function valid_code( $code, $user_id, $expires ) {
		if ( ! preg_match( '/^BLP-([A-Z0-9]{6})\.([a-f0-9]{12})\.([a-f0-9]+)$/', $code, $m ) ) {
			return false;
		}
		$expected = substr( $this->helpers->sign( "link:{$user_id}:{$m[1]}:{$expires}" ), 0, 12 );
		return hash_equals( $expected, $m[2] ) && (int) hexdec( $m[3] ) === (int) $expires;
	}

	/**
	 * پردازش /start با کد.
	 *
	 * @param string $text     متن.
	 * @param array  $from     from.
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 * @return bool
	 */
	public function handle_start( $text, $from, $chat_id, $platform ) {
		if ( 0 !== strpos( $text, '/start BLP-' ) ) {
			return false;
		}
		$code = trim( substr( $text, 7 ) );

		// یافتن کاربرِ دارای این کد
		$users = get_users( array(
			'meta_key'     => '_bpp_link_code',
			'meta_value'   => $code,
			'number'       => 1,
			'count_total'  => false,
		) );
		if ( empty( $users ) ) {
			$this->api->send_message( $platform, $chat_id, $this->helpers->get_setting( 'msg_link_invalid', '❌ کد اتصال نامعتبر است.' ) );
			return false;
		}

		$user    = $users[0];
		$expires = (int) get_user_meta( $user->ID, '_bpp_link_expires', true );

		// بررسی امضا
		if ( ! $this->valid_code( $code, $user->ID, $expires ) ) {
			$this->track_attempt( $user->ID, $chat_id, $platform );
			$this->api->send_message( $platform, $chat_id, '❌ کد اتصال نامعتبر است.' );
			return false;
		}

		if ( $expires < time() ) {
			$this->api->send_message( $platform, $chat_id, $this->helpers->get_setting( 'msg_link_expired', '⏰ کد اتصال منقضی شده است.' ) );
			return false;
		}

		// محدودیت تلاش
		$attempts = (int) get_user_meta( $user->ID, '_bpp_link_attempts', true );
		if ( $attempts >= $this->max_attempts ) {
			$this->api->send_message( $platform, $chat_id, '❌ تعداد تلاش‌های ناموفق زیاد است. کد جدید بگیرید.' );
			return false;
		}

		// انتقال مالکیت chat به این کاربر — فقط یک chat فعال
		$meta_key = ( 'bale' === $platform ) ? '_bpp_bale_chat_id' : '_bpp_telegram_chat_id';
		update_user_meta( $user->ID, $meta_key, (string) $chat_id );

		// حذف کد مصرف‌شده
		delete_user_meta( $user->ID, '_bpp_link_code' );
		delete_user_meta( $user->ID, '_bpp_link_expires' );
		delete_user_meta( $user->ID, '_bpp_link_attempts' );

		// پیوند در جدول
		bpp()->bot_users->link_to_wp_user( (string) $chat_id, $platform, $user->ID );

		$name         = $user->display_name;
		$platform_name = ( 'bale' === $platform ) ? 'بله' : 'تلگرام';
		$msg          = $this->helpers->get_setting(
			'msg_link_success',
			"✅ اتصال موفق!\n\nحساب {platform_name} شما به حساب «{user_name}» متصل شد."
		);
		$msg = strtr( $msg, array(
			'{platform_name}' => $platform_name,
			'{user_name}'     => $name,
		) );
		$this->api->send_message( $platform, $chat_id, $msg );
		return true;
	}

	/**
	 * ثبت تلاش ناموفق.
	 *
	 * @param int    $user_id  کاربر.
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 */
	private function track_attempt( $user_id, $chat_id, $platform ) {
		$n = (int) get_user_meta( $user_id, '_bpp_link_attempts', true ) + 1;
		update_user_meta( $user_id, '_bpp_link_attempts', $n );
		$this->helpers->log( sprintf( 'Invalid link attempt #%d for user %d from chat %s (%s)', $n, $user_id, $chat_id, $platform ), 'wa' );
	}

	/**
	 * رندر دکمه اتصال در پنل کاربری.
	 */
	public function render_link_button() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$user_id = get_current_user_id();
		$bale    = $this->helpers->get_user_chat_id( $user_id, 'bale' );
		$tg      = $this->helpers->get_user_chat_id( $user_id, 'telegram' );
		$code    = $this->get_or_create_code( $user_id );

		$vars = array(
			'bale_connected' => '' !== $bale,
			'tg_connected'   => '' !== $tg,
			'bale_link'      => $this->build_link( 'bale', $code ),
			'tg_link'        => $this->build_link( 'telegram', $code ),
			'code'           => $code,
		);
		$template = BPP_PATH . 'templates/user-link-button.php';
		if ( file_exists( $template ) ) {
			extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract
			include $template;
		}
	}
}
