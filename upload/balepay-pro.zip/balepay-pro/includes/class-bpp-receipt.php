<?php
/**
 * کلاس BPP_Receipt — آپلود رسید با nonce و کنترل مالکیت
 *
 * بهبودهای امنیتی:
 *  - nonce الزامی (WP REST)
 *  - بررسی مالکیت سفارش
 *  - بررسی MIME واقعی + حجم + نام فایل تصادفی ۲۴ کاراکتری
 *  - مسدودسازی اجرای PHP در پوشهٔ رسیدها
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Receipt
 */
class BPP_Receipt {

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * انواع مجاز.
	 *
	 * @var array
	 */
	private $allowed_types = array( 'jpg', 'jpeg', 'png', 'webp' );

	/**
	 * حداکثر حجم.
	 *
	 * @var int
	 */
	private $max_size = 5242880;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * ثبت مسیر REST.
	 */
	public function register_routes() {
		register_rest_route(
			'balepay-pro/v1',
			'/upload-receipt',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_upload' ),
				'permission_callback' => array( $this, 'upload_permission' ),
			)
		);
	}

	/**
	 * اجازهٔ آپلود: لاگین + nonce.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return bool
	 */
	public function upload_permission( $request ) {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		return '' !== $nonce && wp_verify_nonce( $nonce, 'wp_rest' );
	}

	/**
	 * پردازش آپلود.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public function handle_upload( $request ) {
		$order_id = (int) $request->get_param( 'order_id' );
		$note     = sanitize_text_field( (string) $request->get_param( 'note' ) );

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'سفارش یافت نشد' ), 404 );
		}

		$current = get_current_user_id();
		if ( (int) $order->get_user_id() !== (int) $current && ! current_user_can( 'manage_woocommerce' ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'دسترسی غیرمجاز' ), 403 );
		}

		$files = $request->get_file_params();
		if ( empty( $files['receipt'] ) || UPLOAD_ERR_OK !== (int) $files['receipt']['error'] ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'فایلی ارسال نشده است' ), 400 );
		}
		$file = $files['receipt'];

		if ( (int) $file['size'] > $this->max_size ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'حجم فایل بیش از ۵ مگابایت است' ), 400 );
		}

		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, $this->allowed_types, true ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'فقط JPG، PNG و WebP مجاز است' ), 400 );
		}

		// MIME واقعی
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			$mime  = finfo_file( $finfo, $file['tmp_name'] );
			finfo_close( $finfo );
			if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
				return new WP_REST_Response( array( 'ok' => false, 'message' => 'نوع فایل مجاز نیست' ), 400 );
			}
		}

		// ذخیره
		$upload_dir  = wp_upload_dir();
		$base_dir    = trailingslashit( $upload_dir['basedir'] ) . 'balepay-pro';
		$target_dir  = $base_dir . '/receipts/' . $order_id;
		wp_mkdir_p( $target_dir );
		$this->protect_dir( $base_dir );

		$filename    = 'r_' . time() . '_' . wp_generate_password( 24, false, false ) . '.' . $ext;
		$target_path = trailingslashit( $target_dir ) . $filename;
		$target_url  = trailingslashit( $upload_dir['baseurl'] ) . 'balepay-pro/receipts/' . $order_id . '/' . $filename;

		if ( ! move_uploaded_file( $file['tmp_name'], $target_path ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'خطا در ذخیره فایل' ), 500 );
		}

		$order->update_meta_data( '_bpp_receipt_url', $target_url );
		$order->update_meta_data( '_bpp_receipt_uploaded_at', current_time( 'mysql' ) );
		if ( '' !== $note ) {
			$order->update_meta_data( '_bpp_receipt_note', $note );
		}
		$order->save();
		$order->add_order_note( 'رسید پرداخت آپلود شد.' );

		$this->save_transaction( $order, $target_url, $note );
		$this->helpers->log( sprintf( 'Order #%d: receipt uploaded (%s)', $order_id, $filename ), 'ok' );

		// تغییر وضعیت و اعلان
		if ( $order->has_status( 'pending' ) ) {
			// هوک pending→on-hold خودش اعلان آپلود + دکمه تأیید را می‌فرستد
			$order->update_status( 'on-hold', 'رسید آپلود شد — در انتظار تأیید مدیر' );
		} else {
			// آپلود مجدد در وضعیت‌های دیگر — اعلان صریح
			bpp()->notifications->notify_receipt_uploaded( $order );
			bpp()->notifications->send_admin_verification( $order );
		}

		return new WP_REST_Response( array(
			'ok'      => true,
			'message' => 'رسید با موفقیت آپلود شد',
			'url'     => $target_url,
		), 200 );
	}

	/**
	 * ذخیره رکورد تراکنش.
	 *
	 * @param WC_Order $order   سفارش.
	 * @param string   $url     آدرس رسید.
	 * @param string   $note    یادداشت.
	 */
	private function save_transaction( $order, $url, $note ) {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];
		$order_id = $order->get_id();
		$user_id  = $order->get_user_id();

		$wpdb->delete( $table, array( 'order_id' => $order_id, 'transaction_type' => 'verify' ), array( '%d', '%s' ) );
		$wpdb->insert(
			$table,
			array(
				'order_id'         => $order_id,
				'user_id'          => $user_id ? $user_id : null,
				'platform'         => '',
				'transaction_type' => 'verify',
				'status'           => 'on-hold',
				'decision'         => '',
				'amount'           => (int) round( (float) $order->get_total() * 10 ),
				'user_chat_id'     => $user_id ? $this->helpers->get_user_chat_id( $user_id, 'bale' ) : '',
				'receipt_url'      => $url,
				'receipt_note'     => $note,
				'created_at'       => current_time( 'mysql' ),
				'updated_at'       => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * محافظت از پوشه رسیدها.
	 *
	 * @param string $base_dir پوشه پایه.
	 */
	private function protect_dir( $base_dir ) {
		// مسدودسازی اجرای PHP و فهرست‌گیری
		$htaccess = trailingslashit( $base_dir ) . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			$rules  = "# BalePay Pro\n";
			$rules .= "Options -Indexes\n";
			$rules .= "<FilesMatch \"\\.(php|phtml|php5|php7|phar)$\">\n";
			$rules .= "Require all denied\n";
			$rules .= "</FilesMatch>\n";
			@file_put_contents( $htaccess, $rules ); // phpcs:ignore
		}
		$index = trailingslashit( $base_dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			@file_put_contents( $index, "<?php // Silence is golden.\n" ); // phpcs:ignore
		}
		// زیرپوشه‌ها
		foreach ( array( 'receipts' ) as $sub ) {
			$sub_dir = trailingslashit( $base_dir ) . $sub;
			if ( is_dir( $sub_dir ) ) {
				$sub_ht = trailingslashit( $sub_dir ) . '.htaccess';
				if ( ! file_exists( $sub_ht ) ) {
					@file_put_contents( $sub_ht, "Options -Indexes\n<FilesMatch \"\\.(php|phtml|phar)$\">\nRequire all denied\n</FilesMatch>\n" ); // phpcs:ignore
				}
			}
		}
	}

	/**
	 * رندر فرم در صفحه تشکر/پنل کاربری.
	 *
	 * @param int $order_id سفارش.
	 */
	public function render_form( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( ! $this->helpers->is_card_order( $order_id ) ) {
			return;
		}
		if ( ! $order->has_status( array( 'pending', 'on-hold' ) ) ) {
			return;
		}
		// مالکیت
		$current = get_current_user_id();
		if ( ! $current || ( (int) $order->get_user_id() !== (int) $current && ! current_user_can( 'manage_woocommerce' ) ) ) {
			return;
		}

		$vars = array(
			'order_id'     => $order_id,
			'order_total'  => $this->helpers->fa_money( $order->get_total() ),
			'receipt_url'  => $order->get_meta( '_bpp_receipt_url' ),
			'upload_url'   => rest_url( 'balepay-pro/v1/upload-receipt' ),
			'nonce'        => wp_create_nonce( 'wp_rest' ),
			'instructions' => $this->helpers->get_setting( 'payment_instructions', '' ),
			'deadline'     => (int) $this->helpers->get_setting( 'payment_deadline_hours', 2 ),
		);
		$template = BPP_PATH . 'templates/receipt-upload-form.php';
		if ( file_exists( $template ) ) {
			extract( $vars ); // phpcs:ignore WordPress.PHP.DontExtract
			include $template;
		}
	}
}
