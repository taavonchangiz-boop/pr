<?php
/**
 * کلاس BPP_Bot_Users — مدیریت کاربران ربات
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Bot_Users
 */
class BPP_Bot_Users {

	/**
	 * نمونه helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * نام جدول.
	 *
	 * @return string
	 */
	private function table() {
		return $GLOBALS['bpp_tables']['bot_users'];
	}

	/**
	 * ذخیره یا به‌روزرسانی کاربر ربات.
	 *
	 * @param array  $from     آرایه from.
	 * @param string $platform bale|telegram.
	 * @param string $chat_id  آیدی چت.
	 * @return int شناسه رکورد.
	 */
	public function save_user( $from, $platform, $chat_id = '' ) {
		global $wpdb;
		$table = $this->table();

		if ( '' === $chat_id ) {
			$chat_id = isset( $from['id'] ) ? (string) $from['id'] : '';
		} else {
			$chat_id = (string) $chat_id;
		}
		if ( '' === $chat_id || ! $this->helpers || ! isset( $from ) ) {
			return 0;
		}

		$first = isset( $from['first_name'] ) ? mb_substr( (string) $from['first_name'], 0, 100, 'UTF-8' ) : '';
		$last  = isset( $from['last_name'] ) ? mb_substr( (string) $from['last_name'], 0, 100, 'UTF-8' ) : '';
		$user  = isset( $from['username'] ) ? mb_substr( (string) $from['username'], 0, 100, 'UTF-8' ) : '';
		$now   = current_time( 'mysql' );

		$existing = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE chat_id = %s AND platform = %s", $chat_id, $platform ),
			ARRAY_A
		);

		if ( $existing ) {
			$wpdb->update(
				$table,
				array(
					'first_name' => $first,
					'last_name'  => $last,
					'username'   => $user,
					'last_seen'  => $now,
				),
				array( 'id' => $existing['id'] ),
				array( '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);
			return (int) $existing['id'];
		}

		$wpdb->insert(
			$table,
			array(
				'chat_id'    => $chat_id,
				'platform'   => $platform,
				'first_name' => $first,
				'last_name'  => $last,
				'username'   => $user,
				'last_seen'  => $now,
				'created_at' => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * پیوند chat به کاربر وردپرس (فقط پس از احراز مالکیت با کد اتصال).
	 *
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 * @param int    $user_id  کاربر وردپرس.
	 * @return bool
	 */
	public function link_to_wp_user( $chat_id, $platform, $user_id ) {
		global $wpdb;
		$table = $this->table();

		$user_id = (int) $user_id;
		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return false;
		}

		$updated = $wpdb->update(
			$table,
			array( 'wp_user_id' => $user_id ),
			array( 'chat_id' => (string) $chat_id, 'platform' => $platform ),
			array( '%d' ),
			array( '%s', '%s' )
		);
		if ( false === $updated ) {
			return false;
		}

		$meta_key = ( 'bale' === $platform ) ? '_bpp_bale_chat_id' : '_bpp_telegram_chat_id';
		update_user_meta( $user_id, $meta_key, (string) $chat_id );

		$this->helpers->log( sprintf( 'chat %s (%s) linked to WP user #%d', $chat_id, $platform, $user_id ), 'ok' );
		return true;
	}

	/**
	 * کاربرِ وردپرسِ متصل به یک چت.
	 *
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 * @return int|null
	 */
	public function get_wp_user_by_chat( $chat_id, $platform ) {
		global $wpdb;
		$row = $wpdb->get_var(
			$wpdb->prepare( "SELECT wp_user_id FROM {$this->table()} WHERE chat_id = %s AND platform = %s LIMIT 1", $chat_id, $platform )
		);
		return $row ? (int) $row : null;
	}

	/**
	 * دریافت کاربر ربات با chat_id.
	 *
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 * @return array|null
	 */
	public function get_by_chat_id( $chat_id, $platform ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table()} WHERE chat_id = %s AND platform = %s", $chat_id, $platform ),
			ARRAY_A
		);
	}

	/**
	 * لیست کاربران با فیلتر.
	 *
	 * @param array $args فیلترها.
	 * @return array
	 */
	public function get_users( $args = array() ) {
		global $wpdb;
		$table  = $this->table();
		$where  = '1=1';
		$params = array();

		if ( ! empty( $args['platform'] ) && 'all' !== $args['platform'] ) {
			$where   .= ' AND platform = %s';
			$params[] = $args['platform'];
		}
		if ( ! empty( $args['search'] ) ) {
			$where   .= ' AND (first_name LIKE %s OR last_name LIKE %s OR username LIKE %s OR chat_id LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$params   = array_merge( $params, array( $like, $like, $like, $like ) );
		}
		$limit  = isset( $args['limit'] ) ? (int) $args['limit'] : 50;
		$offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;
		$where .= ' ORDER BY last_seen DESC LIMIT %d OFFSET %d';
		$params = array_merge( $params, array( $limit, $offset ) );

		$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where}", $params );
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	/**
	 * تعداد کاربران.
	 *
	 * @param array $args فیلترها.
	 * @return int
	 */
	public function count_users( $args = array() ) {
		global $wpdb;
		$table  = $this->table();
		$where  = '1=1';
		$params = array();

		if ( ! empty( $args['platform'] ) && 'all' !== $args['platform'] ) {
			$where   .= ' AND platform = %s';
			$params[] = $args['platform'];
		}
		$sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		if ( ! empty( $params ) ) {
			$sql = $wpdb->prepare( $sql, $params );
		}
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * تاریخچه چت.
	 *
	 * @param int $bot_user_id شناسه کاربر ربات.
	 * @return array
	 */
	public function get_chat_history( $bot_user_id ) {
		global $wpdb;
		$msg_table = $GLOBALS['bpp_tables']['messages'];
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$msg_table} WHERE bot_user_id = %d ORDER BY created_at ASC LIMIT 200", (int) $bot_user_id ),
			ARRAY_A
		);
	}

	/**
	 * ذخیره پیام.
	 *
	 * @param int    $bot_user_id کاربر.
	 * @param string $chat_id     چت.
	 * @param string $platform    پلتفرم.
	 * @param string $direction   in|out.
	 * @param string $type        text|photo.
	 * @param string $content     متن.
	 * @param string $file_url    آدرس فایل.
	 * @return int
	 */
	public function save_message( $bot_user_id, $chat_id, $platform, $direction, $type = 'text', $content = '', $file_url = '' ) {
		global $wpdb;
		$wpdb->insert(
			$GLOBALS['bpp_tables']['messages'],
			array(
				'bot_user_id'  => (int) $bot_user_id,
				'chat_id'      => (string) $chat_id,
				'platform'     => $platform,
				'direction'    => $direction,
				'message_type' => $type,
				'content'      => mb_substr( $content, 0, 5000, 'UTF-8' ),
				'file_url'     => $file_url,
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * بلاک/رفع بلاک.
	 *
	 * @param int  $id    شناسه.
	 * @param bool $block بلاک؟
	 * @return bool
	 */
	public function set_blocked( $id, $block ) {
		global $wpdb;
		return false !== $wpdb->update(
			$this->table(),
			array( 'is_blocked' => $block ? 1 : 0 ),
			array( 'id' => (int) $id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	/**
	 * مدیر کردن/عزل.
	 *
	 * @param int  $id   شناسه.
	 * @param bool $make مدیر؟
	 * @return bool
	 */
	public function set_admin( $id, $make ) {
		global $wpdb;
		return false !== $wpdb->update(
			$this->table(),
			array( 'is_admin' => $make ? 1 : 0 ),
			array( 'id' => (int) $id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	/**
	 * آیا چت بلاک است؟
	 *
	 * @param string $chat_id  چت.
	 * @param string $platform پلتفرم.
	 * @return bool
	 */
	public function is_blocked( $chat_id, $platform ) {
		global $wpdb;
		$v = $wpdb->get_var(
			$wpdb->prepare( "SELECT is_blocked FROM {$this->table()} WHERE chat_id = %s AND platform = %s LIMIT 1", $chat_id, $platform )
		);
		return '1' === (string) $v;
	}
}
