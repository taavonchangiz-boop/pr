<?php
/**
 * کلاس BPP_Helpers — تنظیمات، رمزنگاری، تاریخ شمسی، ابزارها
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Helpers
 */
class BPP_Helpers {

	/**
	 * تنظیمات کش‌شده.
	 *
	 * @var array|null
	 */
	private $settings = null;

	/**
	 * تنظیمات پیش‌فرض.
	 *
	 * @return array
	 */
	public function default_settings() {
		return array(
			// ربات‌ها
			'bale_token'              => '',
			'telegram_token'          => '',
			'bale_admin_chat_id'      => '',
			'telegram_admin_chat_id'  => '',
			'admin_phone'             => '',
			// درگاه کارت به کارت
			'enabled'                 => 'no',
			'title'                   => 'کارت به کارت (بله‌پی پرو)',
			'description'             => 'پرداخت با کارت به کارت و تأیید خودکار از طریق ربات بله/تلگرام',
			'cards'                   => array(),
			'sheba'                   => '',
			'payment_deadline_hours'  => 2,
			'payment_instructions'    => '',
			'status_after_approve'    => 'processing',
			'auto_expire_pending'     => 'no',
			'remind_pending_hours'    => 12,
			// کیف پول بله
			'wallet_enabled'          => 'no',
			'wallet_provider_token'   => '',
			'wallet_title'            => 'کیف پول بله',
			'wallet_description'      => 'پرداخت آنی با کیف پول بله',
			// اسنپ‌پی
			'snapppay_enabled'        => 'no',
			'snapppay_title'          => 'اسنپ‌پی (۴ قسط)',
			'snapppay_description'    => 'پرداخت اقساطی در ۴ قسط بدون چک و ضامن',
			'snapppay_client_id'      => '',
			'snapppay_client_secret'  => '',
			'snapppay_client_username'=> '',
			'snapppay_client_password'=> '',
			'snapppay_base_url'       => 'https://api.snapppay.ir/',
			'snapppay_default_gateway'=> 'no',
			'snapppay_min_amount'     => 500000,
			'snapppay_max_amount'     => 20000000,
			'snapppay_success_message'=> 'پرداخت شما با موفقیت انجام شد. ممنون از خرید شما.',
			'snapppay_failed_message' => 'پرداخت ناموفق بود. لطفاً دوباره تلاش کنید.',
			// دیجی‌پی
			'digipay_enabled'         => 'no',
			'digipay_title'           => 'دیجی‌پی (۴ قسط)',
			'digipay_description'     => 'پرداخت اقساطی در ۴ قسط بدون سود، چک و ضامن',
			'digipay_username'        => '',
			'digipay_password'        => '',
			'digipay_client_id'       => '',
			'digipay_client_secret'   => '',
			'digipay_success_message' => 'پرداخت شما با موفقیت انجام شد. ممنون از خرید شما.',
			'digipay_failed_message'  => 'پرداخت ناموفق بود. لطفاً دوباره تلاش کنید.',
			// پیام‌رسانی
			'notify_admin_bale'       => 'yes',
			'notify_admin_tg'         => 'yes',
			'notify_customer_bale'    => 'yes',
			'notify_customer_tg'      => 'yes',
			'sms_username'            => '',
			'sms_password'            => '',
			'sms_from'                => '',
			'sms_isflash'             => 0,
			'safir_access_key'        => '',
			'safir_bot_id'            => '',
			// امنیت و وبهوک
			'webhook_secret'          => '',
			'callback_hmac'           => 'yes',
			'require_verified_link'   => 'yes',
			'tls_verify'              => 'yes',
			'report_period'           => 'daily',
			'report_time'             => '08:00',
			// قالب پیام‌ها
			'msg_welcome'             => "🤖 به ربات فروشگاه خوش آمدید!\n\nبرای اتصال حساب، از پنل کاربری سایت کد اتصال بگیرید.",
			'msg_help'                => "📋 راهنما:\n/start — شروع\n/help — راهنما\n\nبرای پیگیری سفارش، شماره سفارش (مثلاً ۱۲۵۰) را بفرستید.",
			'msg_link_success'        => "✅ اتصال موفق!\n\nحساب {platform_name} شما به حساب «{user_name}» متصل شد.",
			'msg_link_invalid'        => "❌ کد اتصال نامعتبر است.\nلطفاً از پنل کاربری کد جدید بگیرید.",
			'msg_link_expired'        => "⏰ کد اتصال منقضی شده است.\nلطفاً کد جدیدی دریافت کنید.",
			'msg_order_placed'        => "🛍 سفارش جدید #{order_id}\n\n👤 {customer}\n📞 {phone}\n💰 مبلغ: {total} تومان\n🕒 {date} — {time}\n\n{items}\n💳 به یکی از کارت‌های زیر واریز کنید:\n{cards}\n\n⏳ مهلت پرداخت: {deadline} ساعت\n{order_url}",
			'msg_receipt_uploaded'    => "🧾 رسید سفارش #{order_id} آپلود شد.\nمبلغ: {total} تومان\n{order_url}",
			'msg_approved'            => "✅ پرداخت سفارش #{order_id} تأیید شد.\nسفارش در حال پردازش است.",
			'msg_rejected'            => "❌ پرداخت سفارش #{order_id} رد شد. لطفاً با پشتیبانی تماس بگیرید.",
			'msg_onhold'              => "📨 سفارش #{order_id} در انتظار تأیید مدیر است.",
		);
	}

	/**
	 * دریافت همه تنظیمات.
	 *
	 * @return array
	 */
	public function get_settings() {
		if ( null === $this->settings ) {
			$saved          = get_option( 'bpp_settings', array() );
			$this->settings = wp_parse_args( $saved, $this->default_settings() );
		}
		return $this->settings;
	}

	/**
	 * دریافت یک تنظیم.
	 *
	 * @param string $key     کلید.
	 * @param mixed  $default مقدار پیش‌فرض.
	 * @return mixed
	 */
	public function get_setting( $key, $default = null ) {
		$s = $this->get_settings();
		return isset( $s[ $key ] ) ? $s[ $key ] : $default;
	}

	/**
	 * به‌روزرسانی تنظیمات (ادغام).
	 *
	 * @param array $new تنظیمات جدید.
	 */
	public function update_settings( $new ) {
		$current        = $this->get_settings();
		$merged         = array_merge( $current, $new );
		update_option( 'bpp_settings', $merged, false );
		$this->settings = $merged;
	}

	// ============================================================
	// رمزنگاری AES-256-GCM (احرازشده) — بهتر از CBC بدون HMAC
	// ============================================================

	/**
	 * کلید رمزنگاری.
	 *
	 * @return string
	 */
	public function get_encryption_key() {
		if ( defined( 'BPP_ENCRYPTION_KEY' ) && '' !== BPP_ENCRYPTION_KEY ) {
			return hash( 'sha256', BPP_ENCRYPTION_KEY, true );
		}
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	/**
	 * رمزنگاری (AES-256-GCM).
	 *
	 * @param string $plain متن ساده.
	 * @return string base64(iv + tag + cipher).
	 */
	public function encrypt( $plain ) {
		if ( '' === $plain ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return $plain; // بدون OpenSSL، بدون رمز — ولی در پنل هشدار داده می‌شود.
		}
		$iv   = random_bytes( 12 );
		$tag  = '';
		$c    = openssl_encrypt( $plain, 'aes-256-gcm', $this->get_encryption_key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16 );
		if ( false === $c ) {
			return '';
		}
		return base64_encode( $iv . $tag . $c );
	}

	/**
	 * رمزگشایی.
	 *
	 * @param string $encoded مقدار رمزشده.
	 * @return string
	 */
	public function decrypt( $encoded ) {
		if ( '' === $encoded ) {
			return '';
		}
		$raw = base64_decode( $encoded, true );
		if ( false === $raw || strlen( $raw ) < 29 ) {
			return '';
		}
		$iv  = substr( $raw, 0, 12 );
		$tag = substr( $raw, 12, 16 );
		$c   = substr( $raw, 28 );
		$p   = openssl_decrypt( $c, 'aes-256-gcm', $this->get_encryption_key(), OPENSSL_RAW_DATA, $iv, $tag );
		return false === $p ? '' : $p;
	}

	/**
	 * آیا رمزنگاری در دسترس است؟
	 *
	 * @return bool
	 */
	public function has_crypto() {
		return function_exists( 'openssl_encrypt' ) && in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true );
	}

	/**
	 * ذخیره امن یک مقدار حساس (رمز می‌کند).
	 *
	 * @param string $key   کلید تنظیم.
	 * @param string $plain مقدار ساده.
	 */
	public function set_secret( $key, $plain ) {
		$this->update_settings( array( $key => $this->encrypt( $plain ) ) );
	}

	/**
	 * خواندن امن یک مقدار حساس (رمزگشایی).
	 *
	 * @param string $key کلید تنظیم.
	 * @return string
	 */
	public function get_secret( $key ) {
		return $this->decrypt( (string) $this->get_setting( $key, '' ) );
	}

	/**
	 * توکن ربات یک پلتفرم.
	 *
	 * @param string $platform bale|telegram.
	 * @return string
	 */
	public function get_token( $platform ) {
		$key = ( 'bale' === $platform ) ? 'bale_token' : 'telegram_token';
		return $this->get_secret( $key );
	}

	/**
	 * ذخیره توکن ربات.
	 *
	 * @param string $platform bale|telegram.
	 * @param string $token    توکن.
	 */
	public function set_token( $platform, $token ) {
		$key = ( 'bale' === $platform ) ? 'bale_token' : 'telegram_token';
		$this->set_secret( $key, trim( $token ) );
	}

	/**
	 * آیدی مدیر یک پلتفرم.
	 *
	 * @param string $platform bale|telegram.
	 * @return string
	 */
	public function get_admin_chat_id( $platform ) {
		$key = ( 'bale' === $platform ) ? 'bale_admin_chat_id' : 'telegram_admin_chat_id';
		return (string) $this->get_setting( $key, '' );
	}

	/**
	 * آیا چت داده‌شده، چت مدیرِ پلتفرم است؟
	 *
	 * @param string $platform bale|telegram.
	 * @param string $chat_id  آیدی چت.
	 * @return bool
	 */
	public function is_admin_chat( $platform, $chat_id ) {
		$admin = $this->get_admin_chat_id( $platform );
		return '' !== $admin && (string) $admin === (string) $chat_id;
	}

	/**
	 * آیدی چت متصل‌شده کاربر.
	 *
	 * @param int    $user_id  شناسه کاربر وردپرس.
	 * @param string $platform bale|telegram.
	 * @return string
	 */
	public function get_user_chat_id( $user_id, $platform ) {
		if ( ! $user_id ) {
			return '';
		}
		$key = ( 'bale' === $platform ) ? '_bpp_bale_chat_id' : '_bpp_telegram_chat_id';
		return (string) get_user_meta( $user_id, $key, true );
	}

	/**
	 * آیا کارت به کارت فعال است؟
	 *
	 * @return bool
	 */
	public function is_card_enabled() {
		return 'yes' === $this->get_setting( 'enabled', 'no' );
	}

	/**
	 * آیا کیف پول بله فعال است؟
	 *
	 * @return bool
	 */
	public function is_wallet_enabled() {
		return 'yes' === $this->get_setting( 'wallet_enabled', 'no' ) && '' !== $this->get_secret( 'wallet_provider_token' );
	}

	/**
	 * آیا اسنپ‌پی فعال است؟
	 *
	 * @return bool
	 */
	public function is_snapppay_enabled() {
		return 'yes' === $this->get_setting( 'snapppay_enabled', 'no' )
			&& '' !== $this->get_secret( 'snapppay_client_id' )
			&& '' !== $this->get_secret( 'snapppay_client_secret' );
	}

	/**
	 * آیا دیجی‌پی فعال است؟
	 *
	 * @return bool
	 */
	public function is_digipay_enabled() {
		return 'yes' === $this->get_setting( 'digipay_enabled', 'no' )
			&& '' !== $this->get_secret( 'digipay_username' )
			&& '' !== $this->get_secret( 'digipay_password' );
	}

	/**
	 * آیا سفارش با درگاه بله‌پی پرو (کارت به کارت) ثبت شده؟
	 *
	 * @param int $order_id شناسه سفارش.
	 * @return bool
	 */
	public function is_card_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		return 'bpp_card' === $order->get_payment_method();
	}

	/**
	 * تبدیل مبلغ به ریال.
	 *
	 * @param float|string $amount   مبلغ.
	 * @param string       $currency ارز.
	 * @return int
	 */
	public function amount_to_irr( $amount, $currency = 'IRR' ) {
		$amount = (float) $amount;
		if ( 'IRR' === $currency || 'IRR' === strtoupper( (string) $currency ) ) {
			return (int) round( $amount );
		}
		if ( 'IRT' === strtoupper( (string) $currency ) ) {
			return (int) round( $amount * 10 );
		}
		// سایر ارزها — فرض بر تومان بودن ورودی فروشگاه ایرانی.
		return (int) round( $amount * 10 );
	}

	/**
	 * عدد فارسی.
	 *
	 * @param int|string $num عدد.
	 * @return string
	 */
	public function fa_num( $num ) {
		$fa  = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$en  = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		return str_replace( $en, $fa, (string) $num );
	}

	/**
	 * مبلغ با جداکننده هزارگان (فارسی).
	 *
	 * @param float|int $amount مبلغ.
	 * @return string
	 */
	public function fa_money( $amount ) {
		return $this->fa_num( number_format( (float) $amount, 0, '.', ',' ) );
	}

	/**
	 * تبدیل یونیکس به تاریخ شمسی (بدون وابستگی به تقویم سایت).
	 *
	 * @param int|null $timestamp زمان یونیکس.
	 * @return string
	 */
	public function to_jalali( $timestamp = null ) {
		if ( null === $timestamp || ! $timestamp ) {
			$timestamp = time();
		}
		list( $jy, $jm, $jd ) = $this->gregorian_to_jalali( gmdate( 'Y', $timestamp ), gmdate( 'n', $timestamp ), gmdate( 'j', $timestamp ) );
		return sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
	}

	/**
	 * زمان فارسی.
	 *
	 * @return string
	 */
	public function fa_time() {
		return current_time( 'H:i' );
	}

	/**
	 * تبدیل میلادی به جلالی.
	 *
	 * @param int $gy سال میلادی.
	 * @param int $gm ماه میلادی.
	 * @param int $gd روز میلادی.
	 * @return array
	 */
	private function gregorian_to_jalali( $gy, $gm, $gd ) {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days  = 355666 + ( 365 * $gy ) + (int) ( ( $gy2 + 3 ) / 4 ) - (int) ( ( $gy2 + 99 ) / 100 ) + (int) ( ( $gy2 + 399 ) / 400 ) + $gd + $g_d_m[ $gm - 1 ];
		$jy    = -1595 + ( 33 * (int) ( $days / 12053 ) );
		$days %= 12053;
		$jy   += 4 * (int) ( $days / 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$jy  += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}
		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}
		return array( $jy, $jm, $jd );
	}

	/**
	 * نرمال‌سازی شماره موبایل به 09xxxxxxxxx.
	 *
	 * @param string $phone شماره.
	 * @return string
	 */
	public function normalize_mobile( $phone ) {
		$phone = preg_replace( '/[^0-9]/', '', (string) $phone );
		if ( '' === $phone ) {
			return '';
		}
		if ( 0 === strpos( $phone, '98' ) && 12 === strlen( $phone ) ) {
			$phone = '0' . substr( $phone, 2 );
		}
		if ( 10 === strlen( $phone ) && '9' === $phone[0] ) {
			$phone = '0' . $phone;
		}
		if ( ! preg_match( '/^09[0-9]{9}$/', $phone ) ) {
			return '';
		}
		return $phone;
	}

	/**
	 * نرمال‌سازی به 989xxxxxxxxx (برای سفیر/اس ام اس).
	 *
	 * @param string $phone شماره.
	 * @return string
	 */
	public function normalize_phone_intl( $phone ) {
		$phone = $this->normalize_mobile( $phone );
		if ( '' === $phone ) {
			return '';
		}
		return '98' . substr( $phone, 1 );
	}

	/**
	 * رندر قالب پیام با متغیرها.
	 *
	 * @param string   $template قالب.
	 * @param WC_Order $order    سفارش.
	 * @param array    $extra    متغیر اضافه.
	 * @return string
	 */
	public function render_message( $template, $order, $extra = array() ) {
		$order_id = $order->get_id();
		$items    = '';
		$i        = 0;
		foreach ( $order->get_items() as $item ) {
			if ( $i >= 10 ) {
				$items .= '...';
				break;
			}
			$items .= '🛒 ' . $item->get_name() . ' × ' . $this->fa_num( $item->get_quantity() ) . "\n";
			$i++;
		}
		$cards = '';
		$cards_raw = (array) $this->get_setting( 'cards', array() );
		foreach ( $cards_raw as $card ) {
			if ( ! empty( $card['number'] ) ) {
				$cards .= '💳 ' . $this->format_card( $card['number'] );
				if ( ! empty( $card['name'] ) ) {
					$cards .= ' — ' . $card['name'];
				}
				$cards .= "\n";
			}
		}
		$vars = array(
			'{order_id}'  => $this->fa_num( $order_id ),
			'{total}'     => $this->fa_money( $order->get_total() ),
			'{customer}'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'{phone}'     => $order->get_billing_phone(),
			'{date}'      => $this->to_jalali( $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time() ),
			'{time}'      => $this->fa_time(),
			'{items}'     => trim( $items ),
			'{cards}'     => trim( $cards ),
			'{deadline}'  => $this->fa_num( (int) $this->get_setting( 'payment_deadline_hours', 2 ) ),
			'{order_url}' => $order->get_view_order_url(),
			'{note}'      => '',
		);
		$vars = array_merge( $vars, $extra );
		return strtr( $template, $vars );
	}

	/**
	 * قالب‌بندی شماره کارت.
	 *
	 * @param string $number شماره کارت.
	 * @return string
	 */
	public function format_card( $number ) {
		$number = preg_replace( '/[^0-9]/', '', (string) $number );
		if ( 16 !== strlen( $number ) ) {
			return $number;
		}
		return implode( '-', str_split( $number, 4 ) );
	}

	// ============================================================
	// لاگ (جدول اختصاصی — نه options حجیم)
	// ============================================================

	/**
	 * افزودن لاگ.
	 *
	 * @param string $message متن.
	 * @param string $type    ok|no|in|wa.
	 */
	public function log( $message, $type = 'in' ) {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['logs'];
		$wpdb->insert(
			$table,
			array(
				'type'       => $type,
				'message'    => mb_substr( $message, 0, 2000, 'UTF-8' ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s' )
		);
		// پاکسازی لاگ‌های قدیمی‌تر از ۷ روز در ۵٪ درخواست‌ها
		if ( 0 === wp_rand( 0, 19 ) ) {
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE created_at < %s",
					gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS )
				)
			);
		}
	}

	/**
	 * دریافت لاگ‌ها.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public function get_logs( $limit = 100 ) {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['logs'];
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", (int) $limit ),
			ARRAY_A
		);
	}

	/**
	 * پاک کردن لاگ‌ها.
	 */
	public function clear_logs() {
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . $GLOBALS['bpp_tables']['logs'] );
	}

	// ============================================================
	// سواپ‌های امنیتی وبهوک
	// ============================================================

	/**
	 * امضای HMAC برای callback ها.
	 *
	 * @param string $data داده.
	 * @return string
	 */
	public function sign( $data ) {
		return hash_hmac( 'sha256', $data, $this->get_hmac_key() );
	}

	/**
	 * کلید HMAC.
	 *
	 * @return string
	 */
	public function get_hmac_key() {
		return hash( 'sha256', $this->get_secret_key_material() );
	}

	/**
	 * مواد اولیه کلید HMAC — secret وبهوک + سالت وردپرس.
	 *
	 * @return string
	 */
	private function get_secret_key_material() {
		$secret = (string) $this->get_setting( 'webhook_secret', '' );
		if ( '' === $secret ) {
			$secret = wp_generate_password( 48, true, false );
			$this->update_settings( array( 'webhook_secret' => $secret ) );
		}
		return $secret . '|' . wp_salt( 'nonce' );
	}

	/**
	 * تولید رشته تصادفی امن.
	 *
	 * @param int $length طول.
	 * @return string
	 */
	public function generate_secret( $length = 32 ) {
		return wp_generate_password( $length, true, false );
	}
}
