<?php
/**
 * بلاک‌های Checkout ووکامرس (پشتیبانی گوتنبرگ) — کاملاً متن‌باز
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس پایه بلاک.
 */
abstract class BPP_Block_Base extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {

	/**
	 * نام.
	 *
	 * @var string
	 */
	protected $name = '';

	/**
	 * دادهٔ اولیه.
	 *
	 * @var array
	 */
	protected $settings_data = array();

	/**
	 * ایزوله.
	 *
	 * @return array
	 */
	public function is_active() {
		return ! empty( $this->settings_data['enabled'] );
	}

	/**
	 * اسکریپت‌ها.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		wp_register_script(
			'bpp-blocks',
			BPP_URL . 'assets/js/blocks/balepay-pro-blocks.js',
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-i18n' ),
			BPP_VERSION,
			true
		);
		return array( 'bpp-blocks' );
	}

	/**
	 * دادهٔ پنل.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return array(
			'title'       => isset( $this->settings_data['title'] ) ? $this->settings_data['title'] : '',
			'description' => isset( $this->settings_data['description'] ) ? $this->settings_data['description'] : '',
			'supports'    => array( 'features' => array() ),
		);
	}
}

/**
 * بلاک کارت به کارت.
 */
class BPP_Blocks_Card extends BPP_Block_Base {

	/**
	 * نام.
	 *
	 * @var string
	 */
	protected $name = 'bpp_card';

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->settings_data = array(
			'enabled'     => 'yes' === bpp()->helpers->get_setting( 'enabled', 'no' ),
			'title'       => bpp()->helpers->get_setting( 'title', 'کارت به کارت' ),
			'description' => bpp()->helpers->get_setting( 'description', '' ),
		);
	}
}

/**
 * بلاک کیف پول.
 */
class BPP_Blocks_Wallet extends BPP_Block_Base {

	/**
	 * نام.
	 *
	 * @var string
	 */
	protected $name = 'bpp_wallet';

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->settings_data = array(
			'enabled'     => bpp()->helpers->is_wallet_enabled(),
			'title'       => bpp()->helpers->get_setting( 'wallet_title', 'کیف پول بله' ),
			'description' => bpp()->helpers->get_setting( 'wallet_description', '' ),
		);
	}
}

/**
 * بلاک اسنپ‌پی.
 */
class BPP_Blocks_SnappPay extends BPP_Block_Base {

	/**
	 * نام.
	 *
	 * @var string
	 */
	protected $name = 'bpp_snapppay';

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->settings_data = array(
			'enabled'     => bpp()->helpers->is_snapppay_enabled(),
			'title'       => bpp()->helpers->get_setting( 'snapppay_title', 'اسنپ‌پی' ),
			'description' => bpp()->helpers->get_setting( 'snapppay_description', '' ),
		);
	}
}

/**
 * بلاک دیجی‌پی.
 */
class BPP_Blocks_DigiPay extends BPP_Block_Base {

	/**
	 * نام.
	 *
	 * @var string
	 */
	protected $name = 'bpp_digipay';

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->settings_data = array(
			'enabled'     => bpp()->helpers->is_digipay_enabled(),
			'title'       => bpp()->helpers->get_setting( 'digipay_title', 'دیجی‌پی' ),
			'description' => bpp()->helpers->get_setting( 'digipay_description', '' ),
		);
	}
}
