<?php
/**
 * کلاس BPP_Ajax — همهٔ ای‌جکس‌های پنل (کاملاً باز، با nonce)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Ajax
 */
class BPP_Ajax {

	/**
	 * نمونه‌ها.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * ثبت هوک‌ها.
	 */
	public function register_hooks() {
		$actions = array(
			'bpp_save_settings',
			'bpp_test_connection',
			'bpp_register_webhook',
			'bpp_webhook_status',
			'bpp_dashboard_stats',
			'bpp_get_transactions',
			'bpp_get_users',
			'bpp_send_manual_message',
			'bpp_send_bulk_message',
			'bpp_set_admin',
			'bpp_block_user',
			'bpp_get_logs',
			'bpp_clear_logs',
			'bpp_send_test_report',
			'bpp_health_check',
		);
		foreach ( $actions as $a ) {
			add_action( 'wp_ajax_' . $a, array( $this, $a ) );
		}
	}

	/**
	 * بررسی دسترسی و nonce.
	 */
	private function guard() {
		if ( ! current_user_can( 'manage_bpp' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
		}
		check_ajax_referer( 'bpp_admin', 'nonce' );
	}

	/**
	 * خروجی JSON موفق.
	 *
	 * @param mixed $data داده.
	 */
	private function ok( $data ) {
		wp_send_json_success( $data );
	}

	/**
	 * خروجی JSON ناموفق.
	 *
	 * @param string $message پیام.
	 */
	private function fail( $message ) {
		wp_send_json_error( array( 'message' => $message ) );
	}

	// ------------------------------------------------------------
	// تنظیمات
	// ------------------------------------------------------------

	/**
	 * ذخیره تنظیمات — با اعتبارسنجی و رمزکردن فیلدهای حساس.
	 */
	public function bpp_save_settings() {
		$this->guard();
		$in = isset( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array(); // phpcs:ignore
		if ( empty( $in ) ) {
			$this->fail( 'داده‌ای دریافت نشد' );
		}

		$helpers = $this->helpers;
		$current = $helpers->get_settings();

		// فیلدهای متنی ساده
		$text_fields = array(
			'title', 'description', 'sheba', 'payment_instructions',
			'bale_admin_chat_id', 'telegram_admin_chat_id', 'admin_phone',
			'wallet_title', 'wallet_description',
			'snapppay_title', 'snapppay_description', 'snapppay_base_url',
			'snapppay_success_message', 'snapppay_failed_message',
			'digipay_title', 'digipay_description',
			'digipay_success_message', 'digipay_failed_message',
			'sms_username', 'sms_from', 'safir_bot_id',
			'msg_welcome', 'msg_help', 'msg_link_success', 'msg_link_invalid', 'msg_link_expired',
			'msg_order_placed', 'msg_receipt_uploaded', 'msg_approved', 'msg_rejected', 'msg_onhold',
			'report_period', 'report_time',
		);
		$new = array();
		foreach ( $text_fields as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$new[ $f ] = sanitize_textarea_field( (string) $in[ $f ] );
			}
		}

		// فیلدهای yes/no
		$yesno = array(
			'enabled', 'wallet_enabled', 'snapppay_enabled', 'digipay_enabled',
			'snapppay_default_gateway', 'notify_admin_bale', 'notify_admin_tg',
			'notify_customer_bale', 'notify_customer_tg', 'sms_isflash',
			'auto_expire_pending', 'require_verified_link', 'callback_hmac', 'tls_verify',
		);
		foreach ( $yesno as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$new[ $f ] = in_array( (string) $in[ $f ], array( 'yes', 'on', '1', 'true' ), true ) ? 'yes' : 'no';
			}
		}

		// عددی
		foreach ( array( 'payment_deadline_hours', 'remind_pending_hours', 'snapppay_min_amount', 'snapppay_max_amount' ) as $f ) {
			if ( isset( $in[ $f ] ) ) {
				$new[ $f ] = max( 0, (int) $in[ $f ] );
			}
		}
		if ( isset( $in['status_after_approve'] ) && in_array( (string) $in['status_after_approve'], array( 'processing', 'completed' ), true ) ) {
			$new['status_after_approve'] = (string) $in['status_after_approve'];
		}

		// کارت‌ها
		if ( isset( $in['cards'] ) && is_array( $in['cards'] ) ) {
			$cards = array();
			foreach ( $in['cards'] as $c ) {
				$number = preg_replace( '/[^0-9]/', '', (string) $c['number'] );
				if ( 16 !== strlen( $number ) ) {
					continue;
				}
				$cards[] = array(
					'number' => $number,
					'bank'   => sanitize_text_field( isset( $c['bank'] ) ? (string) $c['bank'] : '' ),
					'name'   => sanitize_text_field( isset( $c['name'] ) ? (string) $c['name'] : '' ),
				);
			}
			$new['cards'] = $cards;
		}

		$helpers->update_settings( $new );

		// فیلدهای حساس — فقط اگر خالی نباشند (پس‌فیلدها '•••' هستند)
		$secret_fields = array(
			'bale_token'              => 'bale_token',
			'telegram_token'          => 'telegram_token',
			'wallet_provider_token'   => 'wallet_provider_token',
			'snapppay_client_id'      => 'snapppay_client_id',
			'snapppay_client_secret'  => 'snapppay_client_secret',
			'snapppay_client_username'=> 'snapppay_client_username',
			'snapppay_client_password'=> 'snapppay_client_password',
			'digipay_username'        => 'digipay_username',
			'digipay_password'        => 'digipay_password',
			'digipay_client_id'       => 'digipay_client_id',
			'digipay_client_secret'   => 'digipay_client_secret',
			'sms_password'            => 'sms_password',
			'safir_access_key'        => 'safir_access_key',
		);
		foreach ( $secret_fields as $field => $key ) {
			if ( isset( $in[ $field ] ) ) {
				$val = trim( (string) $in[ $field ] );
				// '•••' یعنی تغییری نداده
				if ( '' !== $val && false === strpos( $val, '•••' ) ) {
					$helpers->set_secret( $key, $val );
				}
			}
		}

		// پاک‌سازی کش توکن‌های درگاه
		delete_transient( 'bpp_snapppay_bearer_token' );
		delete_option( 'bpp_digipay_tokens' );

		// زمان‌بندی مجدد گزارش
		bpp()->report->schedule();

		$this->helpers->log( 'تنظیمات ذخیره شد', 'ok' );
		$this->ok( array( 'message' => 'تنظیمات با موفقیت ذخیره شد' ) );
	}

	// ------------------------------------------------------------
	// تست اتصال — قلبِ رفع باگ «پاسخی دریافت نشد»
	// ------------------------------------------------------------

	/**
	 * تست اتصال ربات با دیاگنوستیک کامل.
	 */
	public function bpp_test_connection() {
		$this->guard();
		$platform = isset( $_POST['platform'] ) ? sanitize_key( (string) $_POST['platform'] ) : '';
		$token    = isset( $_POST['token'] ) ? trim( sanitize_text_field( wp_unslash( (string) $_POST['token'] ) ) ) : '';

		if ( ! in_array( $platform, array( 'bale', 'telegram' ), true ) ) {
			$this->fail( 'پلتفرم نامعتبر' );
		}

		// اگر توکن جدید داده شده، موقتاً تست کن — هنوز ذخیره نکن
		$d = bpp()->api->diagnose( $platform, $token );

		$this->ok( array(
			'ok'    => $d['ok'],
			'info'  => $d['info'],
			'steps' => $d['steps'],
		) );
	}

	/**
	 * ثبت وبهوک.
	 */
	public function bpp_register_webhook() {
		$this->guard();
		$platform = isset( $_POST['platform'] ) ? sanitize_key( (string) $_POST['platform'] ) : '';
		if ( ! in_array( $platform, array( 'bale', 'telegram' ), true ) ) {
			$this->fail( 'پلتفرم نامعتبر' );
		}
		$r = bpp()->webhook->register_webhook( $platform );
		if ( $r['ok'] ) {
			$this->ok( $r );
		}
		$this->fail( $r['message'] );
	}

	/**
	 * وضعیت وبهوک.
	 */
	public function bpp_webhook_status() {
		$this->guard();
		$out = array();
		foreach ( array( 'bale', 'telegram' ) as $p ) {
			$out[ $p ] = bpp()->webhook->webhook_status( $p );
		}
		$this->ok( $out );
	}

	/**
	 * آمار داشبورد.
	 */
	public function bpp_dashboard_stats() {
		$this->guard();
		$this->ok( bpp()->report->dashboard_stats() );
	}

	/**
	 * تراکنش‌ها.
	 */
	public function bpp_get_transactions() {
		$this->guard();
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];
		$limit = isset( $_POST['limit'] ) ? min( 100, max( 1, (int) $_POST['limit'] ) ) : 20;
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ),
			ARRAY_A
		);
		$this->ok( $rows );
	}

	/**
	 * کاربران ربات.
	 */
	public function bpp_get_users() {
		$this->guard();
		$args = array(
			'platform' => isset( $_POST['platform'] ) ? sanitize_key( (string) $_POST['platform'] ) : 'all',
			'search'   => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['search'] ) ) : '',
			'limit'    => 50,
		);
		$this->ok( bpp()->bot_users->get_users( $args ) );
	}

	/**
	 * ارسال پیام دستی.
	 */
	public function bpp_send_manual_message() {
		$this->guard();
		$user_id  = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		$message  = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['message'] ) ) : '';
		if ( ! $user_id || '' === $message ) {
			$this->fail( 'کاربر یا متن نامعتبر' );
		}
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$GLOBALS['bpp_tables']['bot_users']} WHERE id = %d", $user_id ), ARRAY_A );
		if ( ! $row ) {
			$this->fail( 'کاربر یافت نشد' );
		}
		$resp = bpp()->api->send_message( $row['platform'], $row['chat_id'], $message );
		if ( is_wp_error( $resp ) ) {
			$this->fail( $resp->get_error_message() );
		}
		bpp()->bot_users->save_message( (int) $row['id'], $row['chat_id'], $row['platform'], 'out', 'text', $message );
		$this->ok( array( 'message' => 'پیام ارسال شد' ) );
	}

	/**
	 * ارسال گروهی (محدود به ۱۰۰).
	 */
	public function bpp_send_bulk_message() {
		$this->guard();
		$platform = isset( $_POST['platform'] ) ? sanitize_key( (string) $_POST['platform'] ) : 'all';
		$message  = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['message'] ) ) : '';
		if ( '' === $message ) {
			$this->fail( 'متن پیام خالی است' );
		}
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['bot_users'];
		$sql = "SELECT * FROM {$table} WHERE is_blocked = 0";
		$params = array();
		if ( 'all' !== $platform ) {
			$sql .= ' AND platform = %s';
			$params[] = $platform;
		}
		$sql .= ' ORDER BY id DESC LIMIT 100';
		$rows = $wpdb->get_results( $params ? $wpdb->prepare( $sql, $params ) : $sql, ARRAY_A );

		$sent = 0;
		$failed = 0;
		foreach ( $rows as $row ) {
			$resp = bpp()->api->send_message( $row['platform'], $row['chat_id'], $message );
			if ( is_wp_error( $resp ) ) {
				$failed++;
			} else {
				$sent++;
				bpp()->bot_users->save_message( (int) $row['id'], $row['chat_id'], $row['platform'], 'out', 'text', $message );
			}
		}
		$this->ok( array( 'message' => sprintf( 'ارسال شد: %d، ناموفق: %d', $sent, $failed ) ) );
	}

	/**
	 * مدیر/عزل.
	 */
	public function bpp_set_admin() {
		$this->guard();
		$id   = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		$make = ! empty( $_POST['make'] );
		if ( ! $id ) {
			$this->fail( 'شناسه نامعتبر' );
		}
		bpp()->bot_users->set_admin( $id, $make );
		$this->ok( array( 'message' => $make ? 'مدیر شد' : 'عزل شد' ) );
	}

	/**
	 * بلاک/رفع بلاک.
	 */
	public function bpp_block_user() {
		$this->guard();
		$id    = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		$block = ! empty( $_POST['block'] );
		if ( ! $id ) {
			$this->fail( 'شناسه نامعتبر' );
		}
		bpp()->bot_users->set_blocked( $id, $block );
		$this->ok( array( 'message' => $block ? 'بلاک شد' : 'رفع بلاک شد' ) );
	}

	/**
	 * لاگ‌ها.
	 */
	public function bpp_get_logs() {
		$this->guard();
		$this->ok( $this->helpers->get_logs( 100 ) );
	}

	/**
	 * پاک کردن لاگ.
	 */
	public function bpp_clear_logs() {
		$this->guard();
		$this->helpers->clear_logs();
		$this->ok( array( 'message' => 'لاگ‌ها پاک شد' ) );
	}

	/**
	 * گزارش تستی.
	 */
	public function bpp_send_test_report() {
		$this->guard();
		$report = bpp()->report->build_report();
		$resp = bpp()->api->send_message( 'bale', $this->helpers->get_admin_chat_id( 'bale' ), $report );
		if ( is_wp_error( $resp ) ) {
			$this->fail( 'بله: ' . $resp->get_error_message() );
		}
		$this->ok( array( 'message' => 'گزارش ارسال شد' ) );
	}

	/**
	 * سلامت سیستم — نمای کلی برای پنل.
	 */
	public function bpp_health_check() {
		$this->guard();
		$out = array(
			'php_version'    => PHP_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'woocommerce'    => class_exists( 'WooCommerce' ) ? WC()->version : 'غیرفعال',
			'openssl'        => $this->helpers->has_crypto(),
			'curl'           => function_exists( 'curl_init' ),
			'ioncube'        => extension_loaded( 'ionCube Loader' ) ? 'نصب است' : 'نصب نیست (مطلوب)',
			'zlib'           => extension_loaded( 'zlib' ),
			'ssl'            => function_exists( 'openssl_verify' ),
			'rest'           => get_rest_url(),
			'server_ssl'     => is_ssl() ? 'فعال' : 'غیرفعال (توصیه: HTTPS)',
			'webhook_url'    => rest_url( 'balepay-pro/v1/webhook' ),
		);
		$this->ok( $out );
	}
}
