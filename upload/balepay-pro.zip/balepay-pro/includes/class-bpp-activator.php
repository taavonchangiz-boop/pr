<?php
/**
 * کلاس BPP_Activator — نصب، مهاجرت، حذف
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Activator
 */
class BPP_Activator {

	/**
	 * فعال‌سازی.
	 */
	public static function activate() {
		self::create_tables();
		self::migrate();
		self::seed_defaults();
		self::add_capabilities();
		self::schedule_crons();
		flush_rewrite_rules();
	}

	/**
	 * غیرفعال‌سازی.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'bpp_daily_maintenance' );
		wp_clear_scheduled_hook( 'bpp_report_cron' );
		wp_clear_scheduled_hook( 'bpp_webhook_health' );
		flush_rewrite_rules();
	}

	/**
	 * ایجاد جداول.
	 */
	public static function create_tables() {
		global $wpdb;
		$cc = $wpdb->get_charset_collate();

		$tx_table = $wpdb->prefix . 'bpp_transactions';
		$bu_table = $wpdb->prefix . 'bpp_bot_users';
		$ms_table = $wpdb->prefix . 'bpp_messages';
		$lg_table = $wpdb->prefix . 'bpp_logs';

		// نکته مهم: dbDelta فقط یک عبارت CREATE را می‌پذیرد → هر جدول جدا.
		$tables_sql = array(
			"{$tx_table}" => "CREATE TABLE {$tx_table} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				order_id BIGINT(20) NOT NULL,
				user_id BIGINT(20) UNSIGNED DEFAULT NULL,
				platform VARCHAR(16) NOT NULL DEFAULT '',
				transaction_type VARCHAR(20) NOT NULL DEFAULT 'verify',
				status VARCHAR(32) NOT NULL DEFAULT 'pending',
				decision VARCHAR(16) NOT NULL DEFAULT '',
				amount BIGINT(20) DEFAULT NULL,
				admin_chat_id VARCHAR(64) NOT NULL DEFAULT '',
				user_chat_id VARCHAR(64) NOT NULL DEFAULT '',
				receipt_url TEXT NULL,
				receipt_note TEXT NULL,
				tracking_code VARCHAR(128) NOT NULL DEFAULT '',
				undo_message_id VARCHAR(64) NOT NULL DEFAULT '',
				undo_expires INT(11) NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY order_id (order_id),
				KEY transaction_type (transaction_type),
				KEY created_at (created_at)
			) {$cc}",
			"{$bu_table}" => "CREATE TABLE {$bu_table} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				chat_id VARCHAR(64) NOT NULL,
				platform VARCHAR(16) NOT NULL,
				wp_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
				first_name VARCHAR(100) NOT NULL DEFAULT '',
				last_name VARCHAR(100) NOT NULL DEFAULT '',
				username VARCHAR(100) NOT NULL DEFAULT '',
				is_admin TINYINT(1) NOT NULL DEFAULT 0,
				is_blocked TINYINT(1) NOT NULL DEFAULT 0,
				last_seen DATETIME NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY chat_platform (chat_id, platform),
				KEY wp_user_id (wp_user_id)
			) {$cc}",
			"{$ms_table}" => "CREATE TABLE {$ms_table} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				bot_user_id BIGINT(20) UNSIGNED NOT NULL,
				chat_id VARCHAR(64) NOT NULL,
				platform VARCHAR(16) NOT NULL,
				direction VARCHAR(4) NOT NULL DEFAULT 'in',
				message_type VARCHAR(16) NOT NULL DEFAULT 'text',
				content TEXT NULL,
				file_url TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY bot_user_id (bot_user_id),
				KEY created_at (created_at)
			) {$cc}",
			"{$lg_table}" => "CREATE TABLE {$lg_table} (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				type VARCHAR(4) NOT NULL DEFAULT 'in',
				message TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY created_at (created_at)
			) {$cc}",
		);

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( $tables_sql as $sql ) {
			dbDelta( $sql );
		}

		$GLOBALS['bpp_tables']['transactions'] = $tx_table;
		$GLOBALS['bpp_tables']['bot_users']    = $bu_table;
		$GLOBALS['bpp_tables']['messages']     = $ms_table;
		$GLOBALS['bpp_tables']['logs']         = $lg_table;

		update_option( 'bpp_db_version', BPP_DB_VERSION, false );
	}

	/**
	 * مهاجرت‌های آینده اینجا اضافه می‌شوند.
	 */
	public static function migrate() {
		// placeholder برای نسخه‌های بعدی
	}

	/**
	 * تنظیمات پیش‌فرض و secret.
	 */
	private static function seed_defaults() {
		$existing = get_option( 'bpp_settings', false );
		if ( false === $existing ) {
			$helpers = new BPP_Helpers();
			$defaults = $helpers->default_settings();
			$defaults['webhook_secret'] = $helpers->generate_secret( 48 );
			update_option( 'bpp_settings', $defaults, false );
		} else {
			// اطمینان از وجود secret
			$helpers = new BPP_Helpers();
			if ( empty( $existing['webhook_secret'] ) ) {
				$existing['webhook_secret'] = $helpers->generate_secret( 48 );
				update_option( 'bpp_settings', $existing, false );
			}
		}
	}

	/**
	 * قابلیت نقش‌ها.
	 */
	private static function add_capabilities() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( 'manage_bpp' ) ) {
			$admin->add_cap( 'manage_bpp' );
		}
		$shop = get_role( 'shop_manager' );
		if ( $shop && ! $shop->has_cap( 'manage_bpp' ) ) {
			$shop->add_cap( 'manage_bpp' );
		}
	}

	/**
	 * زمان‌بندی کرون‌ها.
	 */
	private static function schedule_crons() {
		if ( ! wp_next_scheduled( 'bpp_daily_maintenance' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'bpp_daily_maintenance' );
		}
		if ( ! wp_next_scheduled( 'bpp_webhook_health' ) ) {
			wp_schedule_event( time() + 6 * HOUR_IN_SECONDS, 'twicedaily', 'bpp_webhook_health' );
		}
		// کرون گزارش توسط کلاس گزارش زمان‌بندی می‌شود
	}

	/**
	 * حذف کامل (uninstall).
	 */
	public static function uninstall() {
		global $wpdb;

		// گزینهٔ «حذف کامل داده‌ها» — اگر خاموش باشد، داده‌ها می‌مانند.
		$wipe = get_option( 'bpp_wipe_on_uninstall', 'no' );
		if ( 'yes' !== $wipe ) {
			return;
		}

		$tables = array( 'bpp_transactions', 'bpp_bot_users', 'bpp_messages', 'bpp_logs' );
		foreach ( $tables as $t ) {
			$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $t );
		}

		delete_option( 'bpp_settings' );
		delete_option( 'bpp_db_version' );
		delete_option( 'bpp_wipe_on_uninstall' );
		delete_option( 'bpp_digipay_tokens' );
		delete_transient( 'bpp_snapppay_bearer_token' );
		delete_option( 'bpp_report_next' );

		$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '\_bpp\_%'" );
		$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '\_bpp\_%'" );

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->remove_cap( 'manage_bpp' );
		}
		$shop = get_role( 'shop_manager' );
		if ( $shop ) {
			$shop->remove_cap( 'manage_bpp' );
		}
	}
}
