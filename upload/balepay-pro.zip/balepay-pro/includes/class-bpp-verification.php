<?php
/**
 * کلاس BPP_Verification — تأیید/رد/Undo با قفل اتمیک
 *
 * بهبودهای امنیتی:
 *  - فقط سفارش‌های on-hold قابل تأیید/رد هستند (ضد ریپلی دکمه‌های قدیمی)
 *  - قفل اتمیک با TTL
 *  - ثبت کامل تراکنش
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Verification
 */
class BPP_Verification {

	/**
	 * API.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * مهلت Undo (ثانیه).
	 *
	 * @var int
	 */
	private $undo_ttl = 60;

	/**
	 * مهلت قفل (ثانیه).
	 *
	 * @var int
	 */
	private $lock_ttl = 10;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API  $api     api.
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $api, $helpers ) {
		$this->api     = $api;
		$this->helpers = $helpers;
	}

	/**
	 * قفل اتمیک.
	 *
	 * @param int $order_id سفارش.
	 * @return bool
	 */
	private function acquire_lock( $order_id ) {
		$key      = 'bpp_lock_' . (int) $order_id;
		$existing = get_option( $key, 0 );
		if ( $existing && ( time() - (int) $existing ) > $this->lock_ttl ) {
			delete_option( $key );
		}
		return add_option( $key, time(), '', 'no' );
	}

	/**
	 * آزادسازی قفل.
	 *
	 * @param int $order_id سفارش.
	 */
	private function release_lock( $order_id ) {
		delete_option( 'bpp_lock_' . (int) $order_id );
	}

	/**
	 * پردازش تأیید/رد.
	 *
	 * @param int    $order_id    سفارش.
	 * @param string $action      approve|reject.
	 * @param string $platform    پلتفرم.
	 * @param string $admin_chat  چت مدیر.
	 * @param string $msg_id      پیام.
	 * @param string $cb_id       callback.
	 * @return array
	 */
	public function process_verification( $order_id, $action, $platform, $admin_chat, $msg_id, $cb_id = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '❌ سفارش یافت نشد' );
			}
			return array( 'ok' => false, 'message' => 'سفارش یافت نشد' );
		}

		// فقط سفارش در انتظار تأیید — ضد ریپلی دکمه‌های قدیمی
		if ( ! $order->has_status( 'on-hold' ) ) {
			$status_fa = $this->status_label( $order->get_status() );
			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '⏳ وضعیت سفارش: ' . $status_fa );
			}
			return array( 'ok' => false, 'message' => 'وضعیت سفارش اجازهٔ این عملیات را نمی‌دهد' );
		}

		if ( ! $this->acquire_lock( $order_id ) ) {
			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '⏳ در حال پردازش…' );
			}
			return array( 'ok' => false, 'message' => 'در حال پردازش' );
		}

		try {
			$decision_text = ( 'approve' === $action ) ? '✅ تأیید شد' : '❌ رد شد';
			$this->api->edit_message_text(
				$platform,
				$admin_chat,
				$msg_id,
				$decision_text . "\n📋 سفارش #" . $this->helpers->fa_num( $order_id ) . "\n⏰ " . $this->helpers->fa_time(),
				array()
			);

			$new_status = ( 'approve' === $action )
				? $this->helpers->get_setting( 'status_after_approve', 'processing' )
				: 'cancelled';

			$order->update_meta_data( '_bpp_decision', $action );
			$order->update_meta_data( '_bpp_previous_status', 'on-hold' );
			$order->update_meta_data( '_bpp_undo_expires', time() + $this->undo_ttl );
			$order->save();

			$note = ( 'approve' === $action )
				? 'پرداخت توسط مدیر تأیید شد (بله‌پی پرو)'
				: 'پرداخت توسط مدیر رد شد (بله‌پی پرو)';
			$order->update_status( $new_status, $note );

			$this->update_transaction( $order_id, $action, $platform, $admin_chat );

			// اعلان به مشتری
			$msg_key = ( 'approve' === $action ) ? 'msg_approved' : 'msg_rejected';
			$template = $this->helpers->get_setting( $msg_key, '' );
			if ( '' !== $template ) {
				$text = $this->helpers->render_message( $template, $order );
				bpp()->notifications->notify_customer( $order, $text );
			}

			// دکمه Undo برای مدیر
			$undo_id = $this->send_undo_message( $order_id, $action, $platform, $admin_chat );

			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, $decision_text );
			}
			$this->helpers->log( sprintf( 'Order #%d %s by admin via %s', $order_id, $action, $platform ), 'ok' );

			return array( 'ok' => true, 'message' => $decision_text, 'undo_message_id' => $undo_id );
		} finally {
			$this->release_lock( $order_id );
		}
	}

	/**
	 * ارسال پیام Undo.
	 *
	 * @param int    $order_id   سفارش.
	 * @param string $action     approve|reject.
	 * @param string $platform   پلتفرم.
	 * @param string $admin_chat چت مدیر.
	 * @return string
	 */
	private function send_undo_message( $order_id, $action, $platform, $admin_chat ) {
		$expires = time() + $this->undo_ttl;
		$data    = 'bpp:' . $order_id . ':undo:' . $expires . ':' . $this->helpers->sign( "cb:{$order_id}:undo:{$expires}:{$platform}" );
		$kb      = array(
			'inline_keyboard' => array(
				array(
					array(
						'text'          => '↩️ بازگشت (۶۰ ثانیه)',
						'callback_data' => $data,
					),
				),
			),
		);
		$status_text = ( 'approve' === $action ) ? 'تأیید شده' : 'رد شده';
		$resp = $this->api->send_message(
			$platform,
			$admin_chat,
			"⚠️ وضعیت سفارش #" . $this->helpers->fa_num( $order_id ) . " ← " . $status_text . "\nاگر اشتباه بود، بازگشت بزنید:",
			$kb
		);
		if ( ! is_wp_error( $resp ) && ! empty( $resp['result']['message_id'] ) ) {
			return (string) $resp['result']['message_id'];
		}
		return '';
	}

	/**
	 * پردازش Undo.
	 *
	 * @param int    $order_id  سفارش.
	 * @param string $platform  پلتفرم.
	 * @param string $admin_chat چت.
	 * @param string $msg_id    پیام.
	 * @param string $cb_id     callback.
	 * @return array
	 */
	public function process_undo( $order_id, $platform, $admin_chat, $msg_id, $cb_id = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'ok' => false, 'message' => 'سفارش یافت نشد' );
		}

		$expires = (int) $order->get_meta( '_bpp_undo_expires' );
		if ( $expires > 0 && time() > $expires ) {
			$this->api->answer_callback( $platform, $cb_id, '⏰ مهلت بازگشت تمام شده است' );
			return array( 'ok' => false, 'message' => 'مهلت تمام شده' );
		}

		if ( ! $this->acquire_lock( $order_id ) ) {
			$this->api->answer_callback( $platform, $cb_id, '⏳ در حال پردازش…' );
			return array( 'ok' => false, 'message' => 'در حال پردازش' );
		}

		try {
			$this->api->edit_message_text(
				$platform,
				$admin_chat,
				$msg_id,
				"↩️ بازگشت انجام شد\n📋 سفارش #" . $this->helpers->fa_num( $order_id ) . " ← در انتظار تأیید",
				array()
			);

			$order->update_meta_data( '_bpp_undo_expires', 0 );
			$order->update_meta_data( '_bpp_decision', '' );
			$order->save();
			$order->update_status( 'on-hold', 'بازگشت از تصمیم مدیر — در انتظار تأیید مجدد' );

			$this->update_transaction( $order_id, 'undo', $platform, $admin_chat );

			// اطلاع به مشتری
			$msg_key = 'msg_onhold';
			$template = $this->helpers->get_setting( $msg_key, '' );
			if ( '' !== $template ) {
				$text = $this->helpers->render_message( $template, $order );
				bpp()->notifications->notify_customer( $order, $text );
			}

			// ارسال مجدد دکمه تأیید به مدیر
			bpp()->notifications->send_admin_verification( $order );

			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '↩️ بازگشت انجام شد' );
			}
			$this->helpers->log( sprintf( 'Order #%d undo by admin via %s', $order_id, $platform ), 'ok' );
			return array( 'ok' => true, 'message' => 'بازگشت انجام شد' );
		} finally {
			$this->release_lock( $order_id );
		}
	}

	/**
	 * به‌روزرسانی جدول تراکنش.
	 *
	 * @param int    $order_id   سفارش.
	 * @param string $decision   approve|reject|undo.
	 * @param string $platform   پلتفرم.
	 * @param string $admin_chat چت.
	 */
	private function update_transaction( $order_id, $decision, $platform, $admin_chat ) {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];
		$status = ( 'approve' === $decision ) ? 'processing' : ( ( 'reject' === $decision ) ? 'cancelled' : 'on-hold' );
		$wpdb->update(
			$table,
			array(
				'decision'    => $decision,
				'status'      => $status,
				'admin_chat_id' => $admin_chat,
				'updated_at'  => current_time( 'mysql' ),
			),
			array( 'order_id' => $order_id, 'transaction_type' => 'verify' ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d', '%s' )
		);
	}

	/**
	 * برچسب فارسی وضعیت.
	 *
	 * @param string $status وضعیت.
	 * @return string
	 */
	private function status_label( $status ) {
		$map = array(
			'pending'    => 'در انتظار پرداخت',
			'on-hold'    => 'در انتظار تأیید',
			'processing' => 'در حال پردازش',
			'completed'  => 'تکمیل شده',
			'cancelled'  => 'لغو شده',
			'failed'     => 'ناموفق',
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : $status;
	}
}
