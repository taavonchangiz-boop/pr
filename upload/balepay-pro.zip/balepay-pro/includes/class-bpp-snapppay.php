<?php
/**
 * درگاه اسنپ‌پی — API + گیت‌وی (با TLS امن و توکن‌های رمز)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاینت API اسنپ‌پی.
 */
class BPP_SnappPay_API {

	/**
	 * تنظیمات.
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->settings = bpp()->helpers->get_settings();
	}

	/**
	 * URL پایه.
	 *
	 * @return string
	 */
	public function base_url() {
		$base = (string) $this->settings['snapppay_base_url'];
		return ( '/' === substr( $base, -1 ) ) ? $base : $base . '/';
	}

	/**
	 * هدر Basic.
	 *
	 * @return array
	 */
	private function basic_headers() {
		$h = bpp()->helpers;
		return array(
			'Authorization' => 'Basic ' . base64_encode( $h->get_secret( 'snapppay_client_id' ) . ':' . $h->get_secret( 'snapppay_client_secret' ) ),
			'Content-Type'  => 'application/x-www-form-urlencoded',
		);
	}

	/**
	 * توکن Bearer با کش.
	 *
	 * @return string
	 */
	private function bearer_token() {
		$token = get_transient( 'bpp_snapppay_bearer_token' );
		if ( $token ) {
			return $token;
		}
		$h = bpp()->helpers;
		$resp = wp_remote_post( $this->base_url() . 'api/online/v1/oauth/token', array(
			'headers'   => $this->basic_headers(),
			'body'      => http_build_query( array(
				'grant_type' => 'password',
				'scope'      => 'online-merchant',
				'username'   => $h->get_secret( 'snapppay_client_username' ),
				'password'   => $h->get_secret( 'snapppay_client_password' ),
			) ),
			'timeout'   => 30,
			'sslverify' => 'yes' === $h->get_setting( 'tls_verify', 'yes' ),
		) );
		if ( is_wp_error( $resp ) ) {
			return '';
		}
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( empty( $json['access_token'] ) ) {
			return '';
		}
		$ttl = isset( $json['expires_in'] ) ? (int) $json['expires_in'] : 3600;
		set_transient( 'bpp_snapppay_bearer_token', $json['access_token'], max( 60, $ttl - 60 ) );
		return $json['access_token'];
	}

	/**
	 * درخواست عمومی.
	 *
	 * @param string $endpoint نقطه پایانی.
	 * @param string $method   GET|POST.
	 * @param array  $args     داده.
	 * @param bool   $json     بدنه JSON؟
	 * @return array|WP_Error
	 */
	private function request( $endpoint, $method = 'GET', $args = array(), $json = true ) {
		$token = $this->bearer_token();
		if ( '' === $token ) {
			return new WP_Error( 'bpp_spp_auth', 'دریافت توکن اسنپ‌پی ناموفق بود. اعتبارنامه‌ها را بررسی کنید.' );
		}
		$url = $this->base_url() . $endpoint;
		if ( 'GET' === $method && ! empty( $args ) ) {
			$url = add_query_arg( $args, $url );
		}
		$req = array(
			'method'    => $method,
			'headers'   => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => $json ? 'application/json' : 'application/x-www-form-urlencoded',
			),
			'timeout'   => 30,
			'sslverify' => 'yes' === bpp()->helpers->get_setting( 'tls_verify', 'yes' ),
		);
		if ( 'GET' !== $method && ! empty( $args ) ) {
			$req['body'] = $json ? wp_json_encode( $args ) : http_build_query( $args );
		}
		$resp = wp_remote_request( $url, $req );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		if ( 401 === $code ) {
			delete_transient( 'bpp_snapppay_bearer_token' );
			return new WP_Error( 'bpp_spp_401', 'توکن منقضی شد — دوباره تلاش کنید.' );
		}
		$body = wp_remote_retrieve_body( $resp );
		$json_out = json_decode( $body, true );
		if ( ! is_array( $json_out ) ) {
			return new WP_Error( 'bpp_spp_badjson', 'پاسخ نامعتبر اسنپ‌پی (HTTP ' . $code . ')' );
		}
		return $json_out;
	}

	/**
	 * مبلغ سفارش به ریال.
	 *
	 * @param WC_Order $order سفارش.
	 * @return int
	 */
	private function order_amount_rial( $order ) {
		return bpp()->helpers->amount_to_irr( $order->get_total(), $order->get_currency() );
	}

	/**
	 * توکن پرداخت.
	 *
	 * @param WC_Order $order سفارش.
	 * @return array|WP_Error
	 */
	public function get_payment_token( $order ) {
		$order_id = $order->get_id();
		$callback = add_query_arg(
			array( 'wc_order' => $order_id, 'gateway' => 'snapppay' ),
			WC()->api_request_url( 'bpp_snapppay' )
		);
		$data = array(
			'amount'               => $this->order_amount_rial( $order ),
			'paymentMethodTypeDto' => 'INSTALLMENT',
			'returnURL'            => $callback,
			'transactionId'        => time() . '-' . $order_id,
			'discountAmount'       => 0,
		);
		$mobile = bpp()->helpers->normalize_mobile( $order->get_billing_phone() );
		if ( '' !== $mobile ) {
			$data['mobile'] = '98' . substr( $mobile, 1 );
		}
		$data['cartList'] = array( array(
			'cartId'    => $order_id,
			'productList' => $this->product_list( $order ),
		) );
		return $this->request( 'api/online/payment/v1/token', 'POST', $data, true );
	}

	/**
	 * لیست محصولات.
	 *
	 * @param WC_Order $order سفارش.
	 * @return array
	 */
	private function product_list( $order ) {
		$list = array();
		foreach ( $order->get_items() as $item ) {
			$list[] = array(
				'productId' => $item->get_product_id(),
				'title'     => mb_substr( $item->get_name(), 0, 100, 'UTF-8' ),
				'count'     => $item->get_quantity(),
				'price'     => $this->order_amount_rial( $order ),
			);
		}
		return $list;
	}

	/**
	 * بررسی صلاحیت.
	 *
	 * @param int $amount مبلغ ریال.
	 * @return array|WP_Error
	 */
	public function eligible( $amount ) {
		return $this->request( 'api/online/offer/v1/eligible', 'GET', array( 'amount' => $amount ), false );
	}

	/**
	 * verify.
	 *
	 * @param string $token توکن پرداخت.
	 * @return array|WP_Error
	 */
	public function verify( $token ) {
		return $this->request( 'api/online/payment/v1/verify', 'POST', array( 'paymentToken' => $token ), true );
	}

	/**
	 * settle.
	 *
	 * @param string $token توکن پرداخت.
	 * @return array|WP_Error
	 */
	public function settle( $token ) {
		return $this->request( 'api/online/payment/v1/settle', 'POST', array( 'paymentToken' => $token ), true );
	}

	/**
	 * cancel.
	 *
	 * @param string $token توکن.
	 * @return array|WP_Error
	 */
	public function cancel( $token ) {
		return $this->request( 'api/online/payment/v1/cancel', 'POST', array( 'paymentToken' => $token ), true );
	}
}

/**
 * گیت‌وی اسنپ‌پی.
 */
class BPP_Gateway_SnappPay extends WC_Payment_Gateway {

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->id                 = 'bpp_snapppay';
		$this->has_fields         = false;
		$this->method_title       = 'بله‌پی پرو (اسنپ‌پی)';
		$this->method_description = 'پرداخت اقساطی ۴ قسطی اسنپ‌پی';
		$this->supports           = array( 'products', 'refunds' );

		$helpers = bpp()->helpers;
		if ( null === $helpers ) {
			$this->enabled = 'no';
			return;
		}
		$this->title       = $helpers->get_setting( 'snapppay_title', 'اسنپ‌پی (۴ قسط)' );
		$this->description = $helpers->get_setting( 'snapppay_description', '' );
		$this->enabled     = $helpers->is_snapppay_enabled() ? 'yes' : 'no';

		$this->init_form_fields();
		$this->init_settings();
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
		add_action( 'woocommerce_api_bpp_snapppay', array( $this, 'callback' ) );
	}

	/**
	 * فرم خلاصه.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => 'فعال‌سازی',
				'type'    => 'checkbox',
				'label'   => 'فعال‌سازی اسنپ‌پی',
				'default' => 'no',
			),
			'notice'  => array(
				'type'        => 'title',
				'description' => 'اعتبارنامه‌های اسنپ‌پی در «بله‌پی پرو ← تنظیمات» (رمزنگاری‌شده) ذخیره می‌شوند.',
			),
		);
	}

	/**
	 * فرستادن به صفحه پرداخت.
	 *
	 * @param int $order_id سفارش.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$order->update_meta_data( '_bpp_payment_method', 'snapppay' );
		$order->save();
		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		);
	}

	/**
	 * صفحه پرداخت (شروع مستقیم).
	 *
	 * @param int $order_id سفارش.
	 */
	public function receipt_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		echo '<div style="text-align:center;padding:30px">';
		echo '<p>' . esc_html__( 'در حال انتقال به درگاه اسنپ‌پی…', 'balepay-pro' ) . '</p>';
		echo '<a class="button alt" href="' . esc_url( add_query_arg( 'bpp_go', '1' ) ) . '">' . esc_html__( 'پرداخت با اسنپ‌پی', 'balepay-pro' ) . '</a>';
		echo '</div>';

		if ( ! isset( $_GET['bpp_go'] ) ) { // phpcs:ignore
			return;
		}
		$api  = new BPP_SnappPay_API();
		$resp = $api->get_payment_token( $order );
		if ( is_wp_error( $resp ) || empty( $resp['response']['paymentPageUrl'] ) ) {
			$msg = is_wp_error( $resp ) ? $resp->get_error_message() : 'پاسخ نامعتبر از اسنپ‌پی';
			$order->add_order_note( 'خطای اسنپ‌پی: ' . $msg );
			wc_add_notice( 'خطا در اتصال به اسنپ‌پی: ' . $msg, 'error' );
			return;
		}
		$token = isset( $resp['response']['paymentToken'] ) ? $resp['response']['paymentToken'] : '';
		$order->update_meta_data( '_bpp_spp_token', $token );
		$order->save();
		echo '<script>window.location.href=' . wp_json_encode( $resp['response']['paymentPageUrl'] ) . ';</script>';
	}

	/**
	 * بازگشت از درگاه.
	 */
	public function callback() {
		$order_id = isset( $_GET['wc_order'] ) ? absint( $_GET['wc_order'] ) : 0; // phpcs:ignore
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		if ( ! $order->needs_payment() ) {
			wp_safe_redirect( $this->get_return_url( $order ) );
			exit;
		}
		$state = isset( $_POST['state'] ) ? sanitize_text_field( wp_unslash( $_POST['state'] ) ) : ''; // phpcs:ignore
		if ( 'OK' !== $state ) {
			$order->update_status( 'failed', 'پرداخت اسنپ‌پی ناموفق (state=' . $state . ')' );
			wc_add_notice( 'پرداخت اسنپ‌پی ناموفق بود.', 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		$token = $order->get_meta( '_bpp_spp_token' );
		if ( ! $token ) {
			$token = isset( $_POST['paymentToken'] ) ? sanitize_text_field( wp_unslash( $_POST['paymentToken'] ) ) : ''; // phpcs:ignore
		}
		if ( ! $token ) {
			wc_add_notice( 'توکن پرداخت نامعتبر است.', 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}

		$api = new BPP_SnappPay_API();
		$verify = $api->verify( $token );
		if ( is_wp_error( $verify ) || empty( $verify['successful'] ) ) {
			$msg = is_wp_error( $verify ) ? $verify->get_error_message() : 'تأیید ناموفق';
			$order->update_status( 'failed', 'تأیید اسنپ‌پی: ' . $msg );
			wc_add_notice( 'خطا: ' . $msg, 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		$settle = $api->settle( $token );
		$order->update_meta_data( '_transaction_id', $token );
		$order->save();
		$order->payment_complete( $token );
		$order->add_order_note( 'پرداخت اسنپ‌پی تأیید و تسویه شد.' );
		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}
		wc_add_notice( bpp()->helpers->get_setting( 'snapppay_success_message', 'پرداخت با موفقیت انجام شد.' ), 'success' );
		wp_safe_redirect( $this->get_return_url( $order ) );
		exit;
	}
}
