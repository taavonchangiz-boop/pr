<?php
/**
 * درگاه‌های پرداخت بله‌پی پرو — کارت به کارت + کیف پول
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * درگاه کارت به کارت.
 */
class BPP_Gateway_Card extends WC_Payment_Gateway {

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->id                 = 'bpp_card';
		$this->has_fields         = true;
		$this->method_title       = 'بله‌پی پرو (کارت به کارت)';
		$this->method_description = 'پرداخت کارت به کارت با تأیید خودکار از ربات بله/تلگرام';
		$this->supports           = array( 'products' );

		$helpers = bpp()->helpers;
		if ( null === $helpers ) {
			$this->enabled = 'no';
			return;
		}
		$this->title       = $helpers->get_setting( 'title', 'کارت به کارت' );
		$this->description = $helpers->get_setting( 'description', '' );
		$this->enabled     = ( 'yes' === $helpers->get_setting( 'enabled', 'no' ) ) ? 'yes' : 'no';

		$this->init_form_fields();
		$this->init_settings();
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * فرم تنظیمات خلاصه در ووکامرس.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => 'فعال‌سازی',
				'type'    => 'checkbox',
				'label'   => 'فعال‌سازی درگاه کارت به کارت',
				'default' => 'no',
			),
			'notice'  => array(
				'type'        => 'title',
				'description' => 'تنظیمات کامل (کارت‌ها، ربات، پیام‌ها) در «بله‌پی پرو ← تنظیمات» است.',
			),
		);
	}

	/**
	 * فیلدهای صفحه پرداخت.
	 */
	public function payment_fields() {
		$helpers = bpp()->helpers;
		if ( '' !== $helpers->get_setting( 'description', '' ) ) {
			echo '<p>' . esc_html( $helpers->get_setting( 'description' ) ) . '</p>';
		}
		$cards = (array) $helpers->get_setting( 'cards', array() );
		if ( ! empty( $cards ) ) {
			echo '<div class="bpp-card-list">';
			foreach ( $cards as $c ) {
				echo '<div style="padding:8px;border:1px solid #e5e7eb;border-radius:8px;margin:6px 0;direction:ltr;text-align:left">';
				echo '<strong>' . esc_html( $helpers->format_card( $c['number'] ) ) . '</strong>';
				if ( ! empty( $c['name'] ) ) {
					echo '<div style="color:#6b7280">' . esc_html( $c['name'] ) . '</div>';
				}
				echo '</div>';
			}
			echo '</div>';
		}
		$instructions = $helpers->get_setting( 'payment_instructions', '' );
		if ( '' !== $instructions ) {
			echo '<div style="font-size:13px;color:#4b5563">' . nl2br( esc_html( $instructions ) ) . '</div>';
		}
	}

	/**
	 * پردازش پرداخت — سفارش pending.
	 *
	 * @param int $order_id سفارش.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$order->update_meta_data( '_bpp_payment_method', 'card' );
		$order->update_meta_data( '_bpp_verify_sent', 0 );
		$order->save();

		// اعلان سفارش جدید به مدیر
		bpp()->notifications->notify_new_order( $order );

		// متن صفحه تشکر
		WC()->session->set( 'bpp_thankyou_note', 'سفارش شما ثبت شد! لطفاً مبلغ را به یکی از کارت‌های بالا واریز و رسید را در همین صفحه آپلود کنید.' );

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}
}

/**
 * درگاه کیف پول بله.
 */
class BPP_Gateway_Wallet extends WC_Payment_Gateway {

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->id                 = 'bpp_wallet';
		$this->has_fields         = false;
		$this->method_title       = 'بله‌پی پرو (کیف پول بله)';
		$this->method_description = 'پرداخت آنی با کیف پول بله از طریق ربات';
		$this->supports           = array( 'products' );

		$helpers = bpp()->helpers;
		if ( null === $helpers ) {
			$this->enabled = 'no';
			return;
		}
		$this->title       = $helpers->get_setting( 'wallet_title', 'کیف پول بله' );
		$this->description = $helpers->get_setting( 'wallet_description', '' );
		$this->enabled     = $helpers->is_wallet_enabled() ? 'yes' : 'no';

		$this->init_form_fields();
		$this->init_settings();
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * فرم خلاصه.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => 'فعال‌سازی',
				'type'    => 'checkbox',
				'label'   => 'فعال‌سازی کیف پول بله',
				'default' => 'no',
			),
			'notice'  => array(
				'type'        => 'title',
				'description' => 'توکن ارائه‌دهندهٔ پرداخت (Provider Token) در «بله‌پی پرو ← تنظیمات» وارد می‌شود.',
			),
		);
	}

	/**
	 * پردازش پرداخت — ارسال فاکتور به ربات.
	 *
	 * @param int $order_id سفارش.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$order->update_meta_data( '_bpp_payment_method', 'wallet' );
		$order->save();

		$r = bpp()->wallet->send_invoice_for_order( $order_id, $order );

		if ( ! $r['ok'] ) {
			wc_add_notice( 'کیف پول بله: ' . $r['message'], 'error' );
			return array( 'result' => 'failure' );
		}

		// منتظر پرداخت در ربات می‌مانیم — سفارش pending می‌ماند
		WC()->cart->empty_cart();
		WC()->session->set( 'bpp_thankyou_note', 'صورتحساب در ربات بله برای شما ارسال شد. پس از پرداخت در ربات، سفارش به‌صورت خودکار تأیید می‌شود.' );

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}
}
