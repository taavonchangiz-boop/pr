<?php
/**
 * کلاس BPP_Report — گزارش دوره‌ای فروش به مدیر
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Report
 */
class BPP_Report {

	/**
	 * API.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API  $api     api.
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $api, $helpers ) {
		$this->api     = $api;
		$this->helpers = $helpers;
	}

	/**
	 * زمان‌بندی کرون.
	 */
	public function schedule() {
		wp_clear_scheduled_hook( 'bpp_report_cron' );
		$period = $this->helpers->get_setting( 'report_period', 'daily' );
		$interval = ( 'weekly' === $period ) ? WEEK_IN_SECONDS : DAY_IN_SECONDS;
		$offset   = $this->seconds_until( $this->helpers->get_setting( 'report_time', '08:00' ) );
		wp_schedule_event( time() + $offset, $period, 'bpp_report_cron' );
	}

	/**
	 * ثانیه تا ساعت مشخص (امروز یا فردا).
	 *
	 * @param string $hhmm ساعت.
	 * @return int
	 */
	private function seconds_until( $hhmm ) {
		$parts = explode( ':', $hhmm );
		$h = isset( $parts[0] ) ? (int) $parts[0] : 8;
		$m = isset( $parts[1] ) ? (int) $parts[1] : 0;
		$now = current_time( 'timestamp' );
		$target = strtotime( 'today ' . sprintf( '%02d:%02d', $h, $m ) );
		if ( $target <= $now ) {
			$target = strtotime( 'tomorrow ' . sprintf( '%02d:%02d', $h, $m ) );
		}
		return max( 60, $target - $now );
	}

	/**
	 * ارسال گزارش زمان‌بندی‌شده.
	 */
	public function send_scheduled_report() {
		$report = $this->build_report();
		$this->api_send( $report );
	}

	/**
	 * ارسال گزارش به همه مدیران.
	 *
	 * @param string $text متن.
	 */
	private function api_send( $text ) {
		foreach ( array( 'bale', 'telegram' ) as $platform ) {
			$admin_id = $this->helpers->get_admin_chat_id( $platform );
			if ( '' !== $admin_id ) {
				$this->api->send_message( $platform, $admin_id, $text );
			}
		}
	}

	/**
	 * ساخت متن گزارش.
	 *
	 * @return string
	 */
	public function build_report() {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];
		$period = ( 'weekly' === $this->helpers->get_setting( 'report_period', 'daily' ) ) ? 7 : 1;
		$since  = gmdate( 'Y-m-d H:i:s', time() - $period * DAY_IN_SECONDS );

		// شمارش سفارش‌ها — سازگار با HPOS و جدول posts
		$hpos = 'yes' === get_option( 'woocommerce_custom_orders_table_enabled', 'no' );
		if ( $hpos && $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}wc_orders'" ) ) {
			$orders_count = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}wc_orders WHERE date_created_gmt >= %s", $since )
			);
			$sum = (float) $wpdb->get_var(
				$wpdb->prepare( "SELECT COALESCE(SUM(o.total_amount),0) FROM {$wpdb->prefix}wc_orders o INNER JOIN {$table} t ON t.order_id = o.id WHERE t.decision = 'approve' AND t.created_at >= %s", $since )
			);
		} else {
			$orders_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->posts} p WHERE p.post_type = 'shop_order' AND p.post_date_gmt >= %s AND p.post_status NOT IN ('trash','auto-draft')",
					$since
				)
			);
			$sum = (float) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COALESCE(SUM(m.meta_value),0) FROM {$wpdb->postmeta} m INNER JOIN {$table} t ON t.order_id = m.post_id WHERE t.decision = 'approve' AND m.meta_key = '_order_total' AND t.created_at >= %s",
					$since
				)
			);
		}

		$approved = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE decision = 'approve' AND created_at >= %s", $since )
		);
		$pending = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = 'on-hold' AND transaction_type = 'verify' AND created_at >= %s", $since )
		);
		$wallet = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE transaction_type = 'wallet' AND created_at >= %s", $since )
		);

		$new_users = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered >= %s", gmdate( 'Y-m-d H:i:s', time() - $period * DAY_IN_SECONDS ) )
		);

		$period_fa = ( 7 === $period ) ? 'هفتهٔ گذشته' : 'امروز';
		$text  = "📊 گزارش فروش — " . $period_fa . "\n\n";
		$text .= "🛍 سفارش‌ها: " . $this->helpers->fa_num( $orders_count ) . "\n";
		$text .= "✅ تأییدشده: " . $this->helpers->fa_num( $approved ) . "\n";
		$text .= "📨 در انتظار تأیید: " . $this->helpers->fa_num( $pending ) . "\n";
		$text .= "💰 کیف پول: " . $this->helpers->fa_num( $wallet ) . "\n";
		$text .= "💵 جمع تأییدشده: " . $this->helpers->fa_money( $sum ) . " تومان\n";
		$text .= "👤 کاربر جدید: " . $this->helpers->fa_num( $new_users ) . "\n";
		$text .= "\n🕒 " . $this->helpers->to_jalali() . ' — ' . $this->helpers->fa_time();
		return $text;
	}

	/**
	 * آمار داشبورد.
	 *
	 * @return array
	 */
	public function dashboard_stats() {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];

		$today_start = gmdate( 'Y-m-d 00:00:00' );
		$stats = array(
			'today_orders'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", $today_start ) ),
			'today_approved'=> (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE decision = 'approve' AND created_at >= %s", $today_start ) ),
			'pending'       => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = 'on-hold' AND transaction_type = 'verify'" ) ),
			'wallet_total'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE transaction_type = 'wallet'" ) ),
			'bot_users'     => bpp()->bot_users->count_users(),
			'linked_users'  => (int) $wpdb->get_var( "SELECT COUNT(DISTINCT wp_user_id) FROM {$GLOBALS['bpp_tables']['bot_users']} WHERE wp_user_id IS NOT NULL" ),
		);
		return $stats;
	}
}
