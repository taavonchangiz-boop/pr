<?php
/**
 * کلاس BPP_Main — نقطهٔ اصلی راه‌اندازی
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Main
 */
final class BPP_Main {

	/**
	 * نمونه یکتا.
	 *
	 * @var BPP_Main|null
	 */
	private static $instance = null;

	/**
	 * نمونه‌ها.
	 *
	 * @var object[]
	 */
	public $helpers;
	public $api;
	public $bot_users;
	public $user_link;
	public $webhook;
	public $verification;
	public $notifications;
	public $receipt;
	public $report;
	public $sms;
	public $safir;
	public $wallet;
	public $ajax;
	public $admin;

	/**
	 * وضعیت.
	 *
	 * @var bool
	 */
	private $initialized = false;

	/**
	 * نمونه یکتا.
	 *
	 * @return BPP_Main
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * سازنده خصوصی.
	 */
	private function __construct() {
		global $wpdb;
		$GLOBALS['bpp_tables']['transactions'] = $wpdb->prefix . 'bpp_transactions';
		$GLOBALS['bpp_tables']['bot_users']    = $wpdb->prefix . 'bpp_bot_users';
		$GLOBALS['bpp_tables']['messages']     = $wpdb->prefix . 'bpp_messages';
		$GLOBALS['bpp_tables']['logs']         = $wpdb->prefix . 'bpp_logs';
	}

	/**
	 * راه‌اندازی.
	 */
	public function init() {
		if ( $this->initialized ) {
			return;
		}
		$this->initialized = true;

		$this->maybe_db_maintenance();

		// نمونه‌سازی
		$this->helpers      = new BPP_Helpers();
		$this->api          = new BPP_Bot_API( $this->helpers );
		$this->bot_users    = new BPP_Bot_Users( $this->helpers );
		$this->sms          = new BPP_SMS( $this->helpers );
		$this->safir        = new BPP_Safir( $this->helpers );
		$this->wallet       = new BPP_Wallet( $this->api, $this->helpers );
		$this->notifications= new BPP_Notifications( $this->api, $this->helpers, $this->sms, $this->safir );
		$this->verification = new BPP_Verification( $this->api, $this->helpers );
		$this->receipt      = new BPP_Receipt( $this->helpers );
		$this->user_link    = new BPP_User_Link( $this->api, $this->helpers );
		$this->report       = new BPP_Report( $this->api, $this->helpers );
		$this->webhook      = new BPP_Webhook( $this->api, $this->helpers );
		$this->ajax         = new BPP_Ajax( $this->helpers );

		// درگاه‌ها
		add_filter( 'woocommerce_payment_gateways', array( $this, 'register_gateways' ) );
		$this->require_gateways();

		// پنل مدیریت — کاملاً متن‌باز
		$this->admin = new BPP_Admin( $this );

		// هوک‌ها
		$this->ajax->register_hooks();
		$this->notifications->register_hooks();
		add_action( 'rest_api_init', array( $this->webhook, 'register_routes' ) );
		add_action( 'rest_api_init', array( $this->receipt, 'register_routes' ) );

		// کرون‌ها
		add_action( 'bpp_report_cron', array( $this->report, 'send_scheduled_report' ) );
		add_action( 'bpp_daily_maintenance', array( $this, 'daily_maintenance' ) );
		add_action( 'bpp_webhook_health', array( $this, 'webhook_health' ) );
		add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );

		// اگر کرون گزارش زمان‌بندی نشده، همین حالا زمان‌بندی کن
		if ( ! wp_next_scheduled( 'bpp_report_cron' ) ) {
			$this->report->schedule();
		}

		// فرانت‌اند
		add_action( 'woocommerce_after_my_account', array( $this->user_link, 'render_link_button' ) );
		add_action( 'woocommerce_thankyou_bpp_card', array( $this->receipt, 'render_form' ) );
		add_action( 'woocommerce_view_order', array( $this->receipt, 'render_form' ) );
		add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'thankyou_text' ), 10, 2 );

		// جاوااسکریپت فرانت
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_front' ) );

		// هشدارها
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );
	}

	/**
	 * نگهداری دیتابیس در صورت نیاز.
	 */
	private function maybe_db_maintenance() {
		global $wpdb;
		$tables = array( 'bpp_transactions', 'bpp_bot_users', 'bpp_messages', 'bpp_logs' );
		$missing = false;
		foreach ( $tables as $t ) {
			$full = $wpdb->prefix . $t;
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $full ) ) !== $full ) {
				$missing = true;
				break;
			}
		}
		if ( $missing || version_compare( (string) get_option( 'bpp_db_version', '0' ), BPP_DB_VERSION, '<' ) ) {
			BPP_Activator::create_tables();
			BPP_Activator::migrate();
		}
	}

	/**
	 * بارگذاری فایل‌های درگاه.
	 */
	private function require_gateways() {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}
		require_once BPP_PATH . 'includes/class-bpp-gateway-card.php';
		require_once BPP_PATH . 'includes/class-bpp-snapppay.php';
		require_once BPP_PATH . 'includes/class-bpp-digipay.php';
	}

	/**
	 * ثبت درگاه‌ها.
	 *
	 * @param array $gateways درگاه‌ها.
	 * @return array
	 */
	public function register_gateways( $gateways ) {
		$gateways[] = 'BPP_Gateway_Card';
		$gateways[] = 'BPP_Gateway_Wallet';
		$gateways[] = 'BPP_Gateway_SnappPay';
		$gateways[] = 'BPP_Gateway_DigiPay';
		return $gateways;
	}

	/**
	 * زمان‌بندی‌های سفارشی.
	 *
	 * @param array $schedules زمان‌ها.
	 * @return array
	 */
	public function cron_schedules( $schedules ) {
		$schedules['weekly'] = array(
			'interval' => WEEK_IN_SECONDS,
			'display'  => 'هفتگی',
		);
		return $schedules;
	}

	/**
	 * نگهداری روزانه — انقضای سفارش‌های معطل و یادآوری.
	 */
	public function daily_maintenance() {
		$this->expire_stale_orders();
		$this->remind_pending();
	}

	/**
	 * انقضای خودکار سفارش‌های پرداخت‌نشده.
	 */
	private function expire_stale_orders() {
		if ( 'yes' !== $this->helpers->get_setting( 'auto_expire_pending', 'no' ) ) {
			return;
		}
		$hours = (int) $this->helpers->get_setting( 'payment_deadline_hours', 2 );
		$cutoff = time() - $hours * HOUR_IN_SECONDS;

		$orders = wc_get_orders( array(
			'status'   => array( 'pending', 'on-hold' ),
			'limit'    => 50,
			'return'   => 'objects',
		) );
		foreach ( $orders as $order ) {
			if ( ! $this->helpers->is_card_order( $order->get_id() ) ) {
				continue;
			}
			$created = $order->get_date_created();
			if ( $created && $created->getTimestamp() < $cutoff ) {
				$order->update_status( 'cancelled', 'انقضای مهلت پرداخت (خودکار)' );
				$this->helpers->log( sprintf( 'Order #%d منقضی و لغو شد', $order->get_id() ), 'wa' );
			}
		}
	}

	/**
	 * یادآوری رسید به مشتریان on-hold.
	 */
	private function remind_pending() {
		$hours = (int) $this->helpers->get_setting( 'remind_pending_hours', 0 );
		if ( ! $hours ) {
			return;
		}
		$cutoff = time() - $hours * HOUR_IN_SECONDS;
		$orders = wc_get_orders( array(
			'status' => 'pending',
			'limit'  => 50,
			'return' => 'objects',
		) );
		foreach ( $orders as $order ) {
			if ( ! $this->helpers->is_card_order( $order->get_id() ) ) {
				continue;
			}
			$last = (int) $order->get_meta( '_bpp_reminded_at' );
			if ( $last && ( time() - $last ) < $hours * HOUR_IN_SECONDS ) {
				continue;
			}
			$created = $order->get_date_created();
			if ( ! $created || $created->getTimestamp() > $cutoff ) {
				continue;
			}
			$text = "⏰ یادآوری پرداخت سفارش #" . $this->helpers->fa_num( $order->get_id() ) . "\n" . $order->get_view_order_url();
			$this->notifications->notify_customer( $order, $text );
			$order->update_meta_data( '_bpp_reminded_at', time() );
			$order->save();
		}
	}

	/**
	 * سلامت وبهوک — ثبت مجدد خودکار اگر از بین رفته باشد.
	 */
	public function webhook_health() {
		foreach ( array( 'bale', 'telegram' ) as $platform ) {
			if ( '' === $this->helpers->get_token( $platform ) ) {
				continue;
			}
			$status = $this->webhook->webhook_status( $platform );
			if ( ! $status['ok'] ) {
				$this->webhook->register_webhook( $platform );
				$this->helpers->log( sprintf( '[health] webhook %s دوباره ثبت شد', $platform ), 'wa' );
			} elseif ( ! empty( $status['last_error'] ) ) {
				// خطای اخیر — لاگ کن
				$this->helpers->log( sprintf( '[health] webhook %s خطا: %s', $platform, $status['last_error'] ), 'wa' );
			}
		}
	}

	/**
	 * متن صفحه تشکر.
	 *
	 * @param string   $text  متن.
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	public function thankyou_text( $text, $order ) {
		$note = WC()->session ? WC()->session->get( 'bpp_thankyou_note' ) : '';
		if ( $note ) {
			return $note;
		}
		if ( $order && $this->helpers->is_card_order( $order->get_id() ) ) {
			return 'سفارش شما ثبت شد! لطفاً مبلغ را واریز و رسید را در زیر آپلود کنید.';
		}
		return $text;
	}

	/**
	 * جاوااسکریپت و استایل فرانت.
	 */
	public function enqueue_front() {
		wp_enqueue_style( 'bpp-front', BPP_URL . 'assets/css/front.css', array(), BPP_VERSION );
		wp_enqueue_script( 'bpp-front', BPP_URL . 'assets/js/front.js', array(), BPP_VERSION, true );
		wp_localize_script( 'bpp-front', 'BPP', array(
			'rest_url'  => rest_url( 'balepay-pro/v1/upload-receipt' ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
		) );
	}

	/**
	 * هشدارهای ادمین.
	 */
	public function admin_notices() {
		if ( ! current_user_can( 'manage_bpp' ) ) {
			return;
		}
		// ووکامرس
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-error"><p><strong>بله‌پی پرو:</strong> برای کارکرد به ووکامرس نیاز دارد.</p></div>';
			return;
		}
		// رمزنگاری
		if ( ! $this->helpers->has_crypto() ) {
			echo '<div class="notice notice-warning"><p><strong>بله‌پی پرو:</strong> افزونهٔ OpenSSL فعال نیست — توکن‌ها رمز نمی‌شوند!</p></div>';
		}
		// توکن ثبت نشده
		$bale = $this->helpers->get_token( 'bale' );
		$tg   = $this->helpers->get_token( 'telegram' );
		if ( '' === $bale && '' === $tg ) {
			echo '<div class="notice notice-warning"><p><strong>بله‌پی پرو:</strong> هنوز توکن رباتی ثبت نشده است. <a href="' . esc_url( admin_url( 'admin.php?page=balepay-pro' ) ) . '">به تنظیمات بروید</a>.</p></div>';
		}
		// آیدی مدیر
		if ( ( '' !== $bale && '' === $this->helpers->get_admin_chat_id( 'bale' ) ) || ( '' !== $tg && '' === $this->helpers->get_admin_chat_id( 'telegram' ) ) ) {
			echo '<div class="notice notice-warning"><p><strong>بله‌پی پرو:</strong> آیدی چت مدیر ثبت نشده — اعلان‌های تأیید پرداخت ارسال نمی‌شوند.</p></div>';
		}
	}
}
