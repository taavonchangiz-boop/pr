<?php
/**
 * کلاس BPP_SMS — ارسال پیامک (ملی پیامک) با TLS امن
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_SMS
 */
class BPP_SMS {

	/**
	 * آدرس API.
	 *
	 * @var string
	 */
	private $api_url = 'https://api.payamak-panel.com/post/Send.asmx/SendSimpleSMS2';

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * فعال؟
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return '' !== $this->helpers->get_setting( 'sms_username', '' )
			&& '' !== $this->helpers->get_secret( 'sms_password' )
			&& '' !== $this->helpers->get_setting( 'sms_from', '' );
	}

	/**
	 * ارسال.
	 *
	 * @param string $to   شماره گیرنده.
	 * @param string $text متن.
	 * @return array
	 */
	public function send( $to, $text ) {
		$to = $this->helpers->normalize_phone_intl( $to );
		if ( '' === $to || '' === trim( $text ) ) {
			return array( 'ok' => false, 'message' => 'شماره یا متن نامعتبر' );
		}

		$params = array(
			'username' => $this->helpers->get_setting( 'sms_username', '' ),
			'password' => $this->helpers->get_secret( 'sms_password' ),
			'from'     => $this->helpers->get_setting( 'sms_from', '' ),
			'to'       => $to,
			'text'     => mb_substr( $text, 0, 300, 'UTF-8' ),
			'isflash'  => $this->helpers->get_setting( 'sms_isflash', 0 ) ? 'true' : 'false',
		);
		$url = $this->api_url . '?' . http_build_query( $params );

		$resp = wp_remote_get( $url, array(
			'timeout'    => 20,
			'sslverify'  => 'yes' === $this->helpers->get_setting( 'tls_verify', 'yes' ),
		) );
		if ( is_wp_error( $resp ) ) {
			$this->helpers->log( '[sms] خطا: ' . $resp->get_error_message(), 'no' );
			return array( 'ok' => false, 'message' => $resp->get_error_message() );
		}
		$body = trim( wp_remote_retrieve_body( $resp ) );
		$ok   = ( '1' === $body || 'true' === strtolower( $body ) );
		if ( ! $ok ) {
			$this->helpers->log( '[sms] پاسخ ناموفق: ' . mb_substr( $body, 0, 120 ), 'wa' );
		}
		return array( 'ok' => $ok, 'message' => $ok ? 'ارسال شد' : 'پاسخ ناموفق از سرویس پیامک' );
	}
}
