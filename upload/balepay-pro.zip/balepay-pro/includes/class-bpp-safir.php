<?php
/**
 * کلاس BPP_Safir — ارسال پیام بله با شماره تلفن (Safir API)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Safir
 */
class BPP_Safir {

	/**
	 * آدرس API.
	 *
	 * @var string
	 */
	private $api_url = 'https://safir.bale.ai/api/v3/send_message';

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $helpers ) {
		$this->helpers = $helpers;
	}

	/**
	 * فعال؟
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return '' !== $this->helpers->get_secret( 'safir_access_key' )
			&& '' !== $this->helpers->get_setting( 'safir_bot_id', '' );
	}

	/**
	 * ارسال.
	 *
	 * @param string $phone شماره.
	 * @param string $text  متن.
	 * @return array
	 */
	public function send( $phone, $text ) {
		$phone = $this->helpers->normalize_phone_intl( $phone );
		if ( '' === $phone || '' === trim( $text ) ) {
			return array( 'ok' => false, 'message' => 'شماره یا متن نامعتبر' );
		}

		$body = array(
			'bot_id'       => (int) $this->helpers->get_setting( 'safir_bot_id', 0 ),
			'phone_number' => $phone,
			'text'         => mb_substr( $text, 0, 1000, 'UTF-8' ),
			'request_id'   => wp_generate_password( 32, false, false ),
		);

		$resp = wp_remote_post( $this->api_url, array(
			'body'      => wp_json_encode( $body ),
			'timeout'   => 20,
			'sslverify' => 'yes' === $this->helpers->get_setting( 'tls_verify', 'yes' ),
			'headers'   => array(
				'api-access-key' => $this->helpers->get_secret( 'safir_access_key' ),
				'Content-Type'   => 'application/json',
			),
		) );
		if ( is_wp_error( $resp ) ) {
			$this->helpers->log( '[safir] خطا: ' . $resp->get_error_message(), 'no' );
			return array( 'ok' => false, 'message' => $resp->get_error_message() );
		}
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );
		$ok   = is_array( $json ) && ! empty( $json['ok'] );
		if ( ! $ok ) {
			$this->helpers->log( '[safir] پاسخ ناموفق: ' . wp_json_encode( $json ), 'wa' );
		}
		return array( 'ok' => $ok, 'message' => $ok ? 'ارسال شد' : 'پاسخ ناموفق از سفیر' );
	}
}
