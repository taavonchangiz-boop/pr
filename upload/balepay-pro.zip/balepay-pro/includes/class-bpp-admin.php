<?php
/**
 * کلاس BPP_Admin — پنل مدیریت (کاملاً متن‌باز)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Admin
 */
class BPP_Admin {

	/**
	 * نمونه اصلی.
	 *
	 * @var BPP_Main
	 */
	private $main;

	/**
	 * سازنده.
	 *
	 * @param BPP_Main $main main.
	 */
	public function __construct( $main ) {
		$this->main = $main;
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * منو.
	 */
	public function menu() {
		add_menu_page(
			'بله‌پی پرو',
			'بله‌پی پرو',
			'manage_bpp',
			'balepay-pro',
			array( $this, 'render' ),
			'dashicons-money-alt',
			56
		);
	}

	/**
	 * دارایی‌ها.
	 *
	 * @param string $hook هوک.
	 */
	public function assets( $hook ) {
		if ( 'toplevel_page_balepay-pro' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'bpp-admin', BPP_URL . 'assets/css/admin.css', array(), BPP_VERSION );
		wp_enqueue_script( 'bpp-admin', BPP_URL . 'assets/js/admin.js', array( 'jquery' ), BPP_VERSION, true );
		wp_localize_script( 'bpp-admin', 'BPP', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'bpp_admin' ),
			'version'  => BPP_VERSION,
			'home_url' => home_url(),
		) );
	}

	/**
	 * رندر پنل.
	 */
	public function render() {
		if ( ! current_user_can( 'manage_bpp' ) ) {
			wp_die( 'دسترسی غیرمجاز' );
		}
		$helpers    = $this->main->helpers;
		$settings   = $helpers->get_settings();
		$webhook_url = rest_url( 'balepay-pro/v1/webhook' );

		// مقادیر نمایشی (جایگزین توکن واقعی با •••)
		$token_state = array(
			'bale'     => '' !== $helpers->get_token( 'bale' ) ? 'ذخیره شده' : 'خالی',
			'telegram' => '' !== $helpers->get_token( 'telegram' ) ? 'ذخیره شده' : 'خالی',
		);

		$cards = (array) $settings['cards'];

		include BPP_PATH . 'templates/admin-panel/main.php';
	}
}
