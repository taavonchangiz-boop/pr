<?php
/**
 * کلاس BPP_Wallet — پرداخت کیف پول بله (sendInvoice)
 *
 * بهبود: عدم تطابق مبلغ = رد پرداخت (نه فقط لاگ)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Wallet
 */
class BPP_Wallet {

	/**
	 * API.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API  $api     api.
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $api, $helpers ) {
		$this->api     = $api;
		$this->helpers = $helpers;
	}

	/**
	 * ارسال فاکتور برای سفارش.
	 *
	 * @param int         $order_id سفارش.
	 * @param WC_Order|null $order    سفارش.
	 * @return array
	 */
	public function send_invoice_for_order( $order_id, $order = null ) {
		if ( null === $order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return array( 'ok' => false, 'message' => 'سفارش یافت نشد' );
		}
		if ( ! $this->helpers->is_wallet_enabled() ) {
			return array( 'ok' => false, 'message' => 'کیف پول بله فعال نیست' );
		}

		$user_id = $order->get_user_id();
		$chat_id = $this->helpers->get_user_chat_id( $user_id, 'bale' );
		if ( '' === $chat_id ) {
			return array( 'ok' => false, 'message' => 'کاربر به ربات بله متصل نیست. از پنل کاربری اتصال دهید.' );
		}

		$total_rial = (int) round( (float) $order->get_total() * 10 ); // تومان → ریال
		$title      = mb_substr( 'سفارش #' . $order_id, 0, 32, 'UTF-8' );
		$desc       = mb_substr( $this->build_description( $order ), 0, 255, 'UTF-8' );
		$payload    = 'bpp_order_' . $order_id;

		$resp = $this->api->send_invoice(
			'bale',
			$chat_id,
			$title,
			$desc,
			$payload,
			$this->helpers->get_secret( 'wallet_provider_token' ),
			array( array( 'label' => $title, 'amount' => $total_rial ) )
		);

		if ( is_wp_error( $resp ) ) {
			$this->helpers->log( sprintf( 'Order #%d: wallet invoice FAILED — %s', $order_id, $resp->get_error_message() ), 'no' );
			return array( 'ok' => false, 'message' => $resp->get_error_message() );
		}
		$order->update_meta_data( '_bpp_wallet_invoice_sent', 1 );
		$order->save();
		$this->helpers->log( sprintf( 'Order #%d: wallet invoice sent (chat=%s, %d Rial)', $order_id, $chat_id, $total_rial ), 'ok' );
		return array( 'ok' => true, 'message' => 'صورتحساب ارسال شد' );
	}

	/**
	 * توضیح فاکتور.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	private function build_description( $order ) {
		$desc = '';
		$i    = 0;
		foreach ( $order->get_items() as $item ) {
			if ( $i >= 5 ) {
				$desc .= '...';
				break;
			}
			$desc .= $item->get_name() . ' × ' . $item->get_quantity() . '، ';
			$i++;
		}
		$desc = rtrim( $desc, '، ' );
		return '' !== $desc ? $desc : 'سفارش #' . $order->get_id();
	}

	/**
	 * پردازش PreCheckoutQuery.
	 *
	 * @param array $pre_checkout_query دیتا.
	 * @return bool
	 */
	public function handle_pre_checkout( $pre_checkout_query ) {
		$query_id = isset( $pre_checkout_query['id'] ) ? (string) $pre_checkout_query['id'] : '';
		$payload  = isset( $pre_checkout_query['invoice_payload'] ) ? (string) $pre_checkout_query['invoice_payload'] : '';

		$order_id = ( 0 === strpos( $payload, 'bpp_order_' ) ) ? (int) substr( $payload, 10 ) : 0;

		$ok    = true;
		$error = '';
		if ( ! $order_id ) {
			$ok    = false;
			$error = 'سفارش نامعتبر است';
		} else {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				$ok    = false;
				$error = 'سفارش یافت نشد';
			} elseif ( ! $order->needs_payment() ) {
				$ok    = false;
				$error = 'این سفارش قبلاً پرداخت شده است';
			}
		}

		$this->api->answer_pre_checkout( 'bale', $query_id, $ok, $error );
		$this->helpers->log( sprintf( 'PreCheckout %s → %s (order #%d)', $query_id, $ok ? 'OK' : 'REJECT: ' . $error, $order_id ), $ok ? 'ok' : 'no' );
		return $ok;
	}

	/**
	 * پردازش SuccessfulPayment — با بررسی سخت مبلغ.
	 *
	 * @param array  $successful_payment دیتا.
	 * @param array  $from               from.
	 * @param string $chat_id            چت.
	 * @return int|false
	 */
	public function handle_successful_payment( $successful_payment, $from = array(), $chat_id = '' ) {
		$payload      = isset( $successful_payment['invoice_payload'] ) ? (string) $successful_payment['invoice_payload'] : '';
		$total_amount = isset( $successful_payment['total_amount'] ) ? (int) $successful_payment['total_amount'] : 0;
		$charge_id    = isset( $successful_payment['telegram_payment_charge_id'] ) ? (string) $successful_payment['telegram_payment_charge_id'] : '';
		$provider_chg = isset( $successful_payment['provider_payment_charge_id'] ) ? (string) $successful_payment['provider_payment_charge_id'] : '';

		$order_id = ( 0 === strpos( $payload, 'bpp_order_' ) ) ? (int) substr( $payload, 10 ) : 0;
		if ( ! $order_id ) {
			$this->helpers->log( 'SuccessfulPayment با payload نامعتبر: ' . $payload, 'no' );
			return false;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}

		$expected_rial = (int) round( (float) $order->get_total() * 10 );

		// اصلاح امنیتی مهم: عدم تطابق مبلغ = رد و علامت‌گذاری
		if ( $total_amount !== $expected_rial ) {
			$this->helpers->log( sprintf( 'Order #%d: MISMATCH مبلغ (expected %d, got %d) — پرداخت مردود شد', $order_id, $expected_rial, $total_amount ), 'no' );
			$order->add_order_note( sprintf( 'هشدار امنیتی: مغایرت مبلغ کیف پول — مورد انتظار %d، دریافتی %d', $expected_rial, $total_amount ) );
			$order->update_meta_data( '_bpp_wallet_mismatch', $total_amount );
			$order->save();
			return false;
		}

		$order->update_meta_data( '_bpp_wallet_paid', 1 );
		$order->update_meta_data( '_bpp_wallet_charge_id', $charge_id );
		$order->update_meta_data( '_bpp_wallet_provider_charge', $provider_chg );
		$order->update_meta_data( '_transaction_id', $charge_id );
		$order->save();

		$new_status = $this->helpers->get_setting( 'status_after_approve', 'processing' );
		$order->update_status( $new_status, 'پرداخت کیف پول بله موفق — شناسه: ' . $charge_id );
		$order->payment_complete( $charge_id );

		if ( function_exists( 'wc_reduce_stock_levels' ) ) {
			wc_reduce_stock_levels( $order_id );
		}

		$this->save_transaction( $order, $charge_id, $provider_chg );

		// اطلاع به مشتری و مدیر
		$msg = "✅ پرداخت کیف پول موفق شد!\n\n📋 سفارش: #" . $this->helpers->fa_num( $order_id ) . "\n💵 مبلغ: " . $this->helpers->fa_money( $order->get_total() ) . " تومان\n🔗 " . $order->get_view_order_url();
		bpp()->notifications->notify_customer( $order, $msg );

		$admin_msg  = "💰 پرداخت کیف پول بله موفق\n\n";
		$admin_msg .= "📋 سفارش: #" . $this->helpers->fa_num( $order_id ) . "\n";
		$admin_msg .= "💵 مبلغ: " . $this->helpers->fa_money( $order->get_total() ) . " تومان\n";
		$admin_msg .= "🔑 شناسه: " . $charge_id . "\n";
		$admin_msg .= "👤 مشتری: " . trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		bpp()->notifications->send_to_admins( $admin_msg );

		if ( ! empty( $from['id'] ) ) {
			bpp()->bot_users->save_user( $from, 'bale', $chat_id ? $chat_id : (string) $from['id'] );
		}

		$this->helpers->log( sprintf( 'Order #%d: wallet payment success (charge=%s)', $order_id, $charge_id ), 'ok' );
		return $order_id;
	}

	/**
	 * ذخیره تراکنش.
	 *
	 * @param WC_Order $order        سفارش.
	 * @param string   $charge_id    شناسه.
	 * @param string   $provider_chg پیگیری.
	 */
	private function save_transaction( $order, $charge_id, $provider_chg ) {
		global $wpdb;
		$table = $GLOBALS['bpp_tables']['transactions'];
		$order_id = $order->get_id();
		$user_id  = $order->get_user_id();

		$wpdb->delete( $table, array( 'order_id' => $order_id, 'transaction_type' => 'wallet' ), array( '%d', '%s' ) );
		$wpdb->insert(
			$table,
			array(
				'order_id'         => $order_id,
				'user_id'          => $user_id ? $user_id : null,
				'platform'         => 'bale',
				'transaction_type' => 'wallet',
				'status'           => 'processing',
				'decision'         => 'approve',
				'amount'           => (int) round( (float) $order->get_total() * 10 ),
				'tracking_code'    => $charge_id,
				'receipt_note'     => 'کیف پول بله — پیگیری: ' . $provider_chg,
				'created_at'       => current_time( 'mysql' ),
				'updated_at'       => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);
	}
}
