<?php
/**
 * درگاه دیجی‌پی — API + گیت‌وی (با TLS امن و توکن‌های رمز)
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاینت API دیجی‌پی.
 */
class BPP_DigiPay_API {

	/**
	 * live یا sandbox؟
	 *
	 * @var bool
	 */
	private $live = true;

	/**
	 * نوع تراکنش (اقساط).
	 *
	 * @var string
	 */
	private $type = '11';

	/**
	 * توکن‌ها.
	 *
	 * @var array
	 */
	private $tokens = array( 'access_token' => '', 'refresh_token' => '' );

	/**
	 * سازنده.
	 */
	public function __construct() {
		$tokens = get_option( 'bpp_digipay_tokens', array() );
		if ( is_array( $tokens ) ) {
			$this->tokens = array_merge( $this->tokens, $tokens );
		}
	}

	/**
	 * URL پایه.
	 *
	 * @return string
	 */
	private function base() {
		return $this->live ? 'https://api.mydigipay.com/digipay/api/' : 'https://uat.mydigipay.info/digipay/api/';
	}

	/**
	 * درخواست عمومی.
	 *
	 * @param string $endpoint نقطه.
	 * @param array  $data     داده.
	 * @param bool   $auth     با Bearer؟
	 * @param bool   $json     JSON؟
	 * @return array|WP_Error
	 */
	private function request( $endpoint, $data = array(), $auth = false, $json = true ) {
		$h = bpp()->helpers;
		$headers = array(
			'Content-Type'    => $json ? 'application/json' : 'application/x-www-form-urlencoded; charset=utf-8',
			'Agent'           => 'WEB',
			'Digipay-Version' => '2022-02-02',
			'Plugin-Version'  => BPP_VERSION,
		);
		if ( $auth ) {
			$headers['Authorization'] = 'Bearer ' . $this->tokens['access_token'];
		}
		$resp = wp_remote_post( $this->base() . $endpoint, array(
			'body'      => $json ? wp_json_encode( $data ) : http_build_query( $data ),
			'headers'   => $headers,
			'timeout'   => 30,
			'sslverify' => 'yes' === $h->get_setting( 'tls_verify', 'yes' ),
		) );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$body = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( 401 === $code && $auth ) {
			$this->tokens['access_token'] = '';
			update_option( 'bpp_digipay_tokens', $this->tokens, false );
			return new WP_Error( 'bpp_dp_401', 'توکن دیجی‌پی منقضی شد' );
		}
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'bpp_dp_badjson', 'پاسخ نامعتبر دیجی‌پی (HTTP ' . $code . ')' );
		}
		return $body;
	}

	/**
	 * احراز هویت.
	 *
	 * @return bool|WP_Error
	 */
	public function authenticate() {
		$h = bpp()->helpers;
		$use_refresh = '' !== $this->tokens['refresh_token'];
		$data = $use_refresh
			? array( 'refresh_token' => $this->tokens['refresh_token'], 'grant_type' => 'refresh_token' )
			: array(
				'username'   => $h->get_secret( 'digipay_username' ),
				'password'   => $h->get_secret( 'digipay_password' ),
				'grant_type' => 'password',
			);
		$basic = 'Basic ' . base64_encode( $h->get_secret( 'digipay_client_id' ) . ':' . $h->get_secret( 'digipay_client_secret' ) );

		$resp = wp_remote_post( $this->base() . 'oauth/token', array(
			'body'      => http_build_query( $data ),
			'headers'   => array(
				'Authorization' => $basic,
				'Content-Type'  => 'application/x-www-form-urlencoded; charset=utf-8',
			),
			'timeout'   => 30,
			'sslverify' => 'yes' === $h->get_setting( 'tls_verify', 'yes' ),
		) );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( empty( $json['access_token'] ) ) {
			$msg = isset( $json['result']['message'] ) ? $json['result']['message'] : 'خطای احراز هویت دیجی‌پی';
			return new WP_Error( 'bpp_dp_auth', $msg );
		}
		$this->tokens = array(
			'access_token'  => $json['access_token'],
			'refresh_token' => isset( $json['refresh_token'] ) ? $json['refresh_token'] : '',
		);
		update_option( 'bpp_digipay_tokens', $this->tokens, false );
		return true;
	}

	/**
	 * ساخت بلیت پرداخت.
	 *
	 * @param WC_Order $order سفارش.
	 * @return array|WP_Error
	 */
	public function create_ticket( $order ) {
		if ( '' === $this->tokens['access_token'] ) {
			$r = $this->authenticate();
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$h = bpp()->helpers;
		$order_id = $order->get_id();
		$callback = add_query_arg(
			array( 'wc_order' => $order_id, 'gateway' => 'digipay' ),
			WC()->api_request_url( 'bpp_digipay' )
		);
		$amount = $h->amount_to_irr( $order->get_total(), $order->get_currency() );

		$items = array();
		foreach ( $order->get_items() as $item ) {
			$items[] = array(
				'sellerId'    => 1,
				'supplierId'  => 1,
				'productCode' => (string) $item->get_product_id(),
				'productType' => 1,
				'count'       => $item->get_quantity(),
				'categoryId'  => '0',
			);
		}
		if ( empty( $items ) ) {
			$items[] = array(
				'sellerId'    => 1,
				'supplierId'  => 1,
				'productCode' => (string) $order_id,
				'productType' => 1,
				'count'       => 1,
				'categoryId'  => '0',
			);
		}

		$mobile = $h->normalize_mobile( $order->get_billing_phone() );
		$data = array(
			'amount'         => $amount,
			'cellNumber'     => '' !== $mobile ? '98' . substr( $mobile, 1 ) : null,
			'providerId'     => $order_id,
			'callbackUrl'    => $callback,
			'basketDetailsDto' => array(
				'basketId' => $order_id,
				'items'    => $items,
			),
		);
		$resp = $this->request( 'tickets/business?type=' . $this->type, $data, true, true );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		if ( empty( $resp['result'] ) || 0 !== (int) $resp['result']['status'] ) {
			$msg = isset( $resp['result']['message'] ) ? $resp['result']['message'] : 'خطای ساخت بلیت دیجی‌پی';
			return new WP_Error( 'bpp_dp_ticket', $msg );
		}
		return $resp;
	}

	/**
	 * تأیید تراکنش.
	 *
	 * @param string $tracking_code کد رهگیری.
	 * @param int    $order_id      سفارش.
	 * @param string $type          نوع.
	 * @return bool|WP_Error
	 */
	public function verify( $tracking_code, $order_id, $type = '0' ) {
		if ( '' === $this->tokens['access_token'] ) {
			$r = $this->authenticate();
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		for ( $i = 0; $i < 3; $i++ ) {
			$resp = $this->request(
				'purchases/verify?type=' . $type,
				array( 'trackingCode' => $tracking_code, 'providerId' => $order_id ),
				true,
				true
			);
			if ( is_wp_error( $resp ) ) {
				return $resp;
			}
			$status = isset( $resp['result']['status'] ) ? (int) $resp['result']['status'] : -1;
			if ( 0 === $status ) {
				return true;
			}
			if ( 9011 === $status ) {
				sleep( 2 );
				continue;
			}
			$msg = isset( $resp['result']['message'] ) ? $resp['result']['message'] : 'تأیید ناموفق';
			return new WP_Error( 'bpp_dp_verify', $msg );
		}
		return new WP_Error( 'bpp_dp_verify_timeout', 'تأیید دیجی‌پی پس از چند بار تلاش ناموفق بود' );
	}

	/**
	 * بازگشت وجه.
	 *
	 * @param int    $amount     مبلغ ریال.
	 * @param int    $order_id   سفارش.
	 * @param string $tracking   کد.
	 * @param string $type       نوع.
	 * @return bool|WP_Error
	 */
	public function refund( $amount, $order_id, $tracking, $type = '0' ) {
		if ( '' === $this->tokens['access_token'] ) {
			$r = $this->authenticate();
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$resp = $this->request(
			'refunds?type=' . $type,
			array(
				'amount'           => $amount,
				'providerId'       => $order_id,
				'saleTrackingCode' => $tracking,
			),
			true,
			true
		);
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		if ( ! empty( $resp['result'] ) && 0 === (int) $resp['result']['status'] ) {
			return true;
		}
		$msg = isset( $resp['result']['message'] ) ? $resp['result']['message'] : 'بازگشت وجه ناموفق';
		return new WP_Error( 'bpp_dp_refund', $msg );
	}
}

/**
 * گیت‌وی دیجی‌پی.
 */
class BPP_Gateway_DigiPay extends WC_Payment_Gateway {

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->id                 = 'bpp_digipay';
		$this->has_fields         = false;
		$this->method_title       = 'بله‌پی پرو (دیجی‌پی)';
		$this->method_description = 'پرداخت اقساطی ۴ قسطی دیجی‌پی';
		$this->supports           = array( 'products', 'refunds' );

		$helpers = bpp()->helpers;
		if ( null === $helpers ) {
			$this->enabled = 'no';
			return;
		}
		$this->title       = $helpers->get_setting( 'digipay_title', 'دیجی‌پی (۴ قسط)' );
		$this->description = $helpers->get_setting( 'digipay_description', '' );
		$this->enabled     = $helpers->is_digipay_enabled() ? 'yes' : 'no';

		$this->init_form_fields();
		$this->init_settings();
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
		add_action( 'woocommerce_api_bpp_digipay', array( $this, 'callback' ) );
	}

	/**
	 * فرم خلاصه.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => 'فعال‌سازی',
				'type'    => 'checkbox',
				'label'   => 'فعال‌سازی دیجی‌پی',
				'default' => 'no',
			),
			'notice'  => array(
				'type'        => 'title',
				'description' => 'اعتبارنامه‌های دیجی‌پی در «بله‌پی پرو ← تنظیمات» (رمزنگاری‌شده) ذخیره می‌شوند.',
			),
		);
	}

	/**
	 * فرستادن به صفحه پرداخت.
	 *
	 * @param int $order_id سفارش.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$order->update_meta_data( '_bpp_payment_method', 'digipay' );
		$order->save();
		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		);
	}

	/**
	 * صفحه پرداخت.
	 *
	 * @param int $order_id سفارش.
	 */
	public function receipt_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		echo '<div style="text-align:center;padding:30px">';
		echo '<p>' . esc_html__( 'در حال انتقال به درگاه دیجی‌پی…', 'balepay-pro' ) . '</p>';
		echo '<a class="button alt" href="' . esc_url( add_query_arg( 'bpp_go', '1' ) ) . '">' . esc_html__( 'پرداخت با دیجی‌پی', 'balepay-pro' ) . '</a>';
		echo '</div>';

		if ( ! isset( $_GET['bpp_go'] ) ) { // phpcs:ignore
			return;
		}
		$api  = new BPP_DigiPay_API();
		$resp = $api->create_ticket( $order );
		if ( is_wp_error( $resp ) ) {
			$order->add_order_note( 'خطای دیجی‌پی: ' . $resp->get_error_message() );
			wc_add_notice( 'خطا در اتصال به دیجی‌پی: ' . $resp->get_error_message(), 'error' );
			return;
		}
		$order->update_meta_data( '_bpp_dp_ticket', isset( $resp['ticket'] ) ? $resp['ticket'] : '' );
		$order->save();
		echo '<script>window.location.href=' . wp_json_encode( $resp['redirectUrl'] ) . ';</script>';
	}

	/**
	 * بازگشت از درگاه.
	 */
	public function callback() {
		$order_id = isset( $_GET['wc_order'] ) ? absint( $_GET['wc_order'] ) : 0; // phpcs:ignore
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		if ( ! $order->needs_payment() ) {
			wp_safe_redirect( $this->get_return_url( $order ) );
			exit;
		}

		$result        = isset( $_POST['result'] ) ? sanitize_text_field( wp_unslash( $_POST['result'] ) ) : ''; // phpcs:ignore
		$amount        = isset( $_POST['amount'] ) ? (int) $_POST['amount'] : 0; // phpcs:ignore
		$tracking_code = isset( $_POST['trackingCode'] ) ? sanitize_text_field( wp_unslash( $_POST['trackingCode'] ) ) : ''; // phpcs:ignore
		$type          = isset( $_POST['type'] ) && '' !== $_POST['type'] ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '0'; // phpcs:ignore

		if ( 'SUCCESS' !== $result ) {
			$order->update_status( 'failed', 'پرداخت دیجی‌پی ناموفق' );
			wc_add_notice( 'پرداخت دیجی‌پی ناموفق بود.', 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}

		$expected = bpp()->helpers->amount_to_irr( $order->get_total(), $order->get_currency() );
		if ( $amount !== $expected ) {
			$order->add_order_note( sprintf( 'مغایرت مبلغ دیجی‌پی: پرداختی %d، انتظار %d', $amount, $expected ) );
			wc_add_notice( 'مبلغ پرداختی با مبلغ سفارش مطابقت ندارد.', 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}

		$api = new BPP_DigiPay_API();
		$verify = $api->verify( $tracking_code, $order_id, $type );
		if ( is_wp_error( $verify ) || true !== $verify ) {
			$msg = is_wp_error( $verify ) ? $verify->get_error_message() : 'تأیید ناموفق';
			$order->update_status( 'failed', 'تأیید دیجی‌پی: ' . $msg );
			wc_add_notice( 'خطا در تأیید پرداخت: ' . $msg, 'error' );
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}

		$order->update_meta_data( '_transaction_id', $tracking_code );
		$order->update_meta_data( '_bpp_dp_tracking', $tracking_code );
		$order->update_meta_data( '_bpp_dp_type', $type );
		$order->save();
		$order->payment_complete( $tracking_code );
		$order->add_order_note( 'پرداخت دیجی‌پی تأیید شد. کد رهگیری: ' . $tracking_code );
		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}
		wc_add_notice( bpp()->helpers->get_setting( 'digipay_success_message', 'پرداخت با موفقیت انجام شد.' ), 'success' );
		wp_safe_redirect( $this->get_return_url( $order ) );
		exit;
	}

	/**
	 * بازگشت وجه.
	 *
	 * @param int    $order_id سفارش.
	 * @param float  $amount   مبلغ.
	 * @param string $reason   دلیل.
	 * @return bool|WP_Error
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_Error( 'no_order', 'سفارش یافت نشد' );
		}
		$tracking = $order->get_meta( '_bpp_dp_tracking' );
		if ( ! $tracking ) {
			return new WP_Error( 'no_tracking', 'کد رهگیری دیجی‌پی موجود نیست' );
		}
		$type = $order->get_meta( '_bpp_dp_type' );
		$type = $type ? $type : '0';
		$rial = bpp()->helpers->amount_to_irr( $amount, $order->get_currency() );
		$api  = new BPP_DigiPay_API();
		$r    = $api->refund( $rial, $order_id, $tracking, $type );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$order->add_order_note( 'بازگشت وجه دیجی‌پی انجام شد.' );
		return true;
	}
}
