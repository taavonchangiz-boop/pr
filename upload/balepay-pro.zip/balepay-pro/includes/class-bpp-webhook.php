<?php
/**
 * کلاس BPP_Webhook — دریافت آپدیت‌های بله/تلگرام
 *
 * بهبودهای امنیتی نسبت به نسخهٔ اصلی:
 *  - secret فقط از هدر خوانده می‌شود (X-Telegram-Bot-Api-Secret-Token / X-Bale-Secret)؛
 *    query param فقط برای بله به‌عنوان fallback
 *  - callback_data امضاشده با HMAC → قابل جعل نیست
 *  - تأیید/رد فقط از چت مدیر پذیرفته می‌شود
 *  - رهگیری سفارش فقط برای مالک تأییدشده یا مدیر
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BPP_Webhook
 */
class BPP_Webhook {

	/**
	 * نمونه‌ها.
	 *
	 * @var BPP_Bot_API
	 */
	private $api;

	/**
	 * helpers.
	 *
	 * @var BPP_Helpers
	 */
	private $helpers;

	/**
	 * سازنده.
	 *
	 * @param BPP_Bot_API  $api     api.
	 * @param BPP_Helpers $helpers helpers.
	 */
	public function __construct( $api, $helpers ) {
		$this->api     = $api;
		$this->helpers = $helpers;
	}

	/**
	 * ثبت مسیرهای REST.
	 */
	public function register_routes() {
		register_rest_route(
			'balepay-pro/v1',
			'/webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	/**
	 * احراز هویت وبهوک.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return bool
	 */
	public function permission( $request ) {
		$secret = (string) $this->helpers->get_setting( 'webhook_secret', '' );
		if ( '' === $secret ) {
			return false;
		}

		// ۱) هدر تلگرام
		$provided = isset( $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ) )
			: '';
		// ۲) هدر بله
		if ( '' === $provided && isset( $_SERVER['HTTP_X_BALE_SECRET'] ) ) {
			$provided = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_BALE_SECRET'] ) );
		}
		// ۳) fallback فقط برای بله (query) — با هشدار
		if ( '' === $provided ) {
			$platform_hint = (string) $request->get_param( 'platform' );
			if ( 'bale' === $platform_hint ) {
				$provided = (string) $request->get_param( 'secret' );
				$this->helpers->log( 'Webhook با secret در query-string دریافت شد — توصیه: فقط از هدر استفاده کنید.', 'wa' );
			}
		}

		return '' !== $provided && hash_equals( $secret, $provided );
	}

	/**
	 * پردازش آپدیت.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public function handle( $request ) {
		$body = $request->get_body();
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid json' ), 400 );
		}

		$platform = (string) $request->get_param( 'platform' );
		if ( ! $this->api->valid_platform( $platform ) ) {
			$platform = $this->detect_platform();
		}
		if ( ! $this->api->valid_platform( $platform ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'unknown platform' ), 400 );
		}

		if ( ! empty( $data['callback_query'] ) ) {
			$this->process_callback( $data['callback_query'], $platform );
		}
		if ( ! empty( $data['pre_checkout_query'] ) ) {
			$wallet = bpp()->wallet;
			if ( $wallet ) {
				$wallet->handle_pre_checkout( $data['pre_checkout_query'] );
			}
		}
		if ( ! empty( $data['message'] ) ) {
			$this->process_message( $data['message'], $platform );
		} else {
			// ذخیره کاربر از callback
			$from = ! empty( $data['callback_query']['from'] ) ? $data['callback_query']['from'] : array();
			if ( ! empty( $from['id'] ) ) {
				$cb_chat = ! empty( $data['callback_query']['message']['chat']['id'] )
					? (string) $data['callback_query']['message']['chat']['id']
					: (string) $from['id'];
				bpp()->bot_users->save_user( $from, $platform, $cb_chat );
			}
		}

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * تشخیص پلتفرم.
	 *
	 * @return string
	 */
	private function detect_platform() {
		$bale = $this->helpers->get_token( 'bale' );
		$tg   = $this->helpers->get_token( 'telegram' );
		if ( '' !== $bale && '' === $tg ) {
			return 'bale';
		}
		if ( '' === $bale && '' !== $tg ) {
			return 'telegram';
		}
		return $bale ? 'bale' : '';
	}

	/**
	 * ساخت URL وبهوک — بدون secret در query (secret در هدر/ثبت).
	 *
	 * @return string
	 */
	public function get_webhook_url() {
		return rest_url( 'balepay-pro/v1/webhook' );
	}

	/**
	 * ثبت وبهوک در سرور ربات.
	 *
	 * تلگرام: secret در هدر (secret_token) — امن
	 * بله: چون هدر secret پشتیبانی نمی‌شود، secret در URL قرار می‌گیرد (با هشدار)
	 *
	 * @param string $platform بله|تلگرام.
	 * @return array ['ok'=>bool,'message'=>string]
	 */
	public function register_webhook( $platform ) {
		$url = $this->get_webhook_url() . '?platform=' . $platform;

		if ( 'bale' === $platform ) {
			$secret = (string) $this->helpers->get_setting( 'webhook_secret', '' );
			$url   .= '&secret=' . rawurlencode( $secret );
			$this->helpers->log( '[webhook] بله هدر secret پشتیبانی نمی‌کند — secret در URL قرار گرفت. توصیه: HTTPS فعال باشد.', 'wa' );
		}

		$resp = $this->api->set_webhook( $platform, $url );
		if ( is_wp_error( $resp ) ) {
			$this->helpers->log( sprintf( '[webhook] %s register FAILED: %s', $platform, $resp->get_error_message() ), 'no' );
			return array( 'ok' => false, 'message' => $resp->get_error_message() );
		}
		$this->helpers->log( sprintf( '[webhook] %s registered', $platform ), 'ok' );
		return array( 'ok' => true, 'message' => 'Webhook با موفقیت ثبت شد' );
	}

	/**
	 * وضعیت وبهوک.
	 *
	 * @param string $platform پلتفرم.
	 * @return array
	 */
	public function webhook_status( $platform ) {
		$resp = $this->api->get_webhook_info( $platform );
		if ( is_wp_error( $resp ) ) {
			return array( 'ok' => false, 'message' => $resp->get_error_message() );
		}
		$r = isset( $resp['result'] ) ? $resp['result'] : array();
		if ( empty( $r['url'] ) ) {
			return array( 'ok' => false, 'message' => 'Webhook ثبت نشده است.' );
		}
		$pending = isset( $r['pending_update_count'] ) ? (int) $r['pending_update_count'] : 0;
		$last_error = isset( $r['last_error_message'] ) && $r['last_error_message'] ? $r['last_error_message'] : '';
		return array(
			'ok'             => true,
			'url'            => $r['url'],
			'pending'        => $pending,
			'last_error'     => $last_error,
			'healthy'        => '' === $last_error && $pending < 50,
			'message'        => $last_error ? 'خطای اخیر: ' . $last_error : ( $pending > 0 ? 'در صف: ' . $pending . ' آپدیت' : 'سالم' ),
		);
	}

	/**
	 * پردازش callback (دکمه‌های تأیید/رد/undo).
	 *
	 * @param array  $callback_query دیتای callback.
	 * @param string $platform       پلتفرم.
	 */
	private function process_callback( $callback_query, $platform ) {
		$data_str = isset( $callback_query['data'] ) ? (string) $callback_query['data'] : '';
		$cb_id    = isset( $callback_query['id'] ) ? (string) $callback_query['id'] : '';
		$from     = isset( $callback_query['from'] ) ? $callback_query['from'] : array();
		$chat_id  = isset( $callback_query['message']['chat']['id'] ) ? (string) $callback_query['message']['chat']['id'] : '';
		$msg_id   = isset( $callback_query['message']['message_id'] ) ? (string) $callback_query['message']['message_id'] : '';

		if ( '' === $data_str || '' === $chat_id ) {
			return;
		}

		// فرمت جدید: bpp:{order}:{action}:{expires}:{sig}
		$parts = explode( ':', $data_str );
		if ( count( $parts ) < 5 || 'bpp' !== $parts[0] ) {
			$this->helpers->log( sprintf( 'Callback با فرمت نامعتبر: %s', mb_substr( $data_str, 0, 80 ) ), 'wa' );
			return;
		}
		$order_id = (int) $parts[1];
		$action   = $parts[2];
		$expires  = (int) $parts[3];
		$sig      = $parts[4];

		// بررسی امضا
		$expected = $this->helpers->sign( "cb:{$order_id}:{$action}:{$expires}:{$platform}" );
		if ( ! hash_equals( $expected, $sig ) ) {
			$this->helpers->log( sprintf( 'Callback با امضای نامعتبر: %s', mb_substr( $data_str, 0, 80 ) ), 'no' );
			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '❌ درخواست نامعتبر' );
			}
			return;
		}
		if ( $expires > 0 && time() > $expires ) {
			$this->api->answer_callback( $platform, $cb_id, '⏰ این دکمه منقضی شده است' );
			return;
		}

		// فقط مدیر می‌تواند تأیید/رد کند — مهم‌ترین اصلاح امنیتی
		if ( ! $this->helpers->is_admin_chat( $platform, $chat_id ) ) {
			$this->helpers->log( sprintf( 'تلاش غیرمجاز %s روی سفارش #%d از چت %s (%s)', $action, $order_id, $chat_id, $platform ), 'no' );
			if ( '' !== $cb_id ) {
				$this->api->answer_callback( $platform, $cb_id, '⛔ فقط مدیر مجاز است' );
			}
			return;
		}

		if ( 'undo' === $action ) {
			bpp()->verification->process_undo( $order_id, $platform, $chat_id, $msg_id, $cb_id );
			return;
		}
		if ( in_array( $action, array( 'approve', 'reject' ), true ) ) {
			bpp()->verification->process_verification( $order_id, $action, $platform, $chat_id, $msg_id, $cb_id );
		}
	}

	/**
	 * پردازش پیام متنی.
	 *
	 * @param array  $message  پیام.
	 * @param string $platform پلتفرم.
	 */
	private function process_message( $message, $platform ) {
		$text    = isset( $message['text'] ) ? (string) $message['text'] : '';
		$from    = isset( $message['from'] ) ? $message['from'] : array();
		$chat_id = isset( $message['chat']['id'] ) ? (string) $message['chat']['id'] : '';
		$msg_id  = isset( $message['message_id'] ) ? (string) $message['message_id'] : '';

		// پرداخت موفق کیف پول
		if ( ! empty( $message['successful_payment'] ) ) {
			$wallet = bpp()->wallet;
			if ( $wallet ) {
				$wallet->handle_successful_payment( $message['successful_payment'], $from, $chat_id );
			}
			return;
		}

		if ( '' === $chat_id || empty( $from['id'] ) ) {
			return;
		}
		if ( bpp()->bot_users->is_blocked( $chat_id, $platform ) ) {
			return;
		}

		$bot_user_id = bpp()->bot_users->save_user( $from, $platform, $chat_id );

		// ذخیره پیام دریافتی
		$type     = 'text';
		$content  = $text;
		$file_url = '';
		if ( empty( $text ) && ! empty( $message['photo'] ) ) {
			$type    = 'photo';
			$content = isset( $message['caption'] ) ? (string) $message['caption'] : '';
			$photos  = $message['photo'];
			$largest = end( $photos );
			if ( ! empty( $largest['file_id'] ) ) {
				$f = $this->api->get_file( $platform, $largest['file_id'] );
				if ( ! is_wp_error( $f ) && ! empty( $f['url'] ) ) {
					$file_url = $f['url'];
				}
			}
		}
		bpp()->bot_users->save_message( $bot_user_id, $chat_id, $platform, 'in', $type, $content, $file_url );

		// /start با کد اتصال
		if ( 0 === strpos( $text, '/start BLP-' ) ) {
			bpp()->user_link->handle_start( $text, $from, $chat_id, $platform );
			return;
		}

		$cmd = trim( $text );

		// /start
		if ( '/start' === $cmd ) {
			$welcome = $this->helpers->get_setting( 'msg_welcome', "🤖 خوش آمدید!" );
			$this->api->send_message( $platform, $chat_id, $welcome );
			bpp()->bot_users->save_message( $bot_user_id, $chat_id, $platform, 'out', 'text', $welcome );
			return;
		}

		// /help
		if ( '/help' === $cmd ) {
			$help = $this->helpers->get_setting( 'msg_help', "📋 راهنما" );
			$this->api->send_message( $platform, $chat_id, $help );
			bpp()->bot_users->save_message( $bot_user_id, $chat_id, $platform, 'out', 'text', $help );
			return;
		}

		// رهگیری سفارش — فقط مالک تأییدشده یا مدیر (رفع IDOR)
		$order_id = $this->parse_order_id( $cmd );
		if ( false !== $order_id ) {
			$this->track_order( $order_id, $chat_id, $platform, $bot_user_id, $msg_id );
		}
	}

	/**
	 * استخراج شماره سفارش از متن.
	 *
	 * @param string $text متن.
	 * @return int|false
	 */
	private function parse_order_id( $text ) {
		if ( 0 === strpos( $text, '#' ) ) {
			$text = substr( $text, 1 );
		}
		$fa  = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$en  = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$text = str_replace( $fa, $en, trim( $text ) );
		if ( ctype_digit( $text ) && strlen( $text ) <= 10 ) {
			return (int) $text;
		}
		return false;
	}

	/**
	 * رهگیری امن سفارش.
	 *
	 * @param int    $order_id   سفارش.
	 * @param string $chat_id    چت.
	 * @param string $platform   پلتفرم.
	 * @param int    $bot_user_id کاربر ربات.
	 * @param string $msg_id     آیدی پیام.
	 */
	private function track_order( $order_id, $chat_id, $platform, $bot_user_id, $msg_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			$this->api->send_message( $platform, $chat_id, "❌ سفارش #{$order_id} یافت نشد." );
			return;
		}

		// احراز مالکیت: چت باید به کاربرِ صاحبِ سفارش متصل باشد، یا مدیر باشد
		$linked_user = bpp()->bot_users->get_wp_user_by_chat( $chat_id, $platform );
		$is_owner    = $linked_user && (int) $linked_user === (int) $order->get_user_id();
		$is_admin    = $this->helpers->is_admin_chat( $platform, $chat_id );
		$require_verified = 'yes' === $this->helpers->get_setting( 'require_verified_link', 'yes' );

		if ( $require_verified && ! $is_owner && ! $is_admin ) {
			$this->helpers->log( sprintf( 'رد رهگیری سفارش #%d برای چت غیرمجاز %s (%s)', $order_id, $chat_id, $platform ), 'wa' );
			$this->api->send_message(
				$platform,
				$chat_id,
				"🔒 برای مشاهدهٔ سفارش، ابتدا حساب خود را از «پنل کاربری سایت ← اتصال ربات» متصل کنید.\n(فقط صاحب سفارش یا مدیر می‌تواند سفارش را ببیند)"
			);
			return;
		}

		if ( ! $is_owner && ! $is_admin ) {
			$this->api->send_message( $platform, $chat_id, "❌ این سفارش متعلق به حساب متصل‌شدهٔ شما نیست." );
			return;
		}

		$status_map = array(
			'pending'    => '🛍 در انتظار پرداخت',
			'on-hold'    => '📨 در انتظار تأیید مدیر',
			'processing' => '📦 در حال پردازش',
			'completed'  => '✅ تکمیل شده',
			'cancelled'  => '❌ لغو شده',
			'refunded'   => '💸 مبلغ بازگردانده شده',
			'failed'     => '⚠️ ناموفق',
		);
		$status = $order->get_status();
		$status_fa = isset( $status_map[ $status ] ) ? $status_map[ $status ] : $status;

		$items = '';
		$i     = 0;
		foreach ( $order->get_items() as $item ) {
			if ( $i >= 10 ) {
				$items .= '...';
				break;
			}
			$items .= '├ ' . $item->get_name() . ' × ' . $this->helpers->fa_num( $item->get_quantity() ) . "\n";
			$i++;
		}

		$reply  = "📋 پیگیری سفارش\n\n";
		$reply .= "📌 شماره: #" . $this->helpers->fa_num( $order_id ) . "\n";
		$reply .= "📅 تاریخ: " . $this->helpers->to_jalali( $order->get_date_created() ? $order->get_date_created()->getTimestamp() : null ) . "\n";
		$reply .= "💵 مبلغ: " . $this->helpers->fa_money( $order->get_total() ) . " تومان\n";
		$reply .= "📊 وضعیت: " . $status_fa . "\n";
		if ( '' !== trim( $items ) ) {
			$reply .= "\n🛒 محصولات:\n" . $items;
		}
		$reply .= "\n🔗 " . $order->get_view_order_url();

		$this->api->send_message( $platform, $chat_id, $reply );
		bpp()->bot_users->save_message( $bot_user_id, $chat_id, $platform, 'out', 'text', $reply );
	}
}
