<?php
/**
 * حذف کامل بله‌پی پرو
 *
 * @package BalePayPro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once plugin_dir_path( __FILE__ ) . 'includes/class-bpp-helpers.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-bpp-activator.php';

BPP_Activator::uninstall();
