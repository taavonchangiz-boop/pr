<?php
/**
 * Plugin Name:       BalePay Pro — بله‌پی پرو
 * Plugin URI:        https://example.com/balepay-pro
 * Description:       مدیریت هوشمند سفارشات ووکامرس از طریق ربات‌های بله و تلگرام — کارت به کارت، کیف پول بله، اسنپ‌پی و دیجی‌پی. کاملاً متن‌باز، امن و بدون وابستگی به کد رمزشده.
 * Version:           1.0.0
 * Author:            BalePay Pro
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       balepay-pro
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * WC requires at least: 8.0
 *
 * @package BalePayPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BPP_VERSION', '1.0.0' );
define( 'BPP_FILE', __FILE__ );
define( 'BPP_PATH', plugin_dir_path( __FILE__ ) );
define( 'BPP_URL', plugin_dir_url( __FILE__ ) );
define( 'BPP_BASENAME', plugin_basename( __FILE__ ) );
define( 'BPP_DB_VERSION', '1.0.0' );

$GLOBALS['bpp_tables'] = array(
	'transactions' => '',
	'bot_users'    => '',
	'messages'     => '',
);

// بارگذاری خودکار کلاس‌ها
require_once BPP_PATH . 'includes/class-bpp-helpers.php';
require_once BPP_PATH . 'includes/class-bpp-bot-api.php';
require_once BPP_PATH . 'includes/class-bpp-bot-users.php';
require_once BPP_PATH . 'includes/class-bpp-activator.php';
require_once BPP_PATH . 'includes/class-bpp-user-link.php';
require_once BPP_PATH . 'includes/class-bpp-webhook.php';
require_once BPP_PATH . 'includes/class-bpp-verification.php';
require_once BPP_PATH . 'includes/class-bpp-notifications.php';
require_once BPP_PATH . 'includes/class-bpp-receipt.php';
require_once BPP_PATH . 'includes/class-bpp-report.php';
require_once BPP_PATH . 'includes/class-bpp-sms.php';
require_once BPP_PATH . 'includes/class-bpp-safir.php';
require_once BPP_PATH . 'includes/class-bpp-ajax.php';
require_once BPP_PATH . 'includes/class-bpp-admin.php';
require_once BPP_PATH . 'includes/class-bpp-main.php';

register_activation_hook( __FILE__, array( 'BPP_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'BPP_Activator', 'deactivate' ) );

/**
 * دسترسی سراسری به نمونه اصلی.
 *
 * @return BPP_Main
 */
function bpp() {
	return BPP_Main::instance();
}

add_action( 'plugins_loaded', array( bpp(), 'init' ), 5 );

// اعلام سازگاری با HPOS و Checkout Blocks ووکامرس
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', BPP_FILE );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables_playground', BPP_FILE );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'orders_cache', BPP_FILE );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', BPP_FILE );
	}
} );

// ثبت درگاه‌های Block (اگر ووکامرس بلاک‌چک‌اوت داشته باشد)
add_action( 'woocommerce_blocks_loaded', function () {
	if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
		return;
	}
	require_once BPP_PATH . 'includes/blocks/class-bpp-blocks.php';

	add_action(
		'woocommerce_blocks_payment_method_type_registration',
		function ( $registry ) {
			$registry->register( new BPP_Blocks_Card() );
			$registry->register( new BPP_Blocks_Wallet() );
			$registry->register( new BPP_Blocks_SnappPay() );
			$registry->register( new BPP_Blocks_DigiPay() );
		}
	);
} );

// لینک تنظیمات در صفحه افزونه‌ها
add_filter( 'plugin_action_links_' . BPP_BASENAME, function ( $links ) {
	$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=balepay-pro' ) ) . '">' . esc_html__( 'تنظیمات', 'balepay-pro' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
} );
