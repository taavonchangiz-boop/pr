<?php
/**
 * فرم آپلود رسید — Thank You / My Account
 *
 * @var int    $order_id
 * @var string $order_total
 * @var string $receipt_url
 * @var string $upload_url
 * @var string $nonce
 * @var string $instructions
 * @var int    $deadline
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="bpp-receipt-form" id="bppReceiptWrap">
	<h4>🧾 آپلود رسید پرداخت</h4>
	<p>سفارش #<?php echo esc_html( $order_id ); ?> — مبلغ: <strong><?php echo esc_html( $order_total ); ?> تومان</strong></p>
	<?php if ( '' !== $instructions ) : ?>
		<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;margin:10px 0;font-size:13px;white-space:pre-line"><?php echo esc_html( $instructions ); ?></div>
	<?php endif; ?>

	<?php if ( '' !== $receipt_url ) : ?>
		<div class="bpp-uploaded-preview" style="margin:10px 0">
			<p style="color:#059669;font-weight:600">✅ رسید قبلی ثبت شده است:</p>
			<img src="<?php echo esc_url( $receipt_url ); ?>" alt="رسید" style="max-width:220px;border-radius:10px;border:1px solid #e5e7eb">
			<p style="font-size:12px;color:#6b7280">در صورت نیاز می‌توانید رسید جدید آپلود کنید.</p>
		</div>
	<?php endif; ?>

	<form id="bppReceiptForm" method="post" enctype="multipart/form-data">
		<input type="hidden" name="order_id" value="<?php echo esc_attr( $order_id ); ?>">
		<p><input type="file" name="receipt" accept="image/jpeg,image/png,image/webp"></p>
		<p><textarea name="note" rows="2" style="width:100%;max-width:420px" placeholder="توضیح (اختیاری) — مثلاً نام واریزکننده"></textarea></p>
		<button type="submit" class="button alt">ارسال رسید</button>
		<span class="bpp-upload-status"></span>
	</form>
	<p style="font-size:12px;color:#6b7280">⏳ مهلت پرداخت: <?php echo esc_html( $deadline ); ?> ساعت — پس از تأیید مدیر، سفارش پردازش می‌شود.</p>
</div>
