<?php
/**
 * دکمه اتصال ربات در پنل کاربری
 *
 * @var bool   $bale_connected
 * @var bool   $tg_connected
 * @var string $bale_link
 * @var string $tg_link
 * @var string $code
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="bpp-link-box">
	<h3>🤖 اتصال حساب به ربات بله/تلگرام</h3>
	<p style="color:#6b7280;font-size:13px">با اتصال حساب، اعلان‌های سفارش و امکان پیگیری سفارش از ربات را دریافت می‌کنید.</p>

	<div class="bpp-link-row">
		<strong>ربات بله:</strong>
		<?php if ( $bale_connected ) : ?>
			<span class="status">✅ متصل است</span>
		<?php elseif ( '' !== $bale_link ) : ?>
			<a class="button" href="<?php echo esc_url( $bale_link ); ?>" target="_blank" rel="noopener">اتصال با بله</a>
		<?php else : ?>
			<span class="status off">توکن بله در سایت تنظیم نشده</span>
		<?php endif; ?>
	</div>

	<div class="bpp-link-row">
		<strong>ربات تلگرام:</strong>
		<?php if ( $tg_connected ) : ?>
			<span class="status">✅ متصل است</span>
		<?php elseif ( '' !== $tg_link ) : ?>
			<a class="button" href="<?php echo esc_url( $tg_link ); ?>" target="_blank" rel="noopener">اتصال با تلگرام</a>
		<?php else : ?>
			<span class="status off">توکن تلگرام در سایت تنظیم نشده</span>
		<?php endif; ?>
	</div>

	<p style="font-size:12px;color:#6b7280">کد اتصال شما (۱۰ دقیقه معتبر است): <code dir="ltr"><?php echo esc_html( $code ); ?></code> — اگر لینک بالا کار نکرد، کد را در ربات به شکل <code>/start <?php echo esc_html( $code ); ?></code> ارسال کنید.</p>
</div>
