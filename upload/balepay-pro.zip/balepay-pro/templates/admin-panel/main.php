<?php
/**
 * قالب پنل مدیریت بله‌پی پرو
 *
 * @var BPP_Helpers $helpers
 * @var array       $settings
 * @var string      $webhook_url
 * @var array       $token_state
 * @var array       $cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tabs = array(
	'dashboard' => 'داشبورد',
	'bots'      => 'ربات‌ها',
	'payment'   => 'کارت به کارت',
	'wallet'    => 'کیف پول',
	'snapppay'  => 'اسنپ‌پی',
	'digipay'   => 'دیجی‌پی',
	'channels'  => 'پیام‌رسانی',
	'messages'  => 'قالب پیام‌ها',
	'report'    => 'گزارش',
	'users'     => 'کاربران ربات',
	'logs'      => 'لاگ‌ها',
);
?>
<div class="wrap bpp-app" dir="rtl">
	<h1>💳 بله‌پی پرو <span class="bpp-ver">v<?php echo esc_html( BPP_VERSION ); ?></span></h1>
	<p class="bpp-subtitle">مدیریت هوشمند پرداخت‌های ووکامرس با ربات‌های بله و تلگرام — <strong>۱۰۰٪ متن‌باز</strong></p>

	<div class="bpp-notice bpp-notice-info">
		اگر در «تست اتصال» خطای <strong>«پاسخی دریافت نشد»</strong> می‌بینید، روی دکمهٔ تست بزنید تا <strong>تشخیص مرحله‌به‌مرحله</strong> انجام شود و علت دقیق (DNS / TLS / توکن / پاسخ سرور) نمایش داده شود.
	</div>

	<nav class="bpp-tabs">
		<?php foreach ( $tabs as $id => $label ) : ?>
			<button type="button" class="bpp-tab<?php echo 'dashboard' === $id ? ' active' : ''; ?>" data-tab="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></button>
		<?php endforeach; ?>
	</nav>

	<!-- ==================== داشبورد ==================== -->
	<section class="bpp-pane active" id="bpp-pane-dashboard">
		<div class="bpp-stats" id="bppStats"><div class="bpp-loading">در حال بارگذاری…</div></div>

		<div class="bpp-card">
			<h3>🩺 سلامت سیستم</h3>
			<div id="bppHealth"><div class="bpp-loading">در حال بررسی…</div></div>
		</div>

		<div class="bpp-card">
			<h3>🔗 وضعیت Webhook</h3>
			<div id="bppWebhookStatus"><div class="bpp-loading">در حال بررسی…</div></div>
		</div>
	</section>

	<!-- ==================== ربات‌ها ==================== -->
	<section class="bpp-pane" id="bpp-pane-bots">
		<div class="bpp-card">
			<h3>🤖 ربات بله</h3>
			<p class="bpp-hint">توکن را از <code>@BotFather_Bale</code> بگیرید.</p>
			<label>توکن ربات بله <em>(وضعیت: <?php echo esc_html( $token_state['bale'] ); ?>)</em></label>
			<input type="password" id="bppBaleToken" class="bpp-input" placeholder="<?php echo 'ذخیره شده' === $token_state['bale'] ? '•••••••• (برای تغییر، توکن جدید وارد کنید)' : '123456789:ABC...'; ?>" dir="ltr" autocomplete="off">
			<div class="bpp-row">
				<button type="button" class="button button-primary bpp-test" data-platform="bale">🔌 تست اتصال</button>
				<button type="button" class="button bpp-register" data-platform="bale">📡 ثبت Webhook</button>
			</div>
			<div class="bpp-diagnose" id="bppDiagBale"></div>

			<label>آیدی چت مدیر (بله)</label>
			<input type="text" id="bppBaleAdminId" class="bpp-input" value="<?php echo esc_attr( $settings['bale_admin_chat_id'] ); ?>" dir="ltr" placeholder="مثلاً 123456789">
			<p class="bpp-hint">برای دریافت آیدی خود، به ربات پیام بدهید؛ آیدی در تب «کاربران ربات» نمایش داده می‌شود.</p>
		</div>

		<div class="bpp-card">
			<h3>🤖 ربات تلگرام</h3>
			<p class="bpp-hint">توکن را از <code>@BotFather</code> بگیرید.</p>
			<label>توکن ربات تلگرام <em>(وضعیت: <?php echo esc_html( $token_state['telegram'] ); ?>)</em></label>
			<input type="password" id="bppTgToken" class="bpp-input" placeholder="<?php echo 'ذخیره شده' === $token_state['telegram'] ? '•••••••• (برای تغییر، توکن جدید وارد کنید)' : '123456789:ABC...'; ?>" dir="ltr" autocomplete="off">
			<div class="bpp-row">
				<button type="button" class="button button-primary bpp-test" data-platform="telegram">🔌 تست اتصال</button>
				<button type="button" class="button bpp-register" data-platform="telegram">📡 ثبت Webhook</button>
			</div>
			<div class="bpp-diagnose" id="bppDiagTelegram"></div>

			<label>آیدی چت مدیر (تلگرام)</label>
			<input type="text" id="bppTgAdminId" class="bpp-input" value="<?php echo esc_attr( $settings['telegram_admin_chat_id'] ); ?>" dir="ltr" placeholder="مثلاً 123456789">
		</div>

		<div class="bpp-card">
			<h3>🔐 امنیت</h3>
			<label class="bpp-check"><input type="checkbox" id="bppTlsVerify" <?php checked( 'yes', $settings['tls_verify'] ); ?>> بررسی گواهی TLS در اتصال‌ها (توصیه: فعال)</label>
			<label class="bpp-check"><input type="checkbox" id="bppRequireVerified" <?php checked( 'yes', $settings['require_verified_link'] ); ?>> رهگیری سفارش در ربات فقط برای مالک متصل‌شده یا مدیر (توصیه: فعال)</label>
			<label class="bpp-check"><input type="checkbox" id="bppCallbackHmac" <?php checked( 'yes', $settings['callback_hmac'] ); ?>> امضای HMAC دکمه‌های تأیید/رد (توصیه: فعال)</label>
			<p class="bpp-hint">آدرس Webhook: <code dir="ltr"><?php echo esc_html( $webhook_url ); ?></code></p>
		</div>
	</section>

	<!-- ==================== کارت به کارت ==================== -->
	<section class="bpp-pane" id="bpp-pane-payment">
		<div class="bpp-card">
			<h3>💳 درگاه کارت به کارت</h3>
			<label class="bpp-check"><input type="checkbox" id="bppEnabled" <?php checked( 'yes', $settings['enabled'] ); ?>> فعال‌سازی درگاه</label>
			<label>عنوان درگاه</label>
			<input type="text" id="bppTitle" class="bpp-input" value="<?php echo esc_attr( $settings['title'] ); ?>">
			<label>توضیحات</label>
			<textarea id="bppDescription" class="bpp-input"><?php echo esc_textarea( $settings['description'] ); ?></textarea>
			<label>دستورالعمل پرداخت (در صفحه تشکر)</label>
			<textarea id="bppInstructions" class="bpp-input"><?php echo esc_textarea( $settings['payment_instructions'] ); ?></textarea>
			<label>مهلت پرداخت (ساعت)</label>
			<input type="number" id="bppDeadline" class="bpp-input bpp-input-sm" value="<?php echo esc_attr( $settings['payment_deadline_hours'] ); ?>" min="1" max="72">
			<label class="bpp-check"><input type="checkbox" id="bppAutoExpire" <?php checked( 'yes', $settings['auto_expire_pending'] ); ?>> لغو خودکار سفارش‌های پرداخت‌نشده پس از مهلت</label>
			<label>وضعیت پس از تأیید مدیر</label>
			<select id="bppStatusAfter" class="bpp-input">
				<option value="processing" <?php selected( 'processing', $settings['status_after_approve'] ); ?>>در حال پردازش (processing)</option>
				<option value="completed" <?php selected( 'completed', $settings['status_after_approve'] ); ?>>تکمیل شده (completed)</option>
			</select>
		</div>

		<div class="bpp-card">
			<h3>🏦 کارت‌های بانکی</h3>
			<div id="bppCards">
				<?php if ( empty( $cards ) ) : ?>
					<div class="bpp-card-row" data-index="0">
						<input type="text" class="bpp-input bpp-card-number" placeholder="شماره کارت (۱۶ رقم)" dir="ltr">
						<input type="text" class="bpp-input bpp-card-bank" placeholder="نام بانک">
						<input type="text" class="bpp-input bpp-card-name" placeholder="نام صاحب حساب">
						<button type="button" class="button bpp-remove-card">حذف</button>
					</div>
				<?php else : ?>
					<?php foreach ( $cards as $i => $c ) : ?>
						<div class="bpp-card-row" data-index="<?php echo (int) $i; ?>">
							<input type="text" class="bpp-input bpp-card-number" value="<?php echo esc_attr( $c['number'] ); ?>" placeholder="شماره کارت (۱۶ رقم)" dir="ltr">
							<input type="text" class="bpp-input bpp-card-bank" value="<?php echo esc_attr( isset( $c['bank'] ) ? $c['bank'] : '' ); ?>" placeholder="نام بانک">
							<input type="text" class="bpp-input bpp-card-name" value="<?php echo esc_attr( isset( $c['name'] ) ? $c['name'] : '' ); ?>" placeholder="نام صاحب حساب">
							<button type="button" class="button bpp-remove-card">حذف</button>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
			<button type="button" class="button" id="bppAddCard">+ افزودن کارت</button>
			<label>شماره شبا (اختیاری)</label>
			<input type="text" id="bppSheba" class="bpp-input" value="<?php echo esc_attr( $settings['sheba'] ); ?>" dir="ltr" placeholder="IR...">
		</div>
	</section>

	<!-- ==================== کیف پول ==================== -->
	<section class="bpp-pane" id="bpp-pane-wallet">
		<div class="bpp-card">
			<h3>💰 کیف پول بله</h3>
			<p class="bpp-hint">توکن Provider Token را از ربات <code>@BotFather_Bale</code> ← بخش پرداخت دریافت کنید.</p>
			<label class="bpp-check"><input type="checkbox" id="bppWalletEnabled" <?php checked( 'yes', $settings['wallet_enabled'] ); ?>> فعال‌سازی کیف پول</label>
			<label>Provider Token <em>(وضعیت: <?php echo '' !== $helpers->get_secret( 'wallet_provider_token' ) ? 'ذخیره شده' : 'خالی'; ?>)</em></label>
			<input type="password" id="bppWalletToken" class="bpp-input" dir="ltr" placeholder="توکن از BotFather_Bale" autocomplete="off">
			<label>عنوان</label>
			<input type="text" id="bppWalletTitle" class="bpp-input" value="<?php echo esc_attr( $settings['wallet_title'] ); ?>">
			<label>توضیحات</label>
			<textarea id="bppWalletDesc" class="bpp-input"><?php echo esc_textarea( $settings['wallet_description'] ); ?></textarea>
		</div>
	</section>

	<!-- ==================== اسنپ‌پی ==================== -->
	<section class="bpp-pane" id="bpp-pane-snapppay">
		<div class="bpp-card">
			<h3>🟡 اسنپ‌پی (اقساطی)</h3>
			<label class="bpp-check"><input type="checkbox" id="bppSnappEnabled" <?php checked( 'yes', $settings['snapppay_enabled'] ); ?>> فعال‌سازی اسنپ‌پی</label>
			<label>Client ID</label>
			<input type="text" id="bppSnappClientId" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $helpers->get_secret( 'snapppay_client_id' ) ); ?>">
			<label>Client Secret</label>
			<input type="password" id="bppSnappClientSecret" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'snapppay_client_secret' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>Username</label>
			<input type="text" id="bppSnappUsername" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $helpers->get_secret( 'snapppay_client_username' ) ); ?>">
			<label>Password</label>
			<input type="password" id="bppSnappPassword" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'snapppay_client_password' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>Base URL</label>
			<input type="text" id="bppSnappBaseUrl" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $settings['snapppay_base_url'] ); ?>">
			<label>پیام موفقیت</label>
			<textarea id="bppSnappSuccess" class="bpp-input"><?php echo esc_textarea( $settings['snapppay_success_message'] ); ?></textarea>
			<label>پیام شکست</label>
			<textarea id="bppSnappFailed" class="bpp-input"><?php echo esc_textarea( $settings['snapppay_failed_message'] ); ?></textarea>
		</div>
	</section>

	<!-- ==================== دیجی‌پی ==================== -->
	<section class="bpp-pane" id="bpp-pane-digipay">
		<div class="bpp-card">
			<h3>🟣 دیجی‌پی (اقساطی)</h3>
			<label class="bpp-check"><input type="checkbox" id="bppDigiEnabled" <?php checked( 'yes', $settings['digipay_enabled'] ); ?>> فعال‌سازی دیجی‌پی</label>
			<label>Username</label>
			<input type="text" id="bppDigiUsername" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $helpers->get_secret( 'digipay_username' ) ); ?>">
			<label>Password</label>
			<input type="password" id="bppDigiPassword" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'digipay_password' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>Client ID</label>
			<input type="text" id="bppDigiClientId" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $helpers->get_secret( 'digipay_client_id' ) ); ?>">
			<label>Client Secret</label>
			<input type="password" id="bppDigiClientSecret" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'digipay_client_secret' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>پیام موفقیت</label>
			<textarea id="bppDigiSuccess" class="bpp-input"><?php echo esc_textarea( $settings['digipay_success_message'] ); ?></textarea>
			<label>پیام شکست</label>
			<textarea id="bppDigiFailed" class="bpp-input"><?php echo esc_textarea( $settings['digipay_failed_message'] ); ?></textarea>
		</div>
	</section>

	<!-- ==================== پیام‌رسانی ==================== -->
	<section class="bpp-pane" id="bpp-pane-channels">
		<div class="bpp-card">
			<h3>📣 کانال‌های اعلان</h3>
			<h4>اعلان به مدیر</h4>
			<label class="bpp-check"><input type="checkbox" id="bppNotifyAdminBale" <?php checked( 'yes', $settings['notify_admin_bale'] ); ?>> از طریق ربات بله</label>
			<label class="bpp-check"><input type="checkbox" id="bppNotifyAdminTg" <?php checked( 'yes', $settings['notify_admin_tg'] ); ?>> از طریق ربات تلگرام</label>
			<h4>اعلان به مشتری</h4>
			<label class="bpp-check"><input type="checkbox" id="bppNotifyCustBale" <?php checked( 'yes', $settings['notify_customer_bale'] ); ?>> از طریق ربات بله</label>
			<label class="bpp-check"><input type="checkbox" id="bppNotifyCustTg" <?php checked( 'yes', $settings['notify_customer_tg'] ); ?>> از طریق ربات تلگرام</label>
			<label>تلفن مدیر (برای پشتیبان SMS/سفیر)</label>
			<input type="text" id="bppAdminPhone" class="bpp-input" value="<?php echo esc_attr( $settings['admin_phone'] ); ?>" dir="ltr" placeholder="09xxxxxxxxx">
		</div>
		<div class="bpp-card">
			<h3>✉️ پیامک (ملی پیامک)</h3>
			<label>نام کاربری</label>
			<input type="text" id="bppSmsUser" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $settings['sms_username'] ); ?>">
			<label>رمز عبور</label>
			<input type="password" id="bppSmsPass" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'sms_password' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>خط ارسال</label>
			<input type="text" id="bppSmsFrom" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $settings['sms_from'] ); ?>">
			<label class="bpp-check"><input type="checkbox" id="bppSmsFlash" <?php checked( 1, (int) $settings['sms_isflash'] ); ?>> پیامک فلش</label>
		</div>
		<div class="bpp-card">
			<h3>🚀 سفیر بله (پیام با شماره تلفن)</h3>
			<label>Access Key</label>
			<input type="password" id="bppSafirKey" class="bpp-input" dir="ltr" placeholder="<?php echo '' !== $helpers->get_secret( 'safir_access_key' ) ? '•••• (رمزنگاری شده)' : ''; ?>" autocomplete="off">
			<label>Bot ID</label>
			<input type="text" id="bppSafirBotId" class="bpp-input" dir="ltr" value="<?php echo esc_attr( $settings['safir_bot_id'] ); ?>">
		</div>
	</section>

	<!-- ==================== قالب پیام‌ها ==================== -->
	<section class="bpp-pane" id="bpp-pane-messages">
		<div class="bpp-card">
			<h3>💬 قالب پیام‌های ربات</h3>
			<p class="bpp-hint">متغیرها: <code>{order_id} {total} {customer} {phone} {date} {time} {items} {cards} {deadline} {order_url}</code></p>
			<?php
			$msg_fields = array(
				'msg_welcome'         => 'خوش‌آمد (/start)',
				'msg_help'            => 'راهنما (/help)',
				'msg_link_success'    => 'اتصال موفق ({platform_name} و {user_name})',
				'msg_link_invalid'    => 'کد نامعتبر',
				'msg_link_expired'    => 'کد منقضی',
				'msg_order_placed'    => 'سفارش جدید برای مدیر',
				'msg_receipt_uploaded'=> 'آپلود رسید',
				'msg_approved'        => 'تأیید پرداخت (به مشتری)',
				'msg_rejected'        => 'رد پرداخت (به مشتری)',
				'msg_onhold'          => 'در انتظار تأیید (به مشتری)',
			);
			foreach ( $msg_fields as $key => $label ) :
				?>
				<label><?php echo esc_html( $label ); ?></label>
				<textarea class="bpp-input bpp-msg" data-key="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $settings[ $key ] ); ?></textarea>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- ==================== گزارش ==================== -->
	<section class="bpp-pane" id="bpp-pane-report">
		<div class="bpp-card">
			<h3>📊 گزارش دوره‌ای</h3>
			<label>دوره</label>
			<select id="bppReportPeriod" class="bpp-input">
				<option value="daily" <?php selected( 'daily', $settings['report_period'] ); ?>>روزانه</option>
				<option value="weekly" <?php selected( 'weekly', $settings['report_period'] ); ?>>هفتگی</option>
			</select>
			<label>ساعت ارسال</label>
			<input type="time" id="bppReportTime" class="bpp-input" value="<?php echo esc_attr( $settings['report_time'] ); ?>">
			<button type="button" class="button" id="bppSendTestReport">📤 ارسال گزارش تستی</button>
		</div>
		<div class="bpp-card">
			<h3>🧾 تراکنش‌های اخیر</h3>
			<div id="bppTransactions"><div class="bpp-loading">در حال بارگذاری…</div></div>
		</div>
	</section>

	<!-- ==================== کاربران ==================== -->
	<section class="bpp-pane" id="bpp-pane-users">
		<div class="bpp-card">
			<h3>👥 کاربران ربات</h3>
			<div class="bpp-row">
				<select id="bppUserPlatform" class="bpp-input bpp-input-sm">
					<option value="all">همه پلتفرم‌ها</option>
					<option value="bale">بله</option>
					<option value="telegram">تلگرام</option>
				</select>
				<input type="text" id="bppUserSearch" class="bpp-input" placeholder="جستجو…">
				<button type="button" class="button" id="bppUserSearchBtn">جستجو</button>
			</div>
			<div id="bppUsersList"><div class="bpp-loading">در حال بارگذاری…</div></div>
		</div>
		<div class="bpp-card">
			<h3>📣 ارسال پیام گروهی (حداکثر ۱۰۰ کاربر)</h3>
			<select id="bppBulkPlatform" class="bpp-input bpp-input-sm">
				<option value="all">همه</option>
				<option value="bale">فقط بله</option>
				<option value="telegram">فقط تلگرام</option>
			</select>
			<textarea id="bppBulkMessage" class="bpp-input" placeholder="متن پیام…"></textarea>
			<button type="button" class="button" id="bppBulkSend">ارسال گروهی</button>
		</div>
	</section>

	<!-- ==================== لاگ‌ها ==================== -->
	<section class="bpp-pane" id="bpp-pane-logs">
		<div class="bpp-card">
			<h3>📜 لاگ‌ها <button type="button" class="button" id="bppClearLogs">پاک کردن</button></h3>
			<div id="bppLogs"><div class="bpp-loading">در حال بارگذاری…</div></div>
		</div>
	</section>

	<div class="bpp-savebar">
		<button type="button" class="button button-primary button-hero" id="bppSave">💾 ذخیره همه تنظیمات</button>
		<span id="bppSaveMsg"></span>
	</div>
</div>
