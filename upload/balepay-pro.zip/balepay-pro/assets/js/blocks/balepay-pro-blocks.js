/* BalePay Pro — Checkout Blocks registration */
(function () {
	'use strict';
	var el = window.wp.element.createElement;
	var i18n = window.wp.i18n;
	var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;

	function createMethod(name, label) {
		return function (settings) {
			var content = el('div', { style: { padding: '4px 0' } }, settings.description || '');
			return {
				name: name,
				label: el('span', {}, label),
				content: content,
				edit: content,
				canMakePayment: function () { return true; },
				ariaLabel: label,
				supports: { features: settings.supports ? settings.supports.features : [] }
			};
		};
	}

	if (!registerPaymentMethod || !window.wc || !window.wc.wcSettings) { return; }
	var settings = window.wc.wcSettings.getSetting;

	try {
		var card = settings('bpp_card_data', null);
		if (card) { registerPaymentMethod(createMethod('bpp_card', card.title)); }
	} catch (e) {}
	try {
		var wallet = settings('bpp_wallet_data', null);
		if (wallet) { registerPaymentMethod(createMethod('bpp_wallet', wallet.title)); }
	} catch (e) {}
	try {
		var spp = settings('bpp_snapppay_data', null);
		if (spp) { registerPaymentMethod(createMethod('bpp_snapppay', spp.title)); }
	} catch (e) {}
	try {
		var dp = settings('bpp_digipay_data', null);
		if (dp) { registerPaymentMethod(createMethod('bpp_digipay', dp.title)); }
	} catch (e) {}
})();
