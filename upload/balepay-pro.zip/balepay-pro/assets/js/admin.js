/* BalePay Pro — Admin Panel (100% open source) */
(function ($) {
	'use strict';

	var B = window.BPP || {};

	function ajax(action, data, cb) {
		data = data || {};
		data.action = action;
		data.nonce = B.nonce;
		$.post(B.ajax_url, data)
			.done(function (resp) {
				if (resp && resp.success) { cb && cb(null, resp.data); }
				else {
					var msg = resp && resp.data && resp.data.message ? resp.data.message : 'خطای ناشناخته';
					cb && cb(msg);
				}
			})
			.fail(function (xhr) {
				cb && cb('خطای شبکه (' + xhr.status + ')');
			});
	}

	/* ---- تب‌ها ---- */
	$('.bpp-tab').on('click', function () {
		var id = $(this).data('tab');
		$('.bpp-tab').removeClass('active');
		$(this).addClass('active');
		$('.bpp-pane').removeClass('active');
		$('#bpp-pane-' + id).addClass('active');
	});

	/* ---- داشبورد ---- */
	function loadStats() {
		ajax('bpp_dashboard_stats', {}, function (err, d) {
			if (err) { $('#bppStats').html('<div class="bpp-error">' + err + '</div>'); return; }
			var html =
				'<div class="bpp-stat"><b>' + d.today_orders + '</b><span>تراکنش امروز</span></div>' +
				'<div class="bpp-stat"><b>' + d.today_approved + '</b><span>تأیید امروز</span></div>' +
				'<div class="bpp-stat"><b>' + d.pending + '</b><span>در انتظار تأیید</span></div>' +
				'<div class="bpp-stat"><b>' + d.wallet_total + '</b><span>کیف پول (کل)</span></div>' +
				'<div class="bpp-stat"><b>' + d.bot_users + '</b><span>کاربران ربات</span></div>' +
				'<div class="bpp-stat"><b>' + d.linked_users + '</b><span>حساب‌های متصل</span></div>';
			$('#bppStats').html(html);
		});
	}

	function loadHealth() {
		ajax('bpp_health_check', {}, function (err, d) {
			if (err) { $('#bppHealth').html('<div class="bpp-error">' + err + '</div>'); return; }
			var rows = [
				['وردپرس', d.wp_version],
				['ووکامرس', d.woocommerce],
				['PHP', d.php_version],
				['OpenSSL (رمزنگاری)', d.openssl ? '✅ فعال' : '❌ غیرفعال'],
				['cURL', d.curl ? '✅ فعال' : '❌ غیرفعال'],
				['ionCube (کد رمز)', d.ioncube === 'نصب نیست (مطلوب)' ? '✅ نصب نیست (مطلوب)' : '⚠️ نصب است'],
				['HTTPS سایت', d.server_ssl],
				['REST API', d.rest]
			];
			var html = '<table class="bpp-table"><tbody>';
			$.each(rows, function (i, r) {
				html += '<tr><td>' + r[0] + '</td><td dir="ltr" style="text-align:left">' + r[1] + '</td></tr>';
			});
			html += '</tbody></table>';
			$('#bppHealth').html(html);
		});
	}

	function loadWebhookStatus() {
		ajax('bpp_webhook_status', {}, function (err, d) {
			if (err) { $('#bppWebhookStatus').html('<div class="bpp-error">' + err + '</div>'); return; }
			var html = '<table class="bpp-table"><tbody>';
			$.each(['bale', 'telegram'], function (i, p) {
				var s = d[p];
				var state = s.ok ? (s.healthy ? '✅ سالم' : '⚠️ ' + s.message) : '❌ ' + s.message;
				html += '<tr><td>' + (p === 'bale' ? 'بله' : 'تلگرام') + '</td><td>' + state + '</td></tr>';
			});
			html += '</tbody></table>';
			$('#bppWebhookStatus').html(html);
		});
	}

	/* ---- تست اتصال (قلب رفع باگ «پاسخی دریافت نشد») ---- */
	$('.bpp-test').on('click', function () {
		var platform = $(this).data('platform');
		var box = $('#bppDiag' + (platform === 'bale' ? 'Bale' : 'Telegram'));
		var tokenField = platform === 'bale' ? '#bppBaleToken' : '#bppTgToken';
		var token = $(tokenField).val() || '';
		box.html('<div class="bpp-loading">در حال تست…</div>');
		$(this).prop('disabled', true);
		ajax('bpp_test_connection', { platform: platform, token: token }, function (err, d) {
			$('.bpp-test[data-platform="' + platform + '"]').prop('disabled', false);
			if (err) { box.html('<div class="bpp-error">' + err + '</div>'); return; }
			var html = '<div class="bpp-diagnose-box ' + (d.ok ? 'bpp-ok' : 'bpp-err') + '">';
			html += '<b>' + (d.ok ? '✅ اتصال برقرار است' : '❌ اتصال ناموفق') + '</b>';
			if (d.info) { html += '<div>' + d.info + '</div>'; }
			html += '<ol>';
			$.each(d.steps || [], function (i, s) {
				html += '<li>' + (s.ok ? '✅' : '❌') + ' <b>' + s.name + ':</b> ' + s.msg + '</li>';
			});
			html += '</ol></div>';
			box.html(html);
		});
	});

	/* ---- ثبت Webhook ---- */
	$('.bpp-register').on('click', function () {
		var platform = $(this).data('platform');
		var btn = $(this);
		btn.prop('disabled', true).text('در حال ثبت…');
		ajax('bpp_register_webhook', { platform: platform }, function (err, d) {
			btn.prop('disabled', false).text('📡 ثبت Webhook');
			alert(err ? 'خطا: ' + err : '✅ ' + d.message);
			loadWebhookStatus();
		});
	});

	/* ---- کارت‌ها ---- */
	$('#bppAddCard').on('click', function () {
		var idx = $('.bpp-card-row').length;
		$('#bppCards').append(
			'<div class="bpp-card-row" data-index="' + idx + '">' +
			'<input type="text" class="bpp-input bpp-card-number" placeholder="شماره کارت (۱۶ رقم)" dir="ltr">' +
			'<input type="text" class="bpp-input bpp-card-bank" placeholder="نام بانک">' +
			'<input type="text" class="bpp-input bpp-card-name" placeholder="نام صاحب حساب">' +
			'<button type="button" class="button bpp-remove-card">حذف</button></div>'
		);
	});
	$(document).on('click', '.bpp-remove-card', function () {
		$(this).closest('.bpp-card-row').remove();
	});

	/* ---- ذخیره ---- */
	$('#bppSave').on('click', function () {
		var cards = [];
		$('.bpp-card-row').each(function () {
			var row = $(this);
			cards.push({
				number: row.find('.bpp-card-number').val(),
				bank: row.find('.bpp-card-bank').val(),
				name: row.find('.bpp-card-name').val()
			});
		});

		var msgFields = {};
		$('.bpp-msg').each(function () {
			msgFields[$(this).data('key')] = $(this).val();
		});

		var settings = {
			/* bots */
			bale_token: $('#bppBaleToken').val(),
			telegram_token: $('#bppTgToken').val(),
			bale_admin_chat_id: $('#bppBaleAdminId').val(),
			telegram_admin_chat_id: $('#bppTgAdminId').val(),
			admin_phone: $('#bppAdminPhone').val(),
			tls_verify: $('#bppTlsVerify').is(':checked') ? 'yes' : 'no',
			require_verified_link: $('#bppRequireVerified').is(':checked') ? 'yes' : 'no',
			callback_hmac: $('#bppCallbackHmac').is(':checked') ? 'yes' : 'no',
			/* card */
			enabled: $('#bppEnabled').is(':checked') ? 'yes' : 'no',
			title: $('#bppTitle').val(),
			description: $('#bppDescription').val(),
			payment_instructions: $('#bppInstructions').val(),
			payment_deadline_hours: $('#bppDeadline').val(),
			auto_expire_pending: $('#bppAutoExpire').is(':checked') ? 'yes' : 'no',
			status_after_approve: $('#bppStatusAfter').val(),
			cards: cards,
			sheba: $('#bppSheba').val(),
			/* wallet */
			wallet_enabled: $('#bppWalletEnabled').is(':checked') ? 'yes' : 'no',
			wallet_provider_token: $('#bppWalletToken').val(),
			wallet_title: $('#bppWalletTitle').val(),
			wallet_description: $('#bppWalletDesc').val(),
			/* snapppay */
			snapppay_enabled: $('#bppSnappEnabled').is(':checked') ? 'yes' : 'no',
			snapppay_client_id: $('#bppSnappClientId').val(),
			snapppay_client_secret: $('#bppSnappClientSecret').val(),
			snapppay_client_username: $('#bppSnappUsername').val(),
			snapppay_client_password: $('#bppSnappPassword').val(),
			snapppay_base_url: $('#bppSnappBaseUrl').val(),
			snapppay_success_message: $('#bppSnappSuccess').val(),
			snapppay_failed_message: $('#bppSnappFailed').val(),
			/* digipay */
			digipay_enabled: $('#bppDigiEnabled').is(':checked') ? 'yes' : 'no',
			digipay_username: $('#bppDigiUsername').val(),
			digipay_password: $('#bppDigiPassword').val(),
			digipay_client_id: $('#bppDigiClientId').val(),
			digipay_client_secret: $('#bppDigiClientSecret').val(),
			digipay_success_message: $('#bppDigiSuccess').val(),
			digipay_failed_message: $('#bppDigiFailed').val(),
			/* channels */
			notify_admin_bale: $('#bppNotifyAdminBale').is(':checked') ? 'yes' : 'no',
			notify_admin_tg: $('#bppNotifyAdminTg').is(':checked') ? 'yes' : 'no',
			notify_customer_bale: $('#bppNotifyCustBale').is(':checked') ? 'yes' : 'no',
			notify_customer_tg: $('#bppNotifyCustTg').is(':checked') ? 'yes' : 'no',
			sms_username: $('#bppSmsUser').val(),
			sms_password: $('#bppSmsPass').val(),
			sms_from: $('#bppSmsFrom').val(),
			sms_isflash: $('#bppSmsFlash').is(':checked') ? 1 : 0,
			safir_access_key: $('#bppSafirKey').val(),
			safir_bot_id: $('#bppSafirBotId').val(),
			/* messages */
			msg_welcome: msgFields.msg_welcome || '',
			msg_help: msgFields.msg_help || '',
			msg_link_success: msgFields.msg_link_success || '',
			msg_link_invalid: msgFields.msg_link_invalid || '',
			msg_link_expired: msgFields.msg_link_expired || '',
			msg_order_placed: msgFields.msg_order_placed || '',
			msg_receipt_uploaded: msgFields.msg_receipt_uploaded || '',
			msg_approved: msgFields.msg_approved || '',
			msg_rejected: msgFields.msg_rejected || '',
			msg_onhold: msgFields.msg_onhold || '',
			/* report */
			report_period: $('#bppReportPeriod').val(),
			report_time: $('#bppReportTime').val()
		};

		var btn = $('#bppSave');
		btn.prop('disabled', true);
		$('#bppSaveMsg').text('در حال ذخیره…').removeClass('bpp-err').addClass('bpp-ok');
		ajax('bpp_save_settings', { settings: settings }, function (err, d) {
			btn.prop('disabled', false);
			if (err) {
				$('#bppSaveMsg').text('❌ ' + err).removeClass('bpp-ok').addClass('bpp-err');
			} else {
				$('#bppSaveMsg').text('✅ ' + d.message).removeClass('bpp-err').addClass('bpp-ok');
				/* پاک کردن فیلدهای توکن پس از ذخیره */
				$('#bppBaleToken, #bppTgToken, #bppWalletToken, #bppSnappClientSecret, #bppSnappPassword, #bppDigiPassword, #bppDigiClientSecret, #bppSmsPass, #bppSafirKey').val('');
				loadStats();
				loadWebhookStatus();
			}
			setTimeout(function () { $('#bppSaveMsg').fadeOut(800, function () { $(this).text('').show(); }); }, 4000);
		});
	});

	/* ---- تراکنش‌ها ---- */
	function loadTransactions() {
		ajax('bpp_get_transactions', { limit: 10 }, function (err, rows) {
			if (err) { $('#bppTransactions').html('<div class="bpp-error">' + err + '</div>'); return; }
			if (!rows.length) { $('#bppTransactions').html('<p>تراکنشی ثبت نشده است.</p>'); return; }
			var html = '<table class="bpp-table"><thead><tr><th>#</th><th>سفارش</th><th>نوع</th><th>وضعیت</th><th>تصمیم</th><th>تاریخ</th></tr></thead><tbody>';
			$.each(rows, function (i, t) {
				var type = t.transaction_type === 'wallet' ? 'کیف پول' : 'کارت به کارت';
				var st = { 'on-hold': 'در انتظار', processing: 'در حال پردازش', cancelled: 'لغو', completed: 'تکمیل', pending: 'در انتظار' }[t.status] || t.status;
				var dec = { approve: '✅ تأیید', reject: '❌ رد', undo: '↩️ بازگشت', '': '—' }[t.decision] || t.decision;
				html += '<tr><td>' + t.id + '</td><td>#' + t.order_id + '</td><td>' + type + '</td><td>' + st + '</td><td>' + dec + '</td><td>' + t.created_at + '</td></tr>';
			});
			html += '</tbody></table>';
			$('#bppTransactions').html(html);
		});
	}

	/* ---- کاربران ---- */
	function loadUsers() {
		ajax('bpp_get_users', {
			platform: $('#bppUserPlatform').val(),
			search: $('#bppUserSearch').val()
		}, function (err, users) {
			if (err) { $('#bppUsersList').html('<div class="bpp-error">' + err + '</div>'); return; }
			if (!users.length) { $('#bppUsersList').html('<p>کاربری یافت نشد. وقتی کسی به ربات پیام دهد اینجا ظاهر می‌شود.</p>'); return; }
			var html = '<table class="bpp-table"><thead><tr><th>نام</th><th>پلتفرم</th><th>Chat ID</th><th>کاربر وردپرس</th><th>آخرین فعالیت</th><th>عملیات</th></tr></thead><tbody>';
			$.each(users, function (i, u) {
				var plat = u.platform === 'bale' ? 'بله' : 'تلگرام';
				html += '<tr><td>' + (u.first_name || '') + ' ' + (u.last_name || '') + (u.username ? ' (@' + u.username + ')' : '') + '</td>' +
					'<td>' + plat + '</td>' +
					'<td dir="ltr">' + u.chat_id + '</td>' +
					'<td>' + (u.wp_user_id ? '#' + u.wp_user_id : '—') + '</td>' +
					'<td>' + (u.last_seen || '—') + '</td>' +
					'<td>' +
					'<button class="button bpp-send-msg" data-id="' + u.id + '" data-chat="' + u.chat_id + '" data-platform="' + u.platform + '">پیام</button> ' +
					'<button class="button bpp-set-admin" data-id="' + u.id + '" data-make="' + (u.is_admin == 1 ? '0' : '1') + '">' + (u.is_admin == 1 ? 'عزل' : 'مدیر') + '</button> ' +
					'<button class="button bpp-block" data-id="' + u.id + '" data-block="' + (u.is_blocked == 1 ? '0' : '1') + '">' + (u.is_blocked == 1 ? 'رفع بلاک' : 'بلاک') + '</button>' +
					'</td></tr>';
			});
			html += '</tbody></table>';
			$('#bppUsersList').html(html);
		});
	}

	$('#bppUserSearchBtn').on('click', loadUsers);
	$('#bppUserPlatform').on('change', loadUsers);

	$(document).on('click', '.bpp-send-msg', function () {
		var id = $(this).data('id');
		var msg = prompt('متن پیام برای ' + $(this).data('chat') + ':');
		if (!msg) { return; }
		ajax('bpp_send_manual_message', { user_id: id, message: msg }, function (err, d) {
			alert(err ? '❌ ' + err : '✅ ' + d.message);
		});
	});

	$(document).on('click', '.bpp-set-admin', function () {
		var btn = $(this);
		ajax('bpp_set_admin', { user_id: btn.data('id'), make: btn.data('make') }, function (err, d) {
			if (!err) { alert('✅ ' + d.message); loadUsers(); } else { alert('❌ ' + err); }
		});
	});

	$(document).on('click', '.bpp-block', function () {
		var btn = $(this);
		ajax('bpp_block_user', { user_id: btn.data('id'), block: btn.data('block') }, function (err, d) {
			if (!err) { alert('✅ ' + d.message); loadUsers(); } else { alert('❌ ' + err); }
		});
	});

	/* ---- ارسال گروهی ---- */
	$('#bppBulkSend').on('click', function () {
		var msg = $('#bppBulkMessage').val();
		if (!msg) { alert('متن پیام را بنویسید'); return; }
		if (!confirm('پیام برای حداکثر ۱۰۰ کاربر ارسال شود؟')) { return; }
		ajax('bpp_send_bulk_message', { platform: $('#bppBulkPlatform').val(), message: msg }, function (err, d) {
			alert(err ? '❌ ' + err : '✅ ' + d.message);
		});
	});

	/* ---- گزارش تستی ---- */
	$('#bppSendTestReport').on('click', function () {
		ajax('bpp_send_test_report', {}, function (err, d) {
			alert(err ? '❌ ' + err : '✅ ' + d.message);
		});
	});

	/* ---- لاگ‌ها ---- */
	function loadLogs() {
		ajax('bpp_get_logs', {}, function (err, logs) {
			if (err) { $('#bppLogs').html('<div class="bpp-error">' + err + '</div>'); return; }
			if (!logs.length) { $('#bppLogs').html('<p>لاگی ثبت نشده است.</p>'); return; }
			var html = '<table class="bpp-table"><thead><tr><th>زمان</th><th>نوع</th><th>پیام</th></tr></thead><tbody>';
			$.each(logs, function (i, l) {
				var badge = { ok: '✅', no: '❌', in: '📥', wa: '⚠️' }[l.type] || '•';
				html += '<tr><td>' + l.created_at + '</td><td>' + badge + '</td><td dir="auto">' + l.message + '</td></tr>';
			});
			html += '</tbody></table>';
			$('#bppLogs').html(html);
		});
	}
	$('#bppClearLogs').on('click', function () {
		if (!confirm('همه لاگ‌ها پاک شود؟')) { return; }
		ajax('bpp_clear_logs', {}, function (err) {
			if (!err) { loadLogs(); }
		});
	});

	/* ---- شروع ---- */
	$(function () {
		loadStats();
		loadHealth();
		loadWebhookStatus();
		loadTransactions();
		loadUsers();
		loadLogs();
	});
})(jQuery);
