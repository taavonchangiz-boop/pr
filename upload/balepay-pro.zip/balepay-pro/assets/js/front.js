/* BalePay Pro — Frontend JS */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var form = document.getElementById('bppReceiptForm');
		if (!form || typeof window.BPP === 'undefined') { return; }

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var fileInput = form.querySelector('input[type="file"]');
			var orderId = form.querySelector('input[name="order_id"]');
			var note = form.querySelector('textarea[name="note"]');
			var status = form.querySelector('.bpp-upload-status');
			if (!fileInput || !fileInput.files.length) {
				if (status) { status.textContent = 'لطفاً فایل رسید را انتخاب کنید.'; status.className = 'bpp-upload-status bpp-upload-err'; }
				return;
			}

			var fd = new FormData();
			fd.append('receipt', fileInput.files[0]);
			fd.append('order_id', orderId ? orderId.value : '');
			if (note) { fd.append('note', note.value); }

			if (status) { status.textContent = 'در حال آپلود…'; status.className = 'bpp-upload-status'; }

			fetch(window.BPP.rest_url, {
				method: 'POST',
				body: fd,
				credentials: 'same-origin',
				headers: { 'X-WP-Nonce': window.BPP.nonce }
			})
				.then(function (r) { return r.json(); })
				.then(function (data) {
					if (data && data.ok) {
						if (status) { status.textContent = '✅ رسید با موفقیت آپلود شد. در انتظار تأیید مدیر.'; status.className = 'bpp-upload-status bpp-upload-ok'; }
						form.querySelector('.bpp-uploaded-preview') &&
							(form.querySelector('.bpp-uploaded-preview').innerHTML = '<img src="' + data.url + '" style="max-width:200px;border-radius:8px">');
						fileInput.value = '';
						setTimeout(function () { location.reload(); }, 2500);
					} else {
						if (status) { status.textContent = '❌ ' + (data && data.message ? data.message : 'خطا در آپلود'); status.className = 'bpp-upload-status bpp-upload-err'; }
					}
				})
				.catch(function () {
					if (status) { status.textContent = '❌ خطای شبکه در آپلود'; status.className = 'bpp-upload-status bpp-upload-err'; }
				});
		});
	});
})();
